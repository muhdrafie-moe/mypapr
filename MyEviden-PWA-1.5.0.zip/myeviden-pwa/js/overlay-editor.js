'use strict';
/*
 * OverlayEditor — editor lapisan teks & bentuk (Fabric.js) yang dikongsi oleh
 * Editor Gambar dan Editor Video.
 */
const FONT_LIST = ['Arial', 'Segoe UI', 'Verdana', 'Tahoma', 'Trebuchet MS', 'Georgia', 'Times New Roman', 'Courier New', 'Comic Sans MS', 'Impact', 'Calibri', 'Cambria'];
const QUICK_COLORS = ['#ffffff', '#000000', '#ff3b30', '#ff9500', '#ffd400', '#34c759', '#00c7be', '#007aff', '#5856d6', '#af52de', '#ff2d55', '#8e8e93'];
const EXTRA_PROPS = ['mpName', 'mpStart', 'mpEnd', 'mpKind'];

(function setupFabricDefaults() {
  if (!window.fabric) return;
  Object.assign(fabric.Object.prototype, {
    transparentCorners: false, cornerColor: '#ffffff', cornerStrokeColor: '#1f5bff', borderColor: '#1f5bff',
    cornerStyle: 'circle', cornerSize: 12, borderScaleFactor: 2, padding: 4, objectCaching: true
  });
})();

class OverlayEditor {
  constructor(opts) {
    this.opts = opts;
    this.mode = opts.mode || 'image';
    this.canvas = null;
    this.workW = 0; this.workH = 0;
    this.displayScale = 1;
    this.history = []; this.hIndex = -1; this.restoring = false;
    this.counter = {};
    this.duration = 0;
    this.buildTools();
    this.renderProps();
    this.ro = new ResizeObserver(() => this.fit());
    this.ro.observe(opts.stageEl);
  }

  /* ------------------------------ kanvas ------------------------------ */
  ensureCanvas() {
    if (this.canvas) return this.canvas;
    const c = new fabric.Canvas(this.opts.canvasEl, {
      preserveObjectStacking: true, enableRetinaScaling: false, stopContextMenu: true, selection: true,
      uniformScaling: true, backgroundColor: null
    });
    this.canvas = c;
    const snap = () => this.snapshot();
    c.on('object:added', (e) => { if (!this.restoring && e.target && !e.target.mpTemp) snap(); this.renderLayers(); });
    c.on('object:removed', () => { if (!this.restoring) snap(); this.renderLayers(); });
    c.on('object:modified', () => { if (!this.restoring) snap(); this.syncPropsValues(); });
    c.on('selection:created', () => this.renderProps());
    c.on('selection:updated', () => this.renderProps());
    c.on('selection:cleared', () => this.renderProps());
    c.on('text:changed', (e) => {
      const ta = this.opts.propsEl.querySelector('textarea[data-k="text"]');
      if (ta && e.target === c.getActiveObject()) ta.value = e.target.text;
      this.renderLayers();
    });
    c.on('text:editing:exited', () => snap());
    return c;
  }

  get hasContent() { return this.workW > 0; }

  setSize(w, hgt) {
    this.ensureCanvas();
    this.workW = Math.round(w); this.workH = Math.round(hgt);
    this.canvas.setWidth(this.workW);
    this.canvas.setHeight(this.workH);
    this.opts.hostEl.classList.add('show');
    this.fit();
  }

  get unit() { return Math.max(this.workW, this.workH) / 1000; }

  fit() {
    if (!this.canvas || !this.workW) return;
    const st = this.opts.stageEl.getBoundingClientRect();
    if (st.width < 20 || st.height < 20) return;
    const pad = 18;
    const s = Math.min((st.width - pad * 2) / this.workW, (st.height - pad * 2) / this.workH, 3);
    const cw = Math.max(10, Math.floor(this.workW * s));
    const ch = Math.max(10, Math.floor(this.workH * s));
    this.displayScale = cw / this.workW;
    this.canvas.setDimensions({ width: cw + 'px', height: ch + 'px' }, { cssOnly: true });
    const host = this.opts.hostEl;
    host.style.width = cw + 'px';
    host.style.height = ch + 'px';
    this.canvas.calcOffset();
    if (this.opts.onFit) this.opts.onFit(cw, ch, this.displayScale);
  }

  clearAll(keepHistory) {
    if (!this.canvas) return;
    this.restoring = true;
    this.canvas.getObjects().slice().forEach((o) => this.canvas.remove(o));
    this.canvas.discardActiveObject();
    this.restoring = false;
    if (!keepHistory) { this.history = []; this.hIndex = -1; this.snapshot(); }
    this.canvas.requestRenderAll();
    this.renderProps();
  }

  userObjects() { return this.canvas ? this.canvas.getObjects().filter((o) => !o.mpTemp) : []; }

  /* ------------------------------ sejarah ------------------------------ */
  serialize() { return JSON.stringify({ objects: this.userObjects().map((o) => o.toObject(EXTRA_PROPS)) }); }
  snapshot() {
    if (!this.canvas || this.restoring) return;
    const s = this.serialize();
    if (this.history[this.hIndex] === s) return;
    this.history = this.history.slice(0, this.hIndex + 1);
    this.history.push(s);
    if (this.history.length > 60) this.history.shift();
    this.hIndex = this.history.length - 1;
    if (this.opts.onChange) this.opts.onChange();
  }
  restore(state) {
    return new Promise((resolve) => {
      const data = JSON.parse(state);
      this.restoring = true;
      this.canvas.discardActiveObject();
      this.userObjects().forEach((o) => this.canvas.remove(o));
      fabric.util.enlivenObjects(data.objects, (objs) => {
        objs.forEach((o) => this.canvas.add(o));
        this.restoring = false;
        this.canvas.requestRenderAll();
        this.renderProps();
        if (this.opts.onChange) this.opts.onChange();
        resolve();
      });
    });
  }
  async undo() { if (this.hIndex > 0) { this.hIndex--; await this.restore(this.history[this.hIndex]); } }
  async redo() { if (this.hIndex < this.history.length - 1) { this.hIndex++; await this.restore(this.history[this.hIndex]); } }

  /* ------------------------------ alat ------------------------------ */
  buildTools() {
    const el = this.opts.toolsEl;
    el.innerHTML = '';
    el.appendChild(h('div', { class: 'panel-title' }, 'Tambah Teks'));
    const g1 = h('div', { class: 'tools-grid' });
    g1.append(
      this.toolBtn('text', 'Teks', () => this.addText()),
      this.toolBtn('stamp', 'Label Evidens', () => this.addEvidenceLabel())
    );
    el.appendChild(g1);
    el.appendChild(h('div', { class: 'panel-title' }, 'Tambah Bentuk'));
    const g2 = h('div', { class: 'tools-grid' });
    g2.append(
      this.toolBtn('rect', 'Segi empat', () => this.addShape('rect')),
      this.toolBtn('roundrect', 'Bucu bulat', () => this.addShape('roundrect')),
      this.toolBtn('circle', 'Bulatan', () => this.addShape('circle')),
      this.toolBtn('triangle', 'Segi tiga', () => this.addShape('triangle')),
      this.toolBtn('line', 'Garisan', () => this.addShape('line')),
      this.toolBtn('arrow', 'Anak panah', () => this.addShape('arrow')),
      this.toolBtn('star', 'Bintang', () => this.addShape('star')),
      this.toolBtn('check', 'Tanda ✓', () => this.addShape('check'))
    );
    el.appendChild(g2);
    applyIcons(el);
  }
  toolBtn(icon, label, fn) {
    const b = h('button', { class: 'tool-btn', 'data-tool': icon, title: label }, h('span', { class: 'ico', 'data-icon': icon }), h('span', null, label));
    b.addEventListener('click', () => {
      if (!this.hasContent) { toast(this.mode === 'video' ? 'Buka video terlebih dahulu.' : 'Buka gambar terlebih dahulu.', 'warn'); return; }
      fn();
    });
    return b;
  }
  nextName(base) { this.counter[base] = (this.counter[base] || 0) + 1; return base + ' ' + this.counter[base]; }

  placeNew(obj, kindName) {
    const c = this.ensureCanvas();
    const n = this.userObjects().length;
    const off = (n % 6) * 18 * this.unit;
    obj.set({ left: this.workW / 2 + off, top: this.workH / 2 + off, originX: 'center', originY: 'center' });
    obj.mpName = this.nextName(kindName);
    obj.mpStart = 0;
    obj.mpEnd = null;
    c.add(obj);
    c.setActiveObject(obj);
    c.requestRenderAll();
    this.renderProps();
    return obj;
  }

  addText(text, extra) {
    const u = this.unit;
    const t = new fabric.IText(text || 'Teks anda', Object.assign({
      fontFamily: 'Arial', fontSize: Math.round(56 * u), fill: '#ffffff', fontWeight: 'bold',
      stroke: '#000000', strokeWidth: Math.max(1, Math.round(3 * u)), paintFirst: 'stroke', textAlign: 'center',
      shadow: new fabric.Shadow({ color: 'rgba(0,0,0,0.45)', blur: 6 * u, offsetX: 2 * u, offsetY: 2 * u }),
      mpKind: 'text'
    }, extra || {}));
    return this.placeNew(t, 'Teks');
  }

  addEvidenceLabel() {
    const u = this.unit;
    const txt = 'Nama: ____________\nTarikh: ' + todayMY() + '\nAktiviti: ____________';
    const t = new fabric.IText(txt, {
      fontFamily: 'Arial', fontSize: Math.round(34 * u), fill: '#1a2233', fontWeight: 'bold', textAlign: 'left',
      backgroundColor: 'rgba(255,255,255,0.85)', lineHeight: 1.25, mpKind: 'text', strokeWidth: 0
    });
    const o = this.placeNew(t, 'Label');
    o.set({ left: o.getScaledWidth() / 2 + 24 * u, top: this.workH - o.getScaledHeight() / 2 - 24 * u });
    o.setCoords();
    this.canvas.requestRenderAll();
    this.snapshot();
    return o;
  }

  addShape(kind) {
    const u = this.unit;
    const base = { fill: 'transparent', stroke: '#ffd400', strokeWidth: Math.max(2, Math.round(6 * u)), strokeUniform: true, mpKind: kind, strokeLineJoin: 'round', strokeLineCap: 'round' };
    const S = Math.round(Math.min(this.workW, this.workH) * 0.3);
    let o, name;
    switch (kind) {
      case 'rect': o = new fabric.Rect(Object.assign({ width: S * 1.3, height: S }, base)); name = 'Segi empat'; break;
      case 'roundrect': o = new fabric.Rect(Object.assign({ width: S * 1.3, height: S, rx: S * 0.15, ry: S * 0.15 }, base)); name = 'Segi empat'; break;
      case 'circle': o = new fabric.Ellipse(Object.assign({ rx: S / 2, ry: S / 2 }, base)); name = 'Bulatan'; break;
      case 'triangle': o = new fabric.Triangle(Object.assign({ width: S, height: S * 0.9 }, base)); name = 'Segi tiga'; break;
      case 'line': o = new fabric.Line([0, 0, S * 1.4, 0], Object.assign({}, base, { fill: '#ffd400' })); name = 'Garisan'; break;
      case 'arrow': {
        const L = S * 1.4, hd = Math.max(18 * u, S * 0.18);
        o = new fabric.Path(`M 0 0 L ${L} 0 M ${L - hd} ${-hd * 0.7} L ${L} 0 L ${L - hd} ${hd * 0.7}`, Object.assign({}, base, { fill: '' }));
        name = 'Anak panah'; break;
      }
      case 'star': {
        const pts = [];
        for (let i = 0; i < 10; i++) {
          const r = i % 2 === 0 ? S / 2 : S / 4.6;
          const a = -Math.PI / 2 + i * Math.PI / 5;
          pts.push({ x: Math.cos(a) * r, y: Math.sin(a) * r });
        }
        o = new fabric.Polygon(pts, Object.assign({}, base, { fill: '#ffd400', stroke: '#ff9500' }));
        name = 'Bintang'; break;
      }
      case 'check': {
        o = new fabric.Path(`M 0 ${S * 0.5} L ${S * 0.35} ${S * 0.85} L ${S} 0`, Object.assign({}, base, { fill: '', stroke: '#34c759', strokeWidth: Math.max(4, Math.round(14 * u)) }));
        name = 'Tanda'; break;
      }
      default: return null;
    }
    return this.placeNew(o, name);
  }

  /* ------------------------------ tindakan ------------------------------ */
  active() { return this.canvas ? this.canvas.getActiveObject() : null; }
  deleteActive() {
    const a = this.active();
    if (!a || (a.isEditing)) return;
    const objs = a.type === 'activeSelection' ? a.getObjects() : [a];
    this.canvas.discardActiveObject();
    this.restoring = true;
    objs.forEach((o) => this.canvas.remove(o));
    this.restoring = false;
    this.snapshot();
    this.canvas.requestRenderAll();
    this.renderProps(); this.renderLayers();
  }
  duplicateActive() {
    const a = this.active();
    if (!a || a.type === 'activeSelection') return;
    a.clone((cl) => {
      cl.set({ left: a.left + 24 * this.unit, top: a.top + 24 * this.unit });
      EXTRA_PROPS.forEach((k) => { cl[k] = a[k]; });
      cl.mpName = this.nextName((a.mpName || 'Objek').replace(/\s\d+$/, ''));
      this.canvas.add(cl);
      this.canvas.setActiveObject(cl);
      this.canvas.requestRenderAll();
      this.renderProps();
    }, EXTRA_PROPS);
  }
  bring(dir) {
    const a = this.active();
    if (!a) return;
    if (dir > 0) this.canvas.bringForward(a); else this.canvas.sendBackwards(a);
    this.snapshot();
    this.canvas.requestRenderAll();
    this.renderLayers();
  }
  nudge(dx, dy) {
    const a = this.active();
    if (!a || a.isEditing) return false;
    a.set({ left: a.left + dx, top: a.top + dy });
    a.setCoords();
    this.canvas.requestRenderAll();
    this.snapshotDebounced();
    return true;
  }
  snapshotDebounced() {
    clearTimeout(this._sd);
    this._sd = setTimeout(() => this.snapshot(), 350);
  }

  handleKey(e) {
    if (!this.canvas) return false;
    const tag = (document.activeElement && document.activeElement.tagName) || '';
    const inField = ['INPUT', 'TEXTAREA', 'SELECT'].includes(tag);
    const a = this.active();
    if (a && a.isEditing) return false;
    const k = e.key.toLowerCase();
    if ((e.ctrlKey || e.metaKey) && k === 'z' && !inField) { e.preventDefault(); e.shiftKey ? this.redo() : this.undo(); return true; }
    if ((e.ctrlKey || e.metaKey) && k === 'y' && !inField) { e.preventDefault(); this.redo(); return true; }
    if ((e.ctrlKey || e.metaKey) && k === 'd' && !inField) { e.preventDefault(); this.duplicateActive(); return true; }
    if (inField) return false;
    if ((k === 'delete' || k === 'backspace') && a) { e.preventDefault(); this.deleteActive(); return true; }
    const step = (e.shiftKey ? 10 : 1) * Math.max(1, this.unit);
    if (k === 'arrowleft') return this.nudge(-step, 0) && (e.preventDefault(), true);
    if (k === 'arrowright') return this.nudge(step, 0) && (e.preventDefault(), true);
    if (k === 'arrowup') return this.nudge(0, -step) && (e.preventDefault(), true);
    if (k === 'arrowdown') return this.nudge(0, step) && (e.preventDefault(), true);
    return false;
  }

  /* ------------------------------ panel sifat ------------------------------ */
  renderProps() {
    const el = this.opts.propsEl;
    el.innerHTML = '';
    const a = this.active();
    el.appendChild(h('div', { class: 'panel-title' }, 'Sifat Objek'));
    if (!a) {
      el.appendChild(h('div', { class: 'props-empty' }, this.hasContent ? 'Pilih teks atau bentuk untuk mengedit sifatnya. Klik dua kali pada teks untuk menaip terus.' : 'Tiada objek.'));
    } else if (a.type === 'activeSelection') {
      el.appendChild(h('div', { class: 'props-empty' }, a.getObjects().length + ' objek dipilih.'));
      el.appendChild(iconBtn('trash', 'Padam', 'btn-danger btn-sm btn-block', () => this.deleteActive()));
    } else {
      this.buildObjectProps(el, a);
    }
    el.appendChild(h('div', { class: 'panel-title' }, 'Lapisan'));
    el.appendChild(h('div', { class: 'layer-list', id: this.opts.propsEl.id + '-layers' }));
    this.renderLayers();
    applyIcons(el);
  }

  renderLayers() {
    const list = document.getElementById(this.opts.propsEl.id + '-layers');
    if (!list || !this.canvas) return;
    list.innerHTML = '';
    const objs = this.userObjects().slice().reverse();
    if (!objs.length) { list.appendChild(h('div', { class: 'muted small' }, 'Belum ada lapisan.')); return; }
    const act = this.active();
    const sel = act ? (act.type === 'activeSelection' ? act.getObjects() : [act]) : [];
    for (const o of objs) {
      const label = o.mpKind === 'text' || o.type === 'i-text' ? (o.text || '').split('\n')[0].slice(0, 22) || o.mpName : o.mpName || o.type;
      let timeLbl = '';
      if (this.mode === 'video') timeLbl = formatTime(o.mpStart || 0, false) + '–' + (o.mpEnd == null ? 'akhir' : formatTime(o.mpEnd, false));
      const row = h('div', { class: 'layer' + (sel.includes(o) ? ' sel' : '') },
        h('span', { class: 'ico', 'data-icon': o.mpKind === 'text' || o.type === 'i-text' ? 'text' : (o.mpKind === 'circle' ? 'circle' : o.mpKind || 'rect') }),
        h('span', null, label),
        timeLbl ? h('small', { class: 'muted' }, timeLbl) : null);
      row.addEventListener('click', () => { this.canvas.setActiveObject(o); this.canvas.requestRenderAll(); this.renderProps(); });
      list.appendChild(row);
    }
    applyIcons(list);
  }

  syncPropsValues() {
    const a = this.active();
    if (!a) return;
    this.opts.propsEl.querySelectorAll('[data-k]').forEach((inp) => {
      const k = inp.dataset.k;
      if (k === 'text' && document.activeElement !== inp) inp.value = a.text || '';
    });
    this.renderLayers();
  }

  buildObjectProps(el, o) {
    const self = this;
    const set = (props) => {
      o.set(props);
      if (o.type === 'i-text') o.initDimensions && o.initDimensions();
      o.setCoords();
      self.canvas.requestRenderAll();
      self.snapshotDebounced();
      self.renderLayers();
    };
    const colorField = (label, key, allowNone) => {
      const wrap = h('div', { class: 'field' }, h('span', null, label));
      const cur = o[key];
      const isNone = !cur || cur === 'transparent' || cur === '';
      const inp = h('input', { type: 'color', value: toHex(isNone ? '#ffffff' : cur) });
      const swatches = h('div', { class: 'swatches' });
      for (const c of QUICK_COLORS) {
        const s = h('button', { class: 'swatch', title: c, style: { background: c } });
        s.addEventListener('click', () => { inp.value = c; if (noneChk) noneChk.checked = false; set({ [key]: c }); });
        swatches.appendChild(s);
      }
      let noneChk = null;
      inp.addEventListener('input', () => { if (noneChk) noneChk.checked = false; set({ [key]: inp.value }); });
      wrap.append(inp, swatches);
      if (allowNone) {
        noneChk = h('input', { type: 'checkbox' });
        noneChk.checked = isNone;
        noneChk.addEventListener('change', () => set({ [key]: noneChk.checked ? (key === 'fill' ? 'transparent' : '') : inp.value }));
        wrap.appendChild(h('label', { class: 'check' }, noneChk, allowNone));
      }
      return wrap;
    };
    const rangeField = (label, min, max, step, get, apply, fmt) => {
      const out = h('output', null, fmt ? fmt(get()) : String(get()));
      const inp = h('input', { type: 'range', min, max, step, value: get() });
      inp.addEventListener('input', () => { const v = parseFloat(inp.value); out.textContent = fmt ? fmt(v) : String(v); apply(v); });
      return h('label', { class: 'field' }, h('span', null, label, ' ', out), inp);
    };
    const u = this.unit;
    const isText = o.type === 'i-text' || o.type === 'textbox' || o.type === 'text';

    el.appendChild(h('div', { class: 'muted small' }, o.mpName || ''));
    if (isText) {
      const ta = h('textarea', { class: 'input', rows: 3, 'data-k': 'text', style: { resize: 'vertical' } });
      ta.value = o.text;
      ta.addEventListener('input', () => set({ text: ta.value }));
      el.appendChild(h('label', { class: 'field' }, h('span', null, 'Teks'), ta));
      const fontSel = h('select', null, ...FONT_LIST.map((f) => h('option', { value: f, selected: o.fontFamily === f }, f)));
      fontSel.addEventListener('change', () => set({ fontFamily: fontSel.value }));
      el.appendChild(h('label', { class: 'field' }, h('span', null, 'Fon'), fontSel));
      el.appendChild(rangeField('Saiz', 8, Math.round(300 * u) || 300, 1, () => Math.round(o.fontSize * (o.scaleY || 1)), (v) => set({ fontSize: v, scaleX: 1, scaleY: 1 })));
      const tg = (label, on, fn) => { const b = h('button', { class: 'toggle' + (on ? ' on' : '') }, label); b.addEventListener('click', () => { b.classList.toggle('on'); fn(b.classList.contains('on')); }); return b; };
      el.appendChild(h('div', { class: 'props-row' },
        tg('B', o.fontWeight === 'bold', (v) => set({ fontWeight: v ? 'bold' : 'normal' })),
        tg('I', o.fontStyle === 'italic', (v) => set({ fontStyle: v ? 'italic' : 'normal' })),
        tg('U', !!o.underline, (v) => set({ underline: v })),
        ...['left', 'center', 'right'].map((al) => {
          const b = h('button', { class: 'toggle' + (o.textAlign === al ? ' on' : ''), title: 'Jajar ' + al }, al === 'left' ? '⟸' : al === 'center' ? '≡' : '⟹');
          b.addEventListener('click', () => { b.parentElement.querySelectorAll('[title^="Jajar"]').forEach((x) => x.classList.remove('on')); b.classList.add('on'); set({ textAlign: al }); });
          return b;
        })));
      el.appendChild(colorField('Warna teks', 'fill'));
      el.appendChild(colorField('Warna garis luar', 'stroke', 'Tiada garis luar'));
      el.appendChild(rangeField('Tebal garis luar', 0, Math.max(10, Math.round(12 * u)), 0.5, () => o.strokeWidth || 0, (v) => set({ strokeWidth: v })));
      el.appendChild(colorField('Latar teks', 'backgroundColor', 'Tiada latar'));
      const sh = h('input', { type: 'checkbox' }); sh.checked = !!o.shadow;
      sh.addEventListener('change', () => set({ shadow: sh.checked ? new fabric.Shadow({ color: 'rgba(0,0,0,0.5)', blur: 6 * u, offsetX: 2 * u, offsetY: 2 * u }) : null }));
      el.appendChild(h('label', { class: 'check' }, sh, 'Bayang'));
    } else {
      const isLine = o.type === 'line' || o.mpKind === 'arrow' || o.mpKind === 'check' || o.mpKind === 'line';
      el.appendChild(colorField('Warna garisan', 'stroke'));
      el.appendChild(rangeField('Tebal garisan', 1, Math.max(40, Math.round(40 * u)), 1, () => o.strokeWidth || 0, (v) => set({ strokeWidth: v })));
      if (!isLine) el.appendChild(colorField('Warna isi', 'fill', 'Tiada isi (lut sinar)'));
      if (o.type === 'rect') {
        el.appendChild(rangeField('Bucu bulat', 0, Math.round(Math.min(o.width, o.height) / 2), 1, () => o.rx || 0, (v) => set({ rx: v, ry: v })));
      }
      const dash = h('input', { type: 'checkbox' }); dash.checked = !!(o.strokeDashArray && o.strokeDashArray.length);
      dash.addEventListener('change', () => { const w = o.strokeWidth || 4; set({ strokeDashArray: dash.checked ? [w * 2.5, w * 1.6] : null }); });
      el.appendChild(h('label', { class: 'check' }, dash, 'Garis putus-putus'));
    }
    el.appendChild(rangeField('Kelegapan', 10, 100, 1, () => Math.round((o.opacity == null ? 1 : o.opacity) * 100), (v) => set({ opacity: v / 100 }), (v) => v + '%'));
    el.appendChild(rangeField('Putaran', -180, 180, 1, () => Math.round(o.angle > 180 ? o.angle - 360 : o.angle || 0), (v) => set({ angle: v }), (v) => v + '°'));

    if (this.mode === 'video') {
      el.appendChild(h('div', { class: 'panel-title' }, 'Masa Paparan'));
      const dur = this.duration || 0;
      const sIn = h('input', { type: 'number', min: 0, step: 0.1, value: (o.mpStart || 0).toFixed(1) });
      const eIn = h('input', { type: 'number', min: 0, step: 0.1, value: o.mpEnd == null ? dur.toFixed(1) : o.mpEnd.toFixed(1) });
      const applyT = () => {
        let s = clamp(parseFloat(sIn.value) || 0, 0, dur);
        let e = clamp(parseFloat(eIn.value) || dur, 0, dur);
        if (e <= s) e = Math.min(dur, s + 0.5);
        o.mpStart = s; o.mpEnd = e >= dur - 0.05 ? null : e;
        self.snapshot(); self.renderLayers();
        if (self.opts.onTimeChange) self.opts.onTimeChange();
      };
      sIn.addEventListener('change', applyT); eIn.addEventListener('change', applyT);
      const now = () => (this.opts.getTime ? this.opts.getTime() : 0);
      el.appendChild(h('div', { class: 'row2' },
        h('label', { class: 'field' }, 'Mula (s)', sIn),
        h('label', { class: 'field' }, 'Tamat (s)', eIn)));
      el.appendChild(h('div', { class: 'row2' },
        iconBtn('clock', 'Mula di sini', 'btn-ghost btn-sm', () => { sIn.value = now().toFixed(1); applyT(); }),
        iconBtn('clock', 'Tamat di sini', 'btn-ghost btn-sm', () => { eIn.value = now().toFixed(1); applyT(); })));
      el.appendChild(iconBtn('eye', 'Papar sepanjang video', 'btn-ghost btn-sm btn-block', () => { sIn.value = '0'; eIn.value = dur.toFixed(1); applyT(); }));
    }

    el.appendChild(h('div', { class: 'panel-title' }, 'Tindakan'));
    el.appendChild(h('div', { class: 'props-row' },
      iconBtn('up', '', 'btn-ghost btn-sm', () => this.bring(1), 'Bawa ke hadapan'),
      iconBtn('down', '', 'btn-ghost btn-sm', () => this.bring(-1), 'Hantar ke belakang'),
      iconBtn('copy', 'Salin', 'btn-ghost btn-sm', () => this.duplicateActive(), 'Salin (Ctrl+D)'),
      iconBtn('trash', 'Padam', 'btn-danger btn-sm', () => this.deleteActive(), 'Padam (Delete)')));
  }

  /* ------------------------------ eksport ------------------------------ */
  /** Render objek tertentu sahaja ke PNG (latar lut sinar) pada resolusi sasaran. */
  renderObjectsPng(objs, multiplier) {
    const c = this.canvas;
    c.discardActiveObject();
    const all = this.userObjects();
    const saved = all.map((o) => o.visible);
    const bg = c.backgroundImage; const bgc = c.backgroundColor;
    c.backgroundImage = null; c.backgroundColor = null;
    all.forEach((o) => { o.visible = objs.includes(o); });
    const url = c.toDataURL({ format: 'png', multiplier });
    all.forEach((o, i) => { o.visible = saved[i]; });
    c.backgroundImage = bg; c.backgroundColor = bgc;
    c.requestRenderAll();
    return url;
  }
}

function toHex(c) {
  if (!c) return '#000000';
  if (/^#[0-9a-f]{6}$/i.test(c)) return c;
  if (/^#[0-9a-f]{3}$/i.test(c)) return '#' + c.slice(1).split('').map((x) => x + x).join('');
  try {
    const col = new fabric.Color(c);
    return '#' + col.toHex();
  } catch (_) { return '#000000'; }
}
