'use strict';
/* MyEviden PWA: daftar service worker (luar talian) & panduan pasang untuk iPhone/iPad. */
(function () {
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').then((reg) => {
        window.__swReg = reg;
        reg.addEventListener('updatefound', () => {
          const nw = reg.installing;
          nw && nw.addEventListener('statechange', () => {
            if (nw.state === 'installed' && navigator.serviceWorker.controller && window.toast) {
              toast('Versi baharu MyEviden tersedia. Tekan Refresh untuk mengemas kini.', 'ok', 'Kemas kini');
            }
          });
        });
      }).catch((e) => console.warn('SW', e));
    });
  }
  // minta storan kekal (kurangkan risiko fail dipadam oleh pelayar)
  if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});

  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const standalone = window.navigator.standalone === true || window.matchMedia('(display-mode: standalone)').matches;
  let deferred = null;
  window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferred = e; show(); });

  function show() {
    if (standalone) return;
    try { if (localStorage.getItem('mypapr:installHide') === '1') return; } catch (_) { /* abaikan */ }
    if (document.getElementById('installBar')) return;
    const bar = document.createElement('div');
    bar.id = 'installBar';
    bar.className = 'install-bar card';
    const ios = isIOS && !deferred;
    bar.innerHTML = '<img src="icons/icon-192.png" alt=""><div class="ib-text"><b>Pasang MyEviden</b><span></span></div>';
    bar.querySelector('span').innerHTML = ios
      ? 'Tekan <b>Kongsi</b> <span class="ib-share">⬆︎</span> di Safari, kemudian <b>Tambah ke Skrin Utama</b>.'
      : 'Pasang sebagai aplikasi — boleh digunakan tanpa internet.';
    if (!ios) {
      const b = document.createElement('button');
      b.className = 'btn btn-primary btn-sm';
      b.textContent = 'Pasang';
      b.onclick = async () => { if (deferred) { deferred.prompt(); await deferred.userChoice.catch(() => {}); deferred = null; } bar.remove(); };
      bar.appendChild(b);
    }
    const x = document.createElement('button');
    x.className = 'btn btn-ghost btn-sm';
    x.textContent = '✕';
    x.title = 'Tutup';
    x.onclick = () => { try { localStorage.setItem('mypapr:installHide', '1'); } catch (_) { /* abaikan */ } bar.remove(); };
    bar.appendChild(x);
    document.body.appendChild(bar);
  }
  if (isIOS) window.addEventListener('load', () => setTimeout(show, 1500));
})();
