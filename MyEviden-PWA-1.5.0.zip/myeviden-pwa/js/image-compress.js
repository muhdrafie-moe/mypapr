'use strict';
/* Modul: Mampat Gambar (pemprosesan kanvas — pantas & luar talian) */
const ImageCompress = {
  items: [],
  preset: 'recommended',
  running: false,

  init() {
    this.preset = Settings.get('imagePreset') || 'recommended';
    const seg = $('#icPreset');
    const upd = () => {
      $$('button', seg).forEach((b) => b.classList.toggle('on', b.dataset.preset === this.preset));
      $('#icPresetDesc').textContent = IMAGE_PRESETS[this.preset].desc;
    };
    seg.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-preset]');
      if (!b || this.running) return;
      this.preset = b.dataset.preset;
      Settings.set({ imagePreset: this.preset });
      this.resetDone(); upd();
    });
    $('#icFormat').addEventListener('change', () => this.resetDone());
    upd();
    const pick = async () => this.add(await window.api.openFiles({ kind: 'image', title: 'Pilih gambar' }));
    $('#icAdd').addEventListener('click', pick);
    $('#icDrop').addEventListener('click', pick);
    setupDrop($('#icDrop'), 'image', (p) => this.add(p));
    setupDrop($('#view-icompress'), 'image', (p) => this.add(p));
    $('#icClear').addEventListener('click', () => { if (!this.running) { this.items = []; this.render(); } });
    $('#icStart').addEventListener('click', () => this.start());
    this.render();
  },

  resetDone() {
    this.items.forEach((it) => { if (it.status === 'done' || it.status === 'error') { it.status = 'ready'; it.out = null; } });
    this.render();
  },

  async add(paths) {
    if (!paths || !paths.length) return;
    for (const p of paths) {
      if (this.items.some((i) => i.path === p)) continue;
      const fi = await window.api.fileInfo(p);
      this.items.push({ id: uid('i'), path: p, name: baseName(p), size: fi.size, status: 'ready', out: null, dims: null });
    }
    this.render();
  },

  render() {
    const list = $('#icList');
    list.innerHTML = '';
    for (const it of this.items) {
      let status;
      if (it.status === 'done') {
        const pct = Math.round((1 - it.out.size / it.size) * 100);
        status = h('span', { class: 'badge ok' }, `✓ ${formatBytes(it.out.size)} (${pct >= 0 ? '−' + pct : '+' + (-pct)}%)`);
      } else if (it.status === 'running') status = h('span', { class: 'badge run' }, 'Memproses…');
      else if (it.status === 'error') status = h('span', { class: 'badge err', title: it.error }, '✕ Ralat');
      else status = h('span', { class: 'badge' }, 'Sedia');
      const actions = h('div', { class: 'item-actions' });
      if (it.status === 'done') {
        actions.append(
          iconBtn('folder', '', 'btn-ghost btn-sm', () => window.api.showItem(it.out.path), 'Tunjuk dalam folder'),
          iconBtn('download', 'Simpan Sebagai', 'btn-primary btn-sm', () => this.saveAs(it)),
          iconBtn('link', '', 'btn-success btn-sm', () => Share.open(it.out.path), 'Jana URL untuk dikongsi'),
          iconBtn('edit', '', 'btn-ghost btn-sm', () => App.openInImageEditor(it.out.path), 'Edit gambar ini'));
      }
      if (!this.running) actions.append(iconBtn('x', '', 'btn-ghost btn-sm', () => { this.items = this.items.filter((x) => x !== it); this.render(); }, 'Buang'));
      list.appendChild(h('div', { class: 'gcard card' },
        h('img', { src: window.api.mediaUrl(it.status === 'done' ? it.out.path : it.path), loading: 'lazy' }),
        h('div', { class: 'item-name', title: it.path }, it.name),
        h('div', { class: 'item-meta' }, h('span', null, formatBytes(it.size)), it.dims ? h('span', null, it.dims) : null, status),
        actions));
    }
    applyIcons(list);
    $('#icDrop').hidden = this.items.length > 0;
    $('#icStart').disabled = this.running;
  },

  async saveAs(it) {
    if (window.api.saveToPhone) { await phoneSave(it.out.path); return; }
    const ext = extOf(it.out.path);
    const dest = await window.api.saveFile({ name: baseName(it.out.path), filters: [{ name: 'Gambar', extensions: [ext] }] });
    if (!dest) return;
    await window.api.copyFile(it.out.path, dest);
    toast('Disimpan: ' + dest, 'ok');
  },

  /** Mampat satu imej → Uint8Array */
  async compressOne(path, presetKey, format) {
    const p = IMAGE_PRESETS[presetKey];
    const img = await loadImagePath(path);
    const sw = img.naturalWidth, sh = img.naturalHeight;
    const s = Math.min(1, p.maxDim / Math.max(sw, sh));
    const w = Math.max(1, Math.round(sw * s)), hh = Math.max(1, Math.round(sh * s));
    const c = document.createElement('canvas');
    c.width = w; c.height = hh;
    const ctx = c.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    if (format === 'jpeg') { ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, w, hh); }
    ctx.drawImage(img, 0, 0, w, hh);
    let bytes;
    if (format === 'png') {
      // PNG: kurangkan saiz melalui pengurangan resolusi sahaja (lossless)
      bytes = await canvasToBytes(c, 'image/png');
    } else {
      bytes = await canvasToBytes(c, 'image/' + format, p.quality);
    }
    return { bytes, w, h: hh, ow: sw, oh: sh };
  },

  async start() {
    if (this.running) return;
    const queue = this.items.filter((i) => i.status === 'ready' || i.status === 'error');
    if (!queue.length) { toast(this.items.length ? 'Semua gambar telah diproses.' : 'Tambah gambar terlebih dahulu.', 'warn'); return; }
    this.running = true;
    let cancelled = false;
    Progress.show('Memampatkan gambar…', '', () => { cancelled = true; });
    const format = $('#icFormat').value;
    const ext = format === 'jpeg' ? 'jpg' : format;
    let ok = 0, i = 0;
    for (const it of queue) {
      if (cancelled) break;
      i++;
      Progress.set((i - 1) / queue.length * 100, `Gambar ${i}/${queue.length}: ${it.name}`);
      it.status = 'running'; this.render();
      try {
        const r = await this.compressOne(it.path, this.preset, format);
        const out = await outputPath(stripExt(it.name) + '_mampat.' + ext);
        await window.api.writeFile(out, r.bytes);
        it.out = { path: out, size: r.bytes.length };
        it.dims = `${r.ow}×${r.oh} → ${r.w}×${r.h}`;
        it.status = 'done'; ok++;
      } catch (e) {
        it.status = 'error'; it.error = e.message;
      }
      this.render();
    }
    Progress.set(100);
    Progress.hide();
    this.running = false;
    this.render();
    if (ok) toast(`${ok} gambar berjaya dimampatkan.`, 'ok', 'Selesai');
    else if (cancelled) toast('Proses dibatalkan.', 'warn');
  }
};
