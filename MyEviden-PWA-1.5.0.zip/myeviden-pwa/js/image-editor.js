'use strict';
/* Modul: Editor Gambar (teks & bentuk atas gambar) */
const ImageEditor = {
  ed: null,
  src: null,       // laluan fail sumber
  baseName: '',
  natW: 0, natH: 0,

  init() {
    this.ed = new OverlayEditor({
      mode: 'image',
      canvasEl: $('#ieCanvas'), hostEl: $('#ieHost'), stageEl: $('#ieStage'),
      toolsEl: $('#ieTools'), propsEl: $('#ieProps')
    });
    $('#ieOpen').addEventListener('click', async () => {
      const p = await window.api.openFiles({ kind: 'image', multi: false, title: 'Buka gambar' });
      if (p.length) this.open(p[0]);
    });
    $('#ieUndo').addEventListener('click', () => this.ed.undo());
    $('#ieRedo').addEventListener('click', () => this.ed.redo());
    $('#ieExport').addEventListener('click', () => this.exportImage());
    $('#ieShare').addEventListener('click', async () => {
      if (!this.src) { toast('Buka gambar terlebih dahulu.', 'warn'); return; }
      const fmt = $('#ieFormat').value;
      const r = await this.exportImage(await outputPath(this.baseName + '_edit.' + (fmt === 'jpeg' ? 'jpg' : fmt)));
      if (r) Share.open(r);
    });
    setupDrop($('#ieStage'), 'image', (p) => this.open(p[0]));
  },

  async open(path, nameHint) {
    if (this.ed.userObjects().length) {
      const r = await window.api.message({ message: 'Buka gambar baharu?', detail: 'Teks dan bentuk pada gambar semasa akan dibuang.', buttons: ['Buka', 'Batal'] });
      if (r !== 0) return false;
    }
    let img;
    try { img = await loadImagePath(path); } catch (e) { toast('Gagal membuka gambar: ' + e.message, 'err'); return false; }
    this.src = path;
    this.baseName = nameHint || stripExt(baseName(path));
    this.natW = img.naturalWidth; this.natH = img.naturalHeight;
    const s = Math.min(1, 2000 / Math.max(this.natW, this.natH));
    const w = Math.round(this.natW * s), hh = Math.round(this.natH * s);
    $('#ieEmpty').hidden = true;
    this.ed.setSize(w, hh);
    this.ed.clearAll(true);
    const fimg = new fabric.Image(img, { selectable: false, evented: false });
    fimg.scaleX = w / this.natW; fimg.scaleY = hh / this.natH;
    this.ed.canvas.setBackgroundImage(fimg, this.ed.canvas.renderAll.bind(this.ed.canvas));
    this.ed.history = []; this.ed.hIndex = -1; this.ed.counter = {};
    this.ed.snapshot();
    this.ed.renderProps();
    $('#ieInfo').textContent = `${this.natW}×${this.natH}px`;
    const fmt = extOf(path);
    $('#ieFormat').value = fmt === 'png' ? 'png' : fmt === 'webp' ? 'webp' : 'jpeg';
    return true;
  },

  async exportImage(destPath) {
    if (!this.src) { toast('Buka gambar terlebih dahulu.', 'warn'); return null; }
    const fmt = $('#ieFormat').value;
    const ext = fmt === 'jpeg' ? 'jpg' : fmt;
    let dest = destPath;
    if (!dest) {
      dest = await window.api.saveFile({ name: this.baseName + '_edit.' + ext, title: 'Simpan gambar', filters: [{ name: fmt.toUpperCase(), extensions: [ext] }] });
      if (!dest) return null;
    }
    const c = this.ed.canvas;
    c.discardActiveObject();
    c.requestRenderAll();
    const mult = this.natW / this.ed.workW;
    if (fmt === 'jpeg') c.backgroundColor = '#ffffff';
    const url = c.toDataURL({ format: fmt, quality: 0.92, multiplier: mult });
    c.backgroundColor = null;
    c.requestRenderAll();
    await window.api.writeFile(dest, dataUrlToBytes(url));
    window.api.library.add(dest);
    toast('Gambar disimpan: ' + dest, 'ok', 'Berjaya');
    return dest;
  }
};
