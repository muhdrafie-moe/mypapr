'use strict';
/*
 * WebVideo — pemprosesan video tanpa ffmpeg (untuk versi Android/APK).
 * Video dimainkan, setiap bingkai dilukis ke kanvas bersama tindanan (teks, bentuk,
 * fokus kepala/muka), kemudian dirakam dengan MediaRecorder (perkakasan telefon).
 * Masa pemprosesan ≈ tempoh video.
 */
const WebVideo = {
  BITRATES: { original: 8e6, normal: 4.5e6, recommended: 2.2e6, max: 0.9e6 },

  supported() {
    return !!(window.MediaRecorder && HTMLCanvasElement.prototype.captureStream);
  },

  pickMime() {
    const c = ['video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4;codecs=avc1.42E01F,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a', 'video/mp4',
      'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
    for (const m of c) { try { if (MediaRecorder.isTypeSupported(m)) return m; } catch (_) { /* abaikan */ } }
    return '';
  },

  /** Maklumat video melalui elemen <video>. */
  probe(url) {
    return new Promise((resolve) => {
      const v = document.createElement('video');
      v.preload = 'metadata'; v.muted = true; v.crossOrigin = 'anonymous';
      const done = (r) => { v.removeAttribute('src'); v.load(); resolve(r); };
      const tm = setTimeout(() => done({ ok: false, error: 'Masa tamat' }), 15000);
      v.onloadedmetadata = () => {
        clearTimeout(tm);
        done({ ok: v.videoWidth > 0, hasVideo: v.videoWidth > 0, duration: v.duration, width: v.videoWidth, height: v.videoHeight, hasAudio: true, rotation: 0, fps: 30 });
      };
      v.onerror = () => { clearTimeout(tm); done({ ok: false, error: 'Format video tidak disokong oleh peranti ini' }); };
      v.src = url;
    });
  },

  /** Saiz output mengikut pratetap (hadkan sisi pendek, dimensi genap). */
  outSize(w, h, preset) {
    const p = VIDEO_PRESETS[preset] || VIDEO_PRESETS.recommended;
    let s = 1;
    if (p.short) s = Math.min(1, p.short / Math.min(w, h));
    return [Math.max(2, Math.round(w * s / 2) * 2), Math.max(2, Math.round(h * s / 2) * 2)];
  },

  /**
   * Render video baharu (satu klip).
   * o: { url, preset, overlay(ctx, t, W, H), onProgress(pct), isCancelled() }
   */
  render(o) {
    return this.renderSequence({ clips: [{ url: o.url, start: 0, end: null }], preset: o.preset, overlay: o.overlay, onProgress: o.onProgress, isCancelled: o.isCancelled });
  },

  loadClip(url) {
    return new Promise((res, rej) => {
      const v = document.createElement('video');
      v.crossOrigin = 'anonymous'; v.preload = 'auto'; v.playsInline = true;
      v.setAttribute('playsinline', '');
      v.onloadeddata = () => res(v);
      v.onerror = () => rej(new Error('Video tidak dapat dibuka.'));
      v.src = url;
    });
  },

  /**
   * Potong & gabung beberapa klip menjadi satu video (main balik berturutan + MediaRecorder).
   * o: { clips:[{url,start,end}], preset, overlay(ctx,tKlip,W,H)?, onProgress(pct), isCancelled() }
   * Saiz output ikut klip pertama; klip lain dimuatkan (letterbox) dengan latar hitam.
   */
  async renderSequence(o) {
    if (!this.supported()) throw new Error('Peranti ini tidak menyokong pemprosesan video.');
    const mime = this.pickMime();
    const vids = [];
    for (const c of o.clips) vids.push(await this.loadClip(c.url));
    const segs = o.clips.map((c, i) => {
      const d = vids[i].duration;
      const s = clamp(c.start || 0, 0, d), e = clamp(c.end == null ? d : c.end, s, d);
      return { v: vids[i], s, e, len: Math.max(0, e - s) };
    }).filter((g) => g.len > 0.05);
    if (!segs.length) throw new Error('Tiada bahagian video untuk diproses.');
    const total = segs.reduce((a, g) => a + g.len, 0);
    const [W, H] = this.outSize(vids[0].videoWidth, vids[0].videoHeight, o.preset);
    const cv = document.createElement('canvas');
    cv.width = W; cv.height = H;
    const ctx = cv.getContext('2d');
    const fps = Math.min(30, (VIDEO_PRESETS[o.preset] || {}).fps || 30);
    const stream = cv.captureStream(fps);
    let actx = null;
    try {
      actx = new (window.AudioContext || window.webkitAudioContext)();
      const dest = actx.createMediaStreamDestination();
      for (const g of segs) { try { actx.createMediaElementSource(g.v).connect(dest); } catch (_) { g.v.muted = true; } }
      dest.stream.getAudioTracks().forEach((t) => stream.addTrack(t));
      if (actx.state === 'suspended') await actx.resume().catch(() => {});
    } catch (_) { segs.forEach((g) => { g.v.muted = true; }); }
    const rec = new MediaRecorder(stream, Object.assign({ videoBitsPerSecond: this.BITRATES[o.preset] || 2.2e6, audioBitsPerSecond: 128000 }, mime ? { mimeType: mime } : {}));
    const chunks = [];
    rec.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
    const stopped = new Promise((r) => { rec.onstop = r; });
    const drawFrame = (v, t) => {
      const vw = v.videoWidth, vh = v.videoHeight;
      if (vw === W && vh === H) ctx.drawImage(v, 0, 0, W, H);
      else {
        ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
        const sc = Math.min(W / vw, H / vh), dw = vw * sc, dh = vh * sc;
        ctx.drawImage(v, (W - dw) / 2, (H - dh) / 2, dw, dh);
      }
      if (o.overlay) o.overlay(ctx, t, W, H);
    };
    let cancelled = false;
    let done = 0;
    for (let i = 0; i < segs.length && !cancelled; i++) {
      const g = segs[i];
      const v = g.v;
      await new Promise((r) => { v.onseeked = r; v.currentTime = g.s; });
      drawFrame(v, g.s);
      if (i === 0) rec.start(1000); else if (rec.state === 'paused') rec.resume();
      await new Promise((resolve) => {
        let fin = false;
        const useRVFC = typeof v.requestVideoFrameCallback === 'function';
        const end = () => { if (fin) return; fin = true; v.pause(); resolve(); };
        const onFrame = (now, meta) => {
          if (fin) return;
          const t = meta && meta.mediaTime != null ? meta.mediaTime : v.currentTime;
          if (t >= g.e - 0.001) { end(); return; }
          drawFrame(v, t);
          if (o.onProgress) o.onProgress(Math.min(99, (done + Math.max(0, t - g.s)) / total * 100));
          if (o.isCancelled && o.isCancelled()) { cancelled = true; end(); return; }
          if (useRVFC) v.requestVideoFrameCallback(onFrame); else requestAnimationFrame(() => onFrame(0, null));
        };
        v.onended = end;
        // pemasa sandaran untuk penghujung potongan
        const iv = setInterval(() => { if (fin) clearInterval(iv); else if (v.currentTime >= g.e - 0.001) { clearInterval(iv); end(); } }, 30);
        if (useRVFC) v.requestVideoFrameCallback(onFrame); else requestAnimationFrame(() => onFrame(0, null));
        v.play().catch(() => { v.muted = true; v.play().catch(end); });
      });
      done += g.len;
      if (i < segs.length - 1 && rec.state === 'recording') rec.pause();
    }
    await new Promise((r) => setTimeout(r, 200));
    try { rec.stop(); } catch (_) { /* abaikan */ }
    await stopped;
    for (const g of segs) { g.v.pause(); g.v.removeAttribute('src'); g.v.load(); }
    stream.getTracks().forEach((t) => t.stop());
    if (actx) actx.close().catch(() => {});
    if (cancelled) return null;
    const type = (rec.mimeType || mime || 'video/webm').split(';')[0];
    if (o.onProgress) o.onProgress(100);
    return { blob: new Blob(chunks, { type }), ext: type.includes('mp4') ? 'mp4' : 'webm', mime: type, width: W, height: H, duration: total };
  }
};

/** Adakah platform ini mempunyai ffmpeg (versi Windows)? */
function hasFfmpeg() { return !!(window.api && window.api.ffmpeg && window.api.ffmpeg.run); }
