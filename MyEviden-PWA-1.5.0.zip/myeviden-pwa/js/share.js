'use strict';
/*
 * Modul: Jana Pautan (URL) — muat naik video/gambar ke pelayan awam supaya boleh
 * dimainkan di mana-mana peranti apabila pautan ditekan. MEMERLUKAN INTERNET.
 */
const Share = {
  path: null,
  jobId: null,
  url: null,

  init() {
    $('#shClose').addEventListener('click', () => this.close());
    $$('#shareModal .share-opt').forEach((lab) => lab.addEventListener('click', () => {
      $$('#shareModal .share-opt').forEach((x) => x.classList.toggle('on', x === lab));
      lab.querySelector('input').checked = true;
    }));
    $('#shAgree').addEventListener('change', () => { $('#shGo').disabled = !$('#shAgree').checked; });
    $('#shGo').addEventListener('click', () => this.go());
    $('#shCancel').addEventListener('click', () => { if (this.jobId) window.api.share.cancel(this.jobId); });
    $('#shCopy').addEventListener('click', async () => { await window.api.copyText(this.url); toast('Pautan disalin ke papan klip.', 'ok'); });
    $('#shOpen').addEventListener('click', () => window.api.openExternal(this.url));
    $('#shSaveQr').addEventListener('click', () => this.saveQr());
    window.api.share.onProgress((d) => {
      if (d.jobId !== this.jobId) return;
      $('#shBar').style.width = d.percent.toFixed(1) + '%';
      $('#shPct').textContent = Math.round(d.percent) + '%';
      $('#shRunText').textContent = `Memuat naik… ${formatBytes(d.sent)} / ${formatBytes(d.total)}`;
    });
  },

  state(which) {
    $('#shSetup').hidden = which !== 'setup';
    $('#shRun').hidden = which !== 'run';
    $('#shDone').hidden = which !== 'done';
  },

  /** Buka dialog jana URL untuk satu fail. */
  async open(path) {
    if (!path) return;
    const fi = await window.api.fileInfo(path);
    if (!fi.ok) { toast('Fail tidak dijumpai: ' + path, 'err'); return; }
    this.path = path;
    this.url = null;
    $('#shFile').innerHTML = '';
    $('#shFile').append(h('b', null, fi.name), h('span', { class: 'muted' }, ' • ' + formatBytes(fi.size)));
    $('#shAgree').checked = false;
    $('#shGo').disabled = true;
    $('#shBar').style.width = '0%';
    this.state('setup');
    $('#shareModal').hidden = false;
    applyIcons($('#shareModal'));
  },
  close() {
    if (this.jobId) { toast('Muat naik masih berjalan — tekan Batal dahulu.', 'warn'); return; }
    $('#shareModal').hidden = true;
  },

  async go(forceOpts) {
    if (!this.path || this.jobId) return;
    const service = (forceOpts && forceOpts.service) || ($('#shareModal input[name="shSvc"]:checked') || {}).value || 'litterbox';
    const time = (forceOpts && forceOpts.time) || $('#shTime').value;
    this.jobId = uid('up');
    this.state('run');
    $('#shRunText').textContent = 'Menyambung ke pelayan…';
    let r;
    try { r = await window.api.share.upload(this.jobId, this.path, { service, time }); } finally { this.jobId = null; }
    if (!r.ok) {
      this.state('setup');
      if (r.cancelled) toast('Muat naik dibatalkan.', 'warn');
      else toast(r.error || 'Muat naik gagal.', 'err', 'Gagal menjana URL');
      return null;
    }
    this.url = r.url;
    const hours = { '1h': 1, '12h': 12, '24h': 24, '72h': 72 }[time] || 72;
    const expires = service === 'litterbox' ? Date.now() + hours * 3600e3 : null;
    await window.api.library.add(this.path);
    await window.api.library.addLink({ path: this.path, name: baseName(this.path), url: r.url, service, expires });
    $('#shUrl').value = r.url;
    $('#shExp').textContent = expires ? 'Luput: ' + new Date(expires).toLocaleString('ms-MY') : 'Pautan kekal (tiada tarikh luput)';
    this.drawQr(r.url, $('#shQr'));
    this.state('done');
    if (window.Gallery && App.view === 'gallery') Gallery.load();
    return r.url;
  },

  drawQr(text, canvas) {
    const qr = qrcode(0, 'M');
    qr.addData(text);
    qr.make();
    const n = qr.getModuleCount();
    const quiet = 2;
    const cell = Math.floor(canvas.width / (n + quiet * 2));
    const off = Math.floor((canvas.width - cell * n) / 2);
    const g = canvas.getContext('2d');
    g.fillStyle = '#ffffff'; g.fillRect(0, 0, canvas.width, canvas.height);
    g.fillStyle = '#000000';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (qr.isDark(r, c)) g.fillRect(off + c * cell, off + r * cell, cell, cell);
  },

  async saveQr() {
    const c = document.createElement('canvas');
    c.width = c.height = 800;
    this.drawQr(this.url, c);
    const dest = await window.api.saveFile({ name: 'QR_' + stripExt(baseName(this.path)) + '.png', title: 'Simpan kod QR', filters: [{ name: 'PNG', extensions: ['png'] }] });
    if (!dest) return;
    await window.api.writeFile(dest, await canvasToBytes(c, 'image/png'));
    toast('Kod QR disimpan: ' + dest, 'ok');
  }
};
