'use strict';
/* Utiliti am MyEviden */
const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'dataset') Object.assign(el.dataset, v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    el.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
  }
  return el;
}

function iconBtn(icon, label, cls, onclick, title) {
  const b = h('button', { class: 'btn ' + (cls || 'btn-ghost btn-sm'), title: title || label || '' });
  b.appendChild(h('span', { class: 'ico', 'data-icon': icon }));
  if (label) b.appendChild(h('span', null, label));
  if (onclick) b.addEventListener('click', onclick);
  applyIcons(b);
  return b;
}

function formatBytes(n) {
  if (n == null || isNaN(n)) return '-';
  if (n < 1024) return n + ' B';
  const u = ['KB', 'MB', 'GB'];
  let i = -1;
  do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
  return n.toFixed(n >= 100 ? 0 : n >= 10 ? 1 : 2) + ' ' + u[i];
}
function formatTime(s, withTenth) {
  if (!isFinite(s) || s < 0) s = 0;
  const m = Math.floor(s / 60);
  const sec = s - m * 60;
  const ss = withTenth === false ? String(Math.floor(sec)).padStart(2, '0') : sec.toFixed(1).padStart(4, '0');
  return String(m).padStart(2, '0') + ':' + ss;
}
function uid(prefix) { return (prefix || 'id') + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7); }
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
function debounce(fn, ms) { let t; return function (...a) { clearTimeout(t); t = setTimeout(() => fn.apply(this, a), ms); }; }

function baseName(p) { return String(p).split(/[\\/]/).pop(); }
function stripExt(name) { const i = name.lastIndexOf('.'); return i > 0 ? name.slice(0, i) : name; }
function extOf(name) { const i = name.lastIndexOf('.'); return i > 0 ? name.slice(i + 1).toLowerCase() : ''; }
function safeName(name) { return String(name).replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').trim() || 'fail'; }
const IMAGE_EXTS = ['jpg', 'jpeg', 'jfif', 'png', 'webp', 'bmp', 'gif', 'avif'];
const VIDEO_EXTS = ['mp4', 'mov', 'm4v', 'avi', 'mkv', 'webm', '3gp', 'wmv', 'mts', 'm2ts', 'flv', 'mpg', 'mpeg'];
function isImagePath(p) { return IMAGE_EXTS.includes(extOf(p)); }
function isVideoPath(p) { return VIDEO_EXTS.includes(extOf(p)); }
function timestamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
function todayMY() {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
}

/* --------- tetapan (cache) --------- */
const Settings = {
  data: null,
  async load() { this.data = await window.api.getSettings(); return this.data; },
  async set(patch) { this.data = await window.api.setSettings(patch); return this.data; },
  get(k) { return this.data ? this.data[k] : undefined; }
};

async function outputPath(fileName) {
  const dir = Settings.get('outDir');
  await window.api.ensureDir(dir);
  return window.api.uniquePath(await window.api.join(dir, safeName(fileName)));
}

/* --------- toast --------- */
function toast(msg, type, title) {
  const box = $('#toasts');
  const t = h('div', { class: 'toast ' + (type || '') });
  if (title) t.appendChild(h('b', null, title));
  t.appendChild(h('div', null, msg));
  box.appendChild(t);
  setTimeout(() => { t.style.transition = 'opacity .3s'; t.style.opacity = '0'; setTimeout(() => t.remove(), 320); }, type === 'err' ? 7000 : 3800);
}

/* --------- modal kemajuan --------- */
const Progress = {
  onCancel: null,
  show(title, text, onCancel) {
    $('#pmTitle').textContent = title || 'Sedang diproses…';
    $('#pmText').textContent = text || '';
    this.set(0);
    this.onCancel = onCancel || null;
    $('#pmCancel').hidden = !onCancel;
    $('#progressModal').hidden = false;
  },
  set(pct, text) {
    pct = clamp(pct || 0, 0, 100);
    $('#pmBar').style.width = pct.toFixed(1) + '%';
    $('#pmPct').textContent = Math.round(pct) + '%';
    if (text != null) $('#pmText').textContent = text;
  },
  hide() { $('#progressModal').hidden = true; this.onCancel = null; },
  get visible() { return !$('#progressModal').hidden; }
};

/* --------- muat imej dari laluan --------- */
function loadImageUrl(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.decoding = 'async';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Gagal membuka gambar'));
    img.src = url;
  });
}
function loadImagePath(p) { return loadImageUrl(window.api.mediaUrl(p)); }

async function canvasToBytes(canvas, mime, quality) {
  const blob = await new Promise((res) => canvas.toBlob(res, mime, quality));
  if (!blob) throw new Error('Gagal menjana fail imej');
  return new Uint8Array(await blob.arrayBuffer());
}
function dataUrlToBytes(dataUrl) {
  const b64 = dataUrl.split(',')[1];
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

/* --------- seret & lepas --------- */
function setupDrop(el, accept, onPaths) {
  const ok = (p) => accept === 'video' ? isVideoPath(p) : accept === 'image' ? isImagePath(p) : (isVideoPath(p) || isImagePath(p));
  el.addEventListener('dragover', (e) => { if (e.dataTransfer && Array.from(e.dataTransfer.types).includes('Files')) { e.preventDefault(); el.classList.add('over'); } });
  el.addEventListener('dragleave', () => el.classList.remove('over'));
  el.addEventListener('drop', (e) => {
    el.classList.remove('over');
    if (!e.dataTransfer || !e.dataTransfer.files || !e.dataTransfer.files.length) return;
    e.preventDefault();
    const paths = Array.from(e.dataTransfer.files).map((f) => window.api.pathForFile(f)).filter(Boolean);
    const good = paths.filter(ok);
    if (paths.length && !good.length) toast('Jenis fail tidak disokong di sini.', 'warn');
    if (good.length) onPaths(good);
  });
}

/* --------- ffmpeg helper dengan kemajuan --------- */
async function runFfmpegJob(args, opts) {
  opts = opts || {};
  const jobId = uid('ff');
  const off = window.api.ffmpeg.onProgress((d) => { if (d.jobId === jobId && opts.onProgress) opts.onProgress(d.percent, d.time); });
  if (opts.registerCancel) opts.registerCancel(() => window.api.ffmpeg.cancel(jobId));
  try {
    const r = await window.api.ffmpeg.run(jobId, args, { cwd: opts.cwd, duration: opts.duration });
    return r;
  } finally { off(); }
}

function ffmpegErrorText(r) {
  if (!r) return 'Ralat tidak diketahui';
  if (r.error) return r.error;
  const lines = String(r.stderr || '').split(/\r?\n/).filter((l) => l.trim() && !/^\s*(frame=|size=|Stream mapping|Press \[q\])/.test(l));
  return lines.slice(-3).join(' | ') || ('Kod keluar ' + r.code);
}

/* --------- platform --------- */
/** Android: simpan salinan ke Galeri telefon, dengan mesej jelas. */
async function phoneSave(p) {
  const r = await window.api.saveToPhone(p);
  if (r && r.ok) toast(`Disimpan ke Galeri telefon (folder ${r.folder || 'MyEviden'}).`, 'ok', 'Berjaya');
  else toast((r && r.error) || 'Gagal menyimpan ke telefon.', 'err', 'Gagal menyimpan');
  return r;
}
/** Android: kongsi fail (WhatsApp, Drive, dll.), dengan mesej jelas jika gagal. */
async function phoneShare(p) {
  const r = await window.api.shareFile(p);
  if (r && !r.ok) toast(r.error || 'Gagal berkongsi.', 'err', 'Gagal berkongsi');
  return r;
}

/** Maklumat media: ffmpeg (Windows) atau elemen <video> (Android). */
function probeMedia(p) { return hasFfmpeg() ? window.api.ffmpeg.probe(p) : WebVideo.probe(window.api.mediaUrl(p)); }
async function saveBlob(p, blob) { return window.api.writeFile(p, new Uint8Array(await blob.arrayBuffer())); }

/* --------- video thumbnail --------- */
function videoThumb(path, at) {
  return new Promise((resolve) => {
    const v = document.createElement('video');
    v.muted = true; v.preload = 'auto'; v.crossOrigin = 'anonymous';
    let done = false;
    const finish = (url) => { if (done) return; done = true; v.removeAttribute('src'); v.load(); resolve(url); };
    v.onloadeddata = () => { try { v.currentTime = Math.min(at || 1, (v.duration || 2) / 3); } catch (_) { finish(null); } };
    v.onseeked = () => {
      try {
        const c = document.createElement('canvas');
        const sc = 240 / Math.max(1, v.videoWidth);
        c.width = Math.round(v.videoWidth * sc); c.height = Math.round(v.videoHeight * sc);
        c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
        finish(c.toDataURL('image/jpeg', 0.7));
      } catch (_) { finish(null); }
    };
    v.onerror = () => finish(null);
    setTimeout(() => finish(null), 8000);
    v.src = window.api.mediaUrl(path);
  });
}
