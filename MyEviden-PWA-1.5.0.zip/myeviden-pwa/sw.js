'use strict';
/* MyEviden service worker — semua fail aplikasi disimpan untuk kegunaan tanpa internet. */
const CACHE = "mypapr-1.5.0-fae6fc2fac";
const FILES = ["./","css/mobile.css","css/style.css","icons/apple-touch-icon.png","icons/icon-192.png","icons/icon-512.png","icons/maskable-192.png","icons/maskable-512.png","img/logo.svg","index.html","js/app.js","js/collage.js","js/face-tracker.js","js/gallery.js","js/icons.js","js/image-compress.js","js/image-editor.js","js/overlay-editor.js","js/platform-android.js","js/presets.js","js/pwa.js","js/share.js","js/trim.js","js/util.js","js/video-compress.js","js/video-editor.js","js/video-web.js","manifest.webmanifest","models/face_landmark_68_model-weights_manifest.json","models/face_landmark_68_model.bin","models/face_recognition_model-weights_manifest.json","models/face_recognition_model.bin","models/ssd_mobilenetv1_model-weights_manifest.json","models/ssd_mobilenetv1_model.bin","models/tiny_face_detector_model-weights_manifest.json","models/tiny_face_detector_model.bin","vendor/cap/browser.js","vendor/cap/capacitor.js","vendor/cap/clipboard.js","vendor/cap/filesystem.js","vendor/cap/share.js","vendor/cap/synapse-shim.js","vendor/cap/synapse.js","vendor/fabric.min.js","vendor/face-api.js","vendor/qrcode.js","vendor/wasm/tfjs-backend-wasm-simd.wasm","vendor/wasm/tfjs-backend-wasm.wasm"];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k.startsWith('mypapr-') && k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // muat naik / pautan luar terus ke rangkaian
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then((hit) => hit || fetch(req).catch(() => (req.mode === 'navigate' ? caches.match('./index.html') : Response.error())))
  );
});
