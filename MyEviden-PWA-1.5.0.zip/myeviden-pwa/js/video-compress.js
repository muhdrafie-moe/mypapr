'use strict';
/* Modul: Mampat Video */
const VideoCompress = {
  items: [],
  preset: 'recommended',
  running: false,
  cancelFn: null,

  init() {
    this.preset = Settings.get('videoPreset') || 'recommended';
    this.bindSeg();
    $('#vcAdd').addEventListener('click', async () => this.add(await window.api.openFiles({ kind: 'video', title: 'Pilih video' })));
    $('#vcDrop').addEventListener('click', async () => this.add(await window.api.openFiles({ kind: 'video', title: 'Pilih video' })));
    setupDrop($('#vcDrop'), 'video', (p) => this.add(p));
    setupDrop($('#view-vcompress'), 'video', (p) => this.add(p));
    $('#vcClear').addEventListener('click', () => { if (this.running) return; this.items = []; this.render(); });
    $('#vcStart').addEventListener('click', () => this.start());
    this.render();
  },

  bindSeg() {
    const seg = $('#vcPreset');
    const upd = () => {
      $$('button', seg).forEach((b) => b.classList.toggle('on', b.dataset.preset === this.preset));
      $('#vcPresetDesc').textContent = VIDEO_PRESETS[this.preset].desc;
    };
    seg.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-preset]');
      if (!b || this.running) return;
      this.preset = b.dataset.preset;
      Settings.set({ videoPreset: this.preset });
      this.items.forEach((it) => { if (it.status === 'done' || it.status === 'error') { it.status = 'ready'; it.out = null; it.progress = 0; } });
      upd(); this.render();
    });
    upd();
  },

  async add(paths) {
    if (!paths || !paths.length) return;
    for (const p of paths) {
      if (this.items.some((i) => i.path === p)) continue;
      const it = { id: uid('v'), path: p, name: baseName(p), size: 0, info: null, thumb: null, status: 'loading', progress: 0, out: null };
      this.items.push(it);
      this.render();
      const [fi, info] = await Promise.all([window.api.fileInfo(p), probeMedia(p)]);
      it.size = fi.size;
      it.info = info;
      it.status = info.ok && info.hasVideo ? 'ready' : 'error';
      if (it.status === 'error') it.error = 'Bukan fail video yang sah';
      this.render();
      videoThumb(p).then((u) => { it.thumb = u; this.render(); });
    }
  },

  render() {
    const list = $('#vcList');
    list.innerHTML = '';
    if (!this.items.length) { $('#vcDrop').hidden = false; return; }
    for (const it of this.items) {
      const meta = [];
      meta.push('Asal: ' + formatBytes(it.size));
      if (it.info && it.info.ok) meta.push(`${it.info.width}×${it.info.height}`, formatTime(it.info.duration, false), it.info.hasAudio ? 'Ada audio' : 'Tiada audio');
      let status;
      if (it.status === 'done') {
        const pct = it.size ? Math.round((1 - it.out.size / it.size) * 100) : 0;
        status = h('span', { class: 'badge ok' }, `✓ ${formatBytes(it.out.size)} (${pct >= 0 ? '−' + pct : '+' + (-pct)}%)`);
      } else if (it.status === 'running') status = h('span', { class: 'badge run' }, 'Memproses… ' + Math.round(it.progress) + '%');
      else if (it.status === 'error') status = h('span', { class: 'badge err', title: it.error || '' }, '✕ ' + (it.error || 'Ralat').slice(0, 80));
      else if (it.status === 'loading') status = h('span', { class: 'badge' }, 'Membaca…');
      else if (it.status === 'cancelled') status = h('span', { class: 'badge' }, 'Dibatalkan');
      else status = h('span', { class: 'badge' }, 'Sedia');
      const thumb = it.thumb ? h('img', { class: 'thumb', src: it.thumb }) : h('div', { class: 'thumb' });
      const actions = h('div', { class: 'item-actions' });
      if (it.status === 'done') {
        actions.append(
          iconBtn('folder', 'Tunjuk', 'btn-ghost btn-sm', () => window.api.showItem(it.out.path)),
          iconBtn('download', 'Simpan Sebagai', 'btn-primary btn-sm', () => this.saveAs(it)),
          iconBtn('link', 'URL', 'btn-success btn-sm', () => Share.open(it.out.path), 'Jana URL untuk dikongsi'));
      }
      if (!this.running) actions.append(iconBtn('x', '', 'btn-ghost btn-sm', () => { this.items = this.items.filter((x) => x !== it); this.render(); }, 'Buang'));
      const main = h('div', { class: 'item-main' },
        h('div', { class: 'item-name', title: it.path }, it.name),
        h('div', { class: 'item-meta' }, ...meta.map((m) => h('span', null, m)), status),
        h('div', { class: 'progress' }, h('div', { class: 'bar', style: { width: (it.status === 'done' ? 100 : it.progress) + '%' } })));
      list.appendChild(h('div', { class: 'item card', 'data-id': it.id }, thumb, main, actions));
    }
    applyIcons(list);
    $('#vcDrop').hidden = this.items.length > 0;
    $('#vcStart').disabled = this.running;
  },

  async saveAs(it) {
    if (window.api.saveToPhone) { await phoneSave(it.out.path); return; }
    const dest = await window.api.saveFile({ name: baseName(it.out.path), filters: [{ name: 'Video MP4', extensions: ['mp4'] }] });
    if (!dest) return;
    await window.api.copyFile(it.out.path, dest);
    toast('Disimpan: ' + dest, 'ok');
  },

  async start() {
    if (this.running) return;
    const queue = this.items.filter((i) => i.status === 'ready' || i.status === 'cancelled' || (i.status === 'error' && i.info && i.info.ok));
    if (!queue.length) { toast(this.items.length ? 'Semua video telah diproses. Tukar pratetap untuk memproses semula.' : 'Tambah video terlebih dahulu.', 'warn'); return; }
    this.running = true;
    let cancelled = false;
    Progress.show('Memampatkan video…', '', () => { cancelled = true; if (this.cancelFn) this.cancelFn(); });
    let n = 0, ok = 0;
    for (const it of queue) {
      if (cancelled) { it.status = 'cancelled'; continue; }
      n++;
      it.status = 'running'; it.progress = 0; this.render();
      const outBase = stripExt(it.name) + '_mampat_' + VIDEO_PRESETS[this.preset].label.toLowerCase();
      if (!hasFfmpeg()) {
        // Android: pemprosesan melalui WebView (MediaRecorder)
        Progress.set(((n - 1)) / queue.length * 100, `Video ${n}/${queue.length}: ${it.name} (masa ≈ tempoh video)`);
        try {
          const r = await WebVideo.render({
            url: window.api.mediaUrl(it.path), preset: this.preset, isCancelled: () => cancelled,
            onProgress: (p) => { it.progress = p; Progress.set(((n - 1) + p / 100) / queue.length * 100); const bar = $(`#vcList [data-id="${it.id}"] .bar`); if (bar) bar.style.width = p + '%'; }
          });
          if (!r) { it.status = 'cancelled'; cancelled = true; }
          else {
            const out = await outputPath(outBase + '.' + r.ext);
            await saveBlob(out, r.blob);
            it.out = { path: out, size: r.blob.size };
            it.status = 'done'; ok++;
          }
        } catch (e) { it.status = 'error'; it.error = e.message; }
        this.render();
        continue;
      }
      const outName = outBase + '.mp4';
      const out = await outputPath(outName);
      const args = videoCompressArgs(it.path, out, this.preset, it.info);
      Progress.set(0, `Video ${n}/${queue.length}: ${it.name}`);
      const r = await runFfmpegJob(args, {
        duration: it.info.duration,
        registerCancel: (fn) => { this.cancelFn = fn; },
        onProgress: (p) => {
          it.progress = p;
          Progress.set(((n - 1) + p / 100) / queue.length * 100);
          const bar = $(`#vcList [data-id="${it.id}"] .bar`);
          if (bar) bar.style.width = p + '%';
        }
      });
      this.cancelFn = null;
      if (r.cancelled || cancelled) { it.status = 'cancelled'; await window.api.remove(out); cancelled = true; }
      else if (r.code === 0) {
        const fi = await window.api.fileInfo(out);
        it.out = { path: out, size: fi.size };
        it.status = 'done'; ok++;
      } else { it.status = 'error'; it.error = ffmpegErrorText(r); await window.api.remove(out); }
      this.render();
    }
    Progress.hide();
    this.running = false;
    this.render();
    if (ok) toast(`${ok} video berjaya dimampatkan dan disimpan dalam folder output.`, 'ok', 'Selesai');
    else if (cancelled) toast('Proses dibatalkan.', 'warn');
    else toast('Tiada video berjaya diproses.', 'err');
  }
};
