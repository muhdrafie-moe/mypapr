'use strict';
/*
 * MyEviden — Penjejak Subjek (Kepala & Muka), luar talian.
 *
 * Versi 1.1: penjejakan berasaskan KEPALA + MUKA, bukan muka sahaja.
 *  1. Model rupa kepala (corak + warna rambut/tudung/muka) dijejak bingkai demi bingkai
 *     → tetap berfungsi apabila murid tunduk, menoleh atau muka tidak jelas.
 *  2. Pengesanan muka SETEMPAT (zum ke kawasan sekitar subjek) → muka kecil di belakang kelas dapat dikesan.
 *  3. Pengesahan identiti dengan "cap muka" (descriptor) + senarai "orang lain" yang ditolak
 *     → bentuk TIDAK melompat ke muka murid lain.
 *  4. Get gerakan: lompatan jauh hanya dibenarkan dengan bukti identiti yang sangat kuat.
 *  5. Titik rujukan (anchor) berbilang: pengguna boleh membetulkan subjek pada mana-mana masa.
 * Semua kotak output dalam koordinat ternormal (0..1) dan mewakili KEPALA subjek.
 */

/* ======================================================================== */
/* Enjin AI                                                                  */
/* ======================================================================== */
const FaceAI = {
  ready: false,
  loading: null,
  backend: '',
  async load() {
    if (this.ready) return;
    if (this.loading) return this.loading;
    this.loading = (async () => {
      const tf = faceapi.tf;
      // Keutamaan: GPU (WebGL) → WASM (CPU pantas) → CPU biasa
      const tryBackend = async (name) => {
        try {
          if (!(await tf.setBackend(name))) return false;
          await tf.ready();
          const x = tf.tidy(() => tf.conv2d(tf.ones([1, 8, 8, 3]), tf.ones([3, 3, 3, 2]), 1, 'same').sum());
          const v = (await x.data())[0];
          x.dispose();
          return v > 0;
        } catch (_) { return false; }
      };
      if (tf.setWasmPaths) tf.setWasmPaths('vendor/wasm/');
      let ok = false;
      for (const b of (window.MYPAPR_FORCE_BACKEND ? [window.MYPAPR_FORCE_BACKEND] : ['webgl', 'wasm', 'cpu'])) {
        if (await tryBackend(b)) { ok = true; break; }
      }
      if (!ok) throw new Error('Tiada enjin AI yang berfungsi pada komputer ini.');
      this.backend = tf.getBackend();
      await faceapi.nets.ssdMobilenetv1.loadFromUri('models');
      await faceapi.nets.faceLandmark68Net.loadFromUri('models');
      await faceapi.nets.faceRecognitionNet.loadFromUri('models');
      this.ready = true;
    })();
    try { await this.loading; } catch (e) { this.loading = null; throw e; }
  },
  options(minConf) { return new faceapi.SsdMobilenetv1Options({ minConfidence: minConf || 0.45, maxResults: 40 }); },

  /** Kesan muka + descriptor pada kanvas. Kotak dalam piksel kanvas. */
  async detectRaw(canvas, minConf) {
    const r = await faceapi.detectAllFaces(canvas, this.options(minConf)).withFaceLandmarks().withFaceDescriptors();
    return r.map((d) => ({ x: d.detection.box.x, y: d.detection.box.y, w: d.detection.box.width, h: d.detection.box.height, score: d.detection.score, desc: d.descriptor }));
  },

  /**
   * Kesan muka dalam satu kawasan bingkai (dizum) — kotak dikembalikan dalam piksel bingkai.
   * region: {x,y,w,h} piksel bingkai sumber.
   */
  async detectRegion(src, region, outSize, minConf) {
    const c = this._crop || (this._crop = document.createElement('canvas'));
    const s = (outSize || 512) / Math.max(region.w, region.h);
    c.width = Math.max(32, Math.round(region.w * s));
    c.height = Math.max(32, Math.round(region.h * s));
    const g = c.getContext('2d', { willReadFrequently: true });
    g.imageSmoothingQuality = 'high';
    g.drawImage(src, region.x, region.y, region.w, region.h, 0, 0, c.width, c.height);
    const faces = await this.detectRaw(c, minConf || 0.38);
    return faces.map((f) => Object.assign(f, { x: region.x + f.x / s, y: region.y + f.y / s, w: f.w / s, h: f.h / s }));
  },

  /** Kesan muka seluruh bingkai: penuh + jubin bertindih (untuk muka kecil). Kotak piksel bingkai. */
  async detectMulti(src, W, H, minConf) {
    let all = await this.detectRegion(src, { x: 0, y: 0, w: W, h: H }, 640, minConf);
    const cols = W >= H ? 3 : 2, rows = W >= H ? 2 : 3;
    const tw = W / cols * 1.35, th = H / rows * 1.35;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const x = clamp((c + 0.5) * W / cols - tw / 2, 0, W - tw), y = clamp((r + 0.5) * H / rows - th / 2, 0, H - th);
        all = all.concat(await this.detectRegion(src, { x, y, w: tw, h: th }, 512, minConf));
      }
    }
    return nms(all, 0.35);
  }
};

/* ======================================================================== */
/* Utiliti geometri                                                          */
/* ======================================================================== */
function nms(boxes, thr) {
  const s = boxes.slice().sort((a, b) => b.score - a.score);
  const keep = [];
  for (const b of s) {
    if (keep.every((k) => iou(k, b) < thr && !containsMost(k, b))) keep.push(b);
  }
  return keep;
}
function containsMost(a, b) {
  const x1 = Math.max(a.x, b.x), y1 = Math.max(a.y, b.y);
  const x2 = Math.min(a.x + a.w, b.x + b.w), y2 = Math.min(a.y + a.h, b.y + b.h);
  const inter = Math.max(0, x2 - x1) * Math.max(0, y2 - y1);
  return inter > 0.7 * Math.min(a.w * a.h, b.w * b.h);
}
function iou(a, b) {
  const x1 = Math.max(a.x, b.x), y1 = Math.max(a.y, b.y);
  const x2 = Math.min(a.x + a.w, b.x + b.w), y2 = Math.min(a.y + a.h, b.y + b.h);
  const inter = Math.max(0, x2 - x1) * Math.max(0, y2 - y1);
  const uni = a.w * a.h + b.w * b.h - inter;
  return uni > 0 ? inter / uni : 0;
}
function centerDist(a, b) {
  const dx = (a.x + a.w / 2) - (b.x + b.w / 2);
  const dy = (a.y + a.h / 2) - (b.y + b.h / 2);
  return Math.sqrt(dx * dx + dy * dy);
}
function descDist(a, b) {
  let s = 0;
  for (let i = 0; i < a.length; i++) { const d = a[i] - b[i]; s += d * d; }
  return Math.sqrt(s);
}
function minDescDist(d, pool) {
  let m = 9;
  if (!d) return m;
  for (const r of pool) m = Math.min(m, descDist(d, r));
  return m;
}
/** Kotak kepala (rambut/tudung + muka) daripada kotak muka (piksel). */
function headFromFace(f) {
  const w = f.w * 1.55, h = f.h * 1.75;
  const cx = f.x + f.w / 2, cy = f.y + f.h / 2 - f.h * 0.16;
  return { x: cx - w / 2, y: cy - h / 2, w, h };
}
function boxCenter(b) { return [b.x + b.w / 2, b.y + b.h / 2]; }
function toNorm(b, W, H) { return { x: b.x / W, y: b.y / H, w: b.w / W, h: b.h / H }; }
function toPx(b, W, H) { return { x: b.x * W, y: b.y * H, w: b.w * W, h: b.h * H }; }

/* ======================================================================== */
/* Model rupa kepala (corak + histogram warna)                               */
/* ======================================================================== */
const PGRID = 16;
const NBINS = 75;

/** Sampel kotak ke grid PGRID×PGRID RGB, dinormalkan (purata 0, norma 1) — untuk NCC. */
function samplePatch(img, b) {
  const { data, width: W, height: H } = img;
  const out = new Float32Array(PGRID * PGRID * 3);
  const sx = b.w / PGRID, sy = b.h / PGRID;
  const ox = [0.25, 0.75], oy = [0.25, 0.75];
  let k = 0;
  for (let gy = 0; gy < PGRID; gy++) {
    for (let gx = 0; gx < PGRID; gx++) {
      let r = 0, g = 0, bl = 0;
      for (let a = 0; a < 2; a++) {
        for (let c = 0; c < 2; c++) {
          let px = (b.x + (gx + ox[c]) * sx) | 0, py = (b.y + (gy + oy[a]) * sy) | 0;
          if (px < 0) px = 0; else if (px >= W) px = W - 1;
          if (py < 0) py = 0; else if (py >= H) py = H - 1;
          const i = (py * W + px) << 2;
          r += data[i]; g += data[i + 1]; bl += data[i + 2];
        }
      }
      out[k++] = r; out[k++] = g; out[k++] = bl;
    }
  }
  // buang purata setiap saluran (kebal perubahan cahaya), normalkan
  const n = PGRID * PGRID;
  for (let ch = 0; ch < 3; ch++) {
    let m = 0;
    for (let i = ch; i < out.length; i += 3) m += out[i];
    m /= n;
    for (let i = ch; i < out.length; i += 3) out[i] -= m;
  }
  let norm = 0;
  for (let i = 0; i < out.length; i++) norm += out[i] * out[i];
  norm = Math.sqrt(norm) || 1;
  for (let i = 0; i < out.length; i++) out[i] /= norm;
  return out;
}
function ncc(a, b) { let s = 0; for (let i = 0; i < a.length; i++) s += a[i] * b[i]; return s; }

/** Histogram warna HSV berpemberat elips (kawasan tengah lebih penting). */
function sampleHist(img, b) {
  const { data, width: W, height: H } = img;
  const hist = new Float32Array(NBINS);
  const G = 22;
  let tot = 0;
  for (let gy = 0; gy < G; gy++) {
    for (let gx = 0; gx < G; gx++) {
      const u = (gx + 0.5) / G * 2 - 1, v = (gy + 0.5) / G * 2 - 1;
      const r2 = u * u + v * v;
      if (r2 > 1) continue;
      const wgt = 1 - r2 * 0.7;
      let px = (b.x + (gx + 0.5) / G * b.w) | 0, py = (b.y + (gy + 0.5) / G * b.h) | 0;
      if (px < 0) px = 0; else if (px >= W) px = W - 1;
      if (py < 0) py = 0; else if (py >= H) py = H - 1;
      const i = (py * W + px) << 2;
      const R = data[i] / 255, Gc = data[i + 1] / 255, B = data[i + 2] / 255;
      const mx = Math.max(R, Gc, B), mn = Math.min(R, Gc, B), d = mx - mn;
      const s = mx > 0 ? d / mx : 0;
      const vb = mx < 0.33 ? 0 : mx < 0.66 ? 1 : 2;
      let bin;
      if (s < 0.18 || d < 0.06) bin = 72 + vb;
      else {
        let hh;
        if (mx === R) hh = ((Gc - B) / d + 6) % 6; else if (mx === Gc) hh = (B - R) / d + 2; else hh = (R - Gc) / d + 4;
        const hb = Math.min(7, Math.floor(hh / 6 * 8));
        const sb = s < 0.45 ? 0 : s < 0.7 ? 1 : 2;
        bin = hb * 9 + sb * 3 + vb;
      }
      hist[bin] += wgt; tot += wgt;
    }
  }
  if (tot > 0) for (let i = 0; i < NBINS; i++) hist[i] /= tot;
  return hist;
}
function bhatta(a, b) { let s = 0; for (let i = 0; i < a.length; i++) s += Math.sqrt(a[i] * b[i]); return s; }

function makeModel(img, b) { return { patch: samplePatch(img, b), hist: sampleHist(img, b), aspect: b.h / b.w }; }
function blendModel(m, img, b, alpha) {
  const p = samplePatch(img, b), hh = sampleHist(img, b);
  const np = new Float32Array(p.length);
  let norm = 0;
  for (let i = 0; i < p.length; i++) { np[i] = m.patch[i] * (1 - alpha) + p[i] * alpha; norm += np[i] * np[i]; }
  norm = Math.sqrt(norm) || 1;
  for (let i = 0; i < np.length; i++) np[i] /= norm;
  const nh = new Float32Array(NBINS);
  for (let i = 0; i < NBINS; i++) nh[i] = m.hist[i] * (1 - alpha) + hh[i] * alpha;
  return { patch: np, hist: nh, aspect: m.aspect };
}
/** Skor rupa calon kotak terhadap set model (0..1). */
function appearanceScore(img, b, models, cur) {
  const p = samplePatch(img, b), hh = sampleHist(img, b);
  let sInit = 0;
  for (const m of models) sInit = Math.max(sInit, 0.55 * (ncc(p, m.patch) + 1) / 2 + 0.45 * bhatta(hh, m.hist));
  const sCur = cur ? 0.55 * (ncc(p, cur.patch) + 1) / 2 + 0.45 * bhatta(hh, cur.hist) : sInit;
  return 0.35 * sInit + 0.65 * sCur;
}
function patchScore(p, models, cur) {
  let s = 0;
  for (const m of models) s = Math.max(s, ncc(p, m.patch));
  const c = cur ? ncc(p, cur.patch) : s;
  return 0.35 * s + 0.65 * c;
}

/** Cari kotak paling serupa di sekitar pusat ramalan. */
function searchHead(img, models, cur, pred, radius, scales) {
  const W = img.width, H = img.height;
  const [pcx, pcy] = boxCenter(pred);
  const stride = Math.max(2, radius / 8);
  scales = scales || [0.95, 1, 1.05];
  const coarse = [];
  for (const sc of scales) {
    const w = pred.w * sc, h = pred.h * sc;
    for (let dy = -radius; dy <= radius + 0.01; dy += stride) {
      for (let dx = -radius; dx <= radius + 0.01; dx += stride) {
        const cx = pcx + dx, cy = pcy + dy;
        if (cx < 0 || cy < 0 || cx > W || cy > H) continue;
        const b = { x: cx - w / 2, y: cy - h / 2, w, h };
        // penalti kecil untuk jarak dari ramalan (utamakan kesinambungan)
        const pen = 0.04 * Math.sqrt(dx * dx + dy * dy) / Math.max(1, radius);
        coarse.push({ b, s: patchScore(samplePatch(img, b), models, cur) - pen });
      }
    }
  }
  coarse.sort((a, b) => b.s - a.s);
  let best = null;
  for (const c of coarse.slice(0, 5)) {
    const st = stride / 3;
    for (let dy = -stride; dy <= stride + 0.01; dy += st) {
      for (let dx = -stride; dx <= stride + 0.01; dx += st) {
        const b = { x: c.b.x + dx, y: c.b.y + dy, w: c.b.w, h: c.b.h };
        const d = centerDist(b, pred);
        const s = appearanceScore(img, b, models, cur) - 0.04 * d / Math.max(1, radius);
        if (!best || s > best.score) best = { box: b, score: s };
      }
    }
  }
  return best || { box: pred, score: 0 };
}

/* ======================================================================== */
/* Bingkai video                                                             */
/* ======================================================================== */
function frameToCanvas(video, canvas, maxDim) {
  const vw = video.videoWidth, vh = video.videoHeight;
  const s = Math.min(1, (maxDim || 1280) / Math.max(vw, vh));
  const w = Math.max(1, Math.round(vw * s)), hh = Math.max(1, Math.round(vh * s));
  if (canvas.width !== w) canvas.width = w;
  if (canvas.height !== hh) canvas.height = hh;
  canvas.getContext('2d', { willReadFrequently: true }).drawImage(video, 0, 0, w, hh);
  return canvas;
}
function seekVideo(video, t) {
  return new Promise((resolve) => {
    let done = false;
    const fin = () => { if (done) return; done = true; video.removeEventListener('seeked', fin); clearTimeout(tm); resolve(); };
    const tm = setTimeout(fin, 4000);
    video.addEventListener('seeked', fin);
    try { video.currentTime = t; } catch (_) { fin(); }
  });
}
/** Gambar kecil kepala subjek (box ternormal). */
function cropFaceThumb(canvas, box) {
  const c = document.createElement('canvas');
  c.width = 96; c.height = 96;
  const W = canvas.width, H = canvas.height;
  const x = box.x * W, y = box.y * H, w = box.w * W, hh = box.h * H;
  const side = Math.max(w, hh) * 1.15;
  c.getContext('2d').drawImage(canvas, x + w / 2 - side / 2, y + hh / 2 - side / 2, side, side, 0, 0, 96, 96);
  return c.toDataURL('image/jpeg', 0.85);
}

/** Kesan semua kepala dalam bingkai semasa (untuk pemilihan subjek). Kotak ternormal. */
async function detectHeads(canvas) {
  const W = canvas.width, H = canvas.height;
  const faces = await FaceAI.detectMulti(canvas, W, H, 0.4);
  return faces.map((f) => {
    const hb = headFromFace(f);
    return Object.assign(toNorm(hb, W, H), { face: toNorm(f, W, H), desc: f.desc, score: f.score });
  }).sort((a, b) => a.x - b.x);
}

/* ======================================================================== */
/* Sesi penjejakan                                                           */
/* ======================================================================== */
class SubjectTracker {
  /** @param {{url:string, duration:number, rate:number}} o */
  constructor(o) {
    this.path = o.path;
    this.duration = o.duration;
    this.rate = o.rate || 8;
    this.dt = 1 / this.rate;
    this.N = Math.max(1, Math.ceil((this.duration - 0.02) * this.rate));
    this.anchors = [];       // {k, t, box(px), desc, model}
    this.samples = new Array(this.N + 1).fill(null); // {t, box(norm)|null, state, score}
    this.anchorRefs = [];    // cap muka daripada subjek yang DIPILIH pengguna (sumber identiti utama)
    this.learned = [];       // cap muka yang dipelajari semasa jejak (berpemberat rendah)
    this.others = [];        // descriptor orang lain (ditolak)
    this.models = [];        // model rupa daripada titik rujukan
    this.canvas = document.createElement('canvas');
    this.stats = { faceConfirmed: 0, appearance: 0, hold: 0, lost: 0, rejectedOthers: 0 };
    this.debug = [];
    this.timing = { grab: 0, search: 0, detect: 0 };
  }
  timeOf(k) { return Math.min(k * this.dt, Math.max(0, this.duration - 0.04)); }
  kOf(t) { return clamp(Math.round(t * this.rate), 0, this.N); }

  get refs() { return this.anchorRefs.concat(this.learned); }

  /** Ekstrak bingkai analisis sekali gus dengan ffmpeg (jauh lebih pantas daripada mencari dalam video). */
  async open(cb) {
    await FaceAI.load();
    if (!hasFfmpeg()) {
      // Android: tiada ffmpeg — baca bingkai dengan mencari (seek) dalam video
      const v = document.createElement('video');
      v.muted = true; v.preload = 'auto'; v.crossOrigin = 'anonymous'; v.playsInline = true;
      await new Promise((resolve, reject) => { v.onloadeddata = resolve; v.onerror = () => reject(new Error('Video tidak dapat dibaca untuk analisis.')); v.src = window.api.mediaUrl(this.path); });
      this.video = v;
      return;
    }
    this.dir = await window.api.tempDir('jejak');
    const sc = "scale='if(gte(iw,ih),min(1280,iw),-2)':'if(gte(iw,ih),-2,min(1280,ih))'";
    const args = ['-i', this.path, '-an', '-vf', `fps=${this.rate},${sc}`, '-q:v', '3', await window.api.join(this.dir, 'f_%06d.jpg')];
    const r = await runFfmpegJob(args, {
      duration: this.duration,
      onProgress: (p) => { if (cb && cb.onStage) cb.onStage('Menyediakan bingkai video…', p); }
    });
    if (r.code !== 0) throw new Error('Gagal membaca bingkai video: ' + ffmpegErrorText(r));
    this.frameCount = await window.api.countFiles(this.dir, 'f_');
    if (!this.frameCount) throw new Error('Tiada bingkai video dapat dibaca.');
  }
  close() {
    if (this.dir) { window.api.remove(this.dir); this.dir = null; }
    if (this.video) { this.video.removeAttribute('src'); this.video.load(); this.video = null; }
  }

  async loadFrame(k) {
    for (let kk = Math.min(k, this.frameCount - 1); kk >= 0; kk--) {
      try {
        const p = await window.api.join(this.dir, 'f_' + String(kk + 1).padStart(6, '0') + '.jpg');
        return await loadImageUrl(window.api.mediaUrl(p));
      } catch (_) { /* bingkai terakhir mungkin tiada — guna sebelumnya */ }
    }
    throw new Error('Bingkai tidak ditemui');
  }

  async grab(t) {
    if (this.video) {
      await seekVideo(this.video, this.timeOf(this.kOf(t)));
      frameToCanvas(this.video, this.canvas, 1280);
      this.W = this.canvas.width; this.H = this.canvas.height;
      return this.canvas.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, this.W, this.H);
    }
    const k = this.kOf(t);
    const im = await this.loadFrame(k);
    const c = this.canvas;
    if (c.width !== im.naturalWidth) c.width = im.naturalWidth;
    if (c.height !== im.naturalHeight) c.height = im.naturalHeight;
    const g = c.getContext('2d', { willReadFrequently: true });
    g.drawImage(im, 0, 0);
    this.W = c.width; this.H = c.height;
    return g.getImageData(0, 0, this.W, this.H);
  }

  /**
   * Tambah titik rujukan (subjek pada masa t) dan jejak semula bahagian yang terjejas.
   * a: { t, box (ternormal kotak kepala), desc? }
   */
  async addAnchor(a, cb) {
    const k = this.kOf(a.t);
    const img = await this.grab(this.timeOf(k));
    const box = toPx(a.box, this.W, this.H);
    let desc = a.desc || null;
    if (!desc) {
      // cuba dapatkan cap muka subjek daripada kawasan kotak yang dilukis
      const reg = this.regionAround(box, 3);
      const faces = await FaceAI.detectRegion(this.canvas, reg, 512, 0.35);
      let bestF = null, bi = 0;
      for (const f of faces) { const v = iou(headFromFace(f), box); if (v > bi) { bi = v; bestF = f; } }
      if (bestF && bi > 0.2) desc = bestF.desc;
    }
    if (desc) {
      // descriptor yang kini dianggap "orang lain" tetapi sepadan subjek → buang daripada senarai tolak
      this.others = this.others.filter((o) => descDist(o, desc) > 0.45);
      this.anchorRefs.push(desc);
    }
    const model = makeModel(img, box);
    this.models.push(model);
    // buang anchor lama pada indeks yang sama
    this.anchors = this.anchors.filter((x) => x.k !== k);
    const anchor = { k, t: this.timeOf(k), box, desc, model };
    this.anchors.push(anchor);
    this.anchors.sort((x, y) => x.k - y.k);
    const i = this.anchors.indexOf(anchor);
    const next = this.anchors[i + 1];
    const prev = this.anchors[i - 1];
    const jobs = [];
    // ke hadapan sehingga anchor seterusnya (atau hujung)
    jobs.push({ from: k, to: next ? next.k - 1 : this.N, dir: 1 });
    // ke belakang: hanya jika ini anchor pertama (sehingga 0); jika tidak, separuh jurang ke anchor sebelumnya
    if (!prev) jobs.push({ from: k - 1, to: 0, dir: -1 });
    else {
      const mid = Math.ceil((prev.k + k) / 2);
      if (mid <= k - 1) jobs.push({ from: k - 1, to: mid, dir: -1 });
    }
    const total = jobs.reduce((s, j) => s + Math.abs(j.to - j.from) + 1, 0);
    let done = 0;
    for (const j of jobs) {
      await this.runSegment(anchor, j, (n) => { done += n; if (cb && cb.onProgress) cb.onProgress(done / total * 100, { processed: done, total }); }, cb);
    }
    return anchor;
  }

  regionAround(b, mult) {
    const W = this.W, H = this.H;
    const side = clamp(Math.max(b.w, b.h) * mult, 220, Math.max(W, H));
    const rw = Math.min(W, side * (W >= H ? 1.25 : 1)), rh = Math.min(H, side);
    const [cx, cy] = boxCenter(b);
    return { x: clamp(cx - rw / 2, 0, W - rw), y: clamp(cy - rh / 2, 0, H - rh), w: rw, h: rh };
  }

  classifyFace(f) {
    // tiada cap muka daripada pemilihan (kotak dilukis): guna cap yang dipelajari sebagai rujukan utama
    const primary = this.anchorRefs.length ? this.anchorRefs : this.learned;
    const dA = minDescDist(f.desc, primary);
    const dL = minDescDist(f.desc, this.learned);
    const d = Math.min(dA, dL + 0.06);
    const o = minDescDist(f.desc, this.others);
    const hasRefs = primary.length > 0;
    const strong = hasRefs && (dA < 0.42 || (dL < 0.3 && dA < 0.5));
    const weak = hasRefs && !strong && dA < 0.52 && dA < o - 0.06;
    const other = hasRefs ? (!strong && !weak && (d > 0.56 || o < d - 0.04)) : false;
    return { d, dA, o, strong, weak, subject: strong || weak, other };
  }

  async runSegment(anchor, job, onStep, cb) {
    const W = this.W, H = this.H;
    let last = Object.assign({}, anchor.box);
    let vel = [0, 0];
    let cur = anchor.model;
    let lost = 0;
    let refScore = 0.8;
    let baseW = anchor.box.w;
    let sinceFace = 0;
    let prevState = 'face';
    // tanpa cap muka, rupa kepala ialah satu-satunya isyarat — benarkan lebih lama
    const appearMax = () => Math.round((this.refs.length ? 2.5 : 8) * this.rate);
    const holdMax = Math.round(0.4 * this.rate);
    // skor rujukan model asal: purata bagi beberapa anjakan kecil kotak anchor
    let initRef = 0.8;
    {
      const img0 = await this.grab(anchor.t);
      const sh = [[0.06, 0], [-0.06, 0], [0, 0.06], [0, -0.06]].map(([dx, dy]) => appearanceScore(img0, { x: anchor.box.x + dx * anchor.box.w, y: anchor.box.y + dy * anchor.box.h, w: anchor.box.w, h: anchor.box.h }, [anchor.model], null));
      initRef = Math.min(0.92, sh.reduce((a, b) => a + b, 0) / sh.length) - 0.08;
    }
    const sign = job.dir;
    // anchor itu sendiri
    this.samples[anchor.k] = { t: anchor.t, box: toNorm(anchor.box, W, H), state: 'anchor', score: 1 };
    const ks = [];
    if (sign > 0) { for (let k = job.from; k <= job.to; k++) ks.push(k); } else { for (let k = job.from; k >= job.to; k--) ks.push(k); }
    let stepCount = 0;
    for (const k of ks) {
      if (cb && cb.isCancelled && cb.isCancelled()) throw new Error('DIBATALKAN');
      if (k === anchor.k) { onStep(1); continue; }
      const t = this.timeOf(k);
      let tm = performance.now();
      const img = await this.grab(t);
      this.timing.grab += performance.now() - tm; tm = performance.now();
      const pred = { x: last.x + vel[0], y: last.y + vel[1], w: last.w, h: last.h };
      const radius = Math.max(last.w, last.h) * (lost ? Math.min(3.5, 1.1 + lost * 0.35) : 1.0);

      // 1) jejak rupa kepala
      const tr = searchHead(img, this.models, cur, pred, radius);
      this.timing.search += performance.now() - tm; tm = performance.now();

      // 2) pengesanan muka setempat (dizum)
      const region = this.regionAround(pred, lost ? 3 + Math.min(lost, 8) : 3.2);
      // bingkai stabil: langkau pengesanan muka berselang-seli (lebih pantas)
      const stable = !lost && prevState === 'face' && tr.score >= refScore - 0.04;
      const skipDet = stable && (stepCount % 2 === 1);
      let faces = skipDet ? [] : await FaceAI.detectRegion(this.canvas, region, 512, 0.38);
      // 3) cari semula seluruh bingkai jika hilang lama
      if (lost > holdMax && lost % 3 === 0 && this.refs.length) {
        faces = nms(faces.concat(await FaceAI.detectMulti(this.canvas, W, H, 0.4)), 0.35);
      }
      this.timing.detect += performance.now() - tm;
      const gate = radius + Math.max(last.w, last.h) * 0.5;
      let subjectFace = null, bestScore = 9;
      const otherHeads = [];
      for (const f of faces) {
        const head = headFromFace(f);
        const cls = this.classifyFace(f);
        const dc = centerDist(head, pred);
        const r = head.w / baseW;
        const sizeOk = r > 0.6 && r < 1.7;
        if (cls.other) {
          otherHeads.push(head);
          if (this.others.length < 80 && minDescDist(f.desc, this.others) > 0.25) this.others.push(f.desc);
          continue;
        }
        let ok = false;
        if (cls.strong && sizeOk && dc <= gate) ok = true;
        else if (cls.weak && sizeOk && dc <= gate * 0.6) ok = true;
        // lompatan jauh hanya dengan identiti sangat kuat & saiz munasabah
        else if (cls.strong && cls.d < 0.36 && r > 0.45 && r < 2.2) ok = true;
        // tiada cap muka rujukan: terima muka yang bertindih dengan kepala yang dijejak
        else if (!this.refs.length && sizeOk && iou(head, tr.box) > 0.3 && dc <= gate) ok = true;
        if (!ok) { if (cls.d >= 0.48) otherHeads.push(head); continue; }
        // veto rupa kepala: rambut/tudung/bentuk mesti serupa subjek (cth. rambut pendek ≠ bertudung)
        const app = appearanceScore(img, head, this.models, cur);
        if (app < Math.min(initRef, refScore) - 0.2 && cls.dA > 0.34) { otherHeads.push(head); this.stats.vetoed = (this.stats.vetoed || 0) + 1; continue; }
        const sc = cls.d + 0.25 * dc / Math.max(1, gate);
        if (sc < bestScore) { bestScore = sc; subjectFace = { f, head, cls }; }
      }

      let box = null, state = 'lost', score = tr.score;
      const initScore = appearanceScore(img, tr.box, this.models, null);
      if (subjectFace) {
        const fh = subjectFace.head;
        if (iou(fh, tr.box) > 0.3 && tr.score > refScore - 0.15) {
          box = { x: fh.x * 0.75 + tr.box.x * 0.25, y: fh.y * 0.75 + tr.box.y * 0.25, w: fh.w * 0.75 + tr.box.w * 0.25, h: fh.h * 0.75 + tr.box.h * 0.25 };
        } else box = Object.assign({}, fh);
        state = 'face';
        score = appearanceScore(img, box, this.models, cur);
        sinceFace = 0;
        baseW = 0.7 * baseW + 0.3 * fh.w;
        if (subjectFace.cls.dA < 0.38 && this.learned.length < 12 && minDescDist(subjectFace.f.desc, this.refs) > 0.2) this.learned.push(subjectFace.f.desc);
        if (!this.anchorRefs.length && subjectFace.f.desc && !this.learned.length) this.learned.push(subjectFace.f.desc);
        this.stats.faceConfirmed++;
      } else {
        // tiada muka subjek: rupa kepala sahaja (subjek tunduk/menoleh) — terhad masa & mesti serupa model asal
        const onOther = otherHeads.some((oh) => iou(oh, tr.box) > 0.25 || centerDist(oh, tr.box) < Math.min(oh.w, tr.box.w) * 0.5);
        if (onOther) this.stats.rejectedOthers++;
        const thr = Math.max(0.62, refScore - (lost ? 0.05 : 0.1));
        const fresh = sinceFace <= appearMax();
        if (!onOther && fresh && tr.score >= thr && initScore >= initRef - 0.12) { box = tr.box; state = 'appearance'; this.stats.appearance++; }
        sinceFace++;
      }
      this.debug.push({ k, st: box ? state : 'lost', tr: +tr.score.toFixed(3), init: +initScore.toFixed(3), ref: +refScore.toFixed(3), nf: faces.length, d: subjectFace ? +subjectFace.cls.d.toFixed(3) : null });

      if (box) {
        const ar = anchor.box.h / anchor.box.w;
        box.w = clamp(box.w, Math.max(last.w * 0.85, baseW * 0.7), Math.min(last.w * 1.18, baseW * 1.45));
        box.h = clamp(box.h, box.w * ar * 0.85, box.w * ar * 1.18);
        const [ncx, ncy] = boxCenter(box), [lcx, lcy] = boxCenter(last);
        const steps = lost + 1;
        vel = [0.5 * vel[0] + 0.5 * (ncx - lcx) / steps, 0.5 * vel[1] + 0.5 * (ncy - lcy) / steps];
        last = { x: box.x, y: box.y, w: box.w, h: box.h };
        lost = 0;
        if (state === 'face') refScore = 0.85 * refScore + 0.15 * clamp(score, 0.6, 0.95);
        if (state === 'face') cur = blendModel(cur, img, box, 0.15);
        else if (score > refScore - 0.03) cur = blendModel(cur, img, box, 0.05);
        this.samples[k] = { t, box: toNorm(box, W, H), state, score };
        prevState = state;
      } else {
        prevState = 'lost';
        lost++;
        vel = [vel[0] * 0.6, vel[1] * 0.6];
        if (lost <= holdMax) {
          const hb = { x: last.x + vel[0], y: last.y + vel[1], w: last.w, h: last.h };
          last = hb;
          this.samples[k] = { t, box: toNorm(hb, W, H), state: 'hold', score };
          this.stats.hold++;
        } else {
          this.samples[k] = { t, box: null, state: 'lost', score };
          this.stats.lost++;
        }
      }
      onStep(1);
      if (++stepCount % 3 === 0) await sleep(0);
    }
  }

  /** Senarai sampel tersusun & dilicinkan. */
  toTrack() {
    const raw = [];
    for (let k = 0; k <= this.N; k++) {
      const s = this.samples[k];
      raw.push(s ? { t: this.timeOf(k), box: s.box, state: s.state } : { t: this.timeOf(k), box: null, state: 'none' });
    }
    return smoothTrack(raw, this.dt);
  }
}

/** Jejak penuh dari satu subjek (serasi dengan v1.0). */
async function trackSubject(o) {
  const tr = new SubjectTracker({ path: o.path, duration: o.duration, rate: o.rate });
  await tr.open(o);
  try {
    await tr.addAnchor({ t: o.target.time, box: o.target.box, desc: o.target.desc }, { onProgress: o.onProgress, isCancelled: o.isCancelled });
    return tr.toTrack();
  } finally { tr.close(); }
}

/* ======================================================================== */
/* Pelicinan & interpolasi                                                   */
/* ======================================================================== */
function smoothTrack(samples, step) {
  const n = samples.length;
  const out = samples.map((s) => ({ t: s.t, box: s.box ? Object.assign({}, s.box) : null, state: s.state }));
  // isi jurang pendek (≤0.5s) secara interpolasi
  const maxGap = Math.max(1, Math.round(0.5 / step));
  let i = 0;
  while (i < n) {
    if (out[i].box) { i++; continue; }
    let j = i;
    while (j < n && !out[j].box) j++;
    const gap = j - i;
    if (i > 0 && j < n && gap <= maxGap) {
      const a = out[i - 1].box, b = out[j].box;
      for (let k = i; k < j; k++) {
        const f = (k - (i - 1)) / (j - (i - 1));
        out[k].box = { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f, w: a.w + (b.w - a.w) * f, h: a.h + (b.h - a.h) * f };
        out[k].state = 'hold';
      }
    }
    i = j;
  }
  // purata bergerak berpemberat (tidak melintasi jurang); anchor dikekalkan tepat
  const Wt = [1, 2, 4, 2, 1];
  return out.map((s, idx) => {
    if (!s.box || s.state === 'anchor') return s;
    let sx = 0, sy = 0, sw = 0, shh = 0, tw = 0;
    for (let k = -2; k <= 2; k++) {
      const q = out[idx + k];
      if (!q || !q.box) continue;
      const w = Wt[k + 2];
      sx += (q.box.x + q.box.w / 2) * w; sy += (q.box.y + q.box.h / 2) * w; sw += q.box.w * w; shh += q.box.h * w; tw += w;
    }
    const cx = sx / tw, cy = sy / tw, bw = sw / tw, bh = shh / tw;
    return { t: s.t, box: { x: cx - bw / 2, y: cy - bh / 2, w: bw, h: bh }, state: s.state };
  });
}

function trackBoxAt(track, t) {
  if (!track || !track.length) return null;
  if (t <= track[0].t) return track[0].box;
  const last = track[track.length - 1];
  if (t >= last.t) return last.box;
  let lo = 0, hi = track.length - 1;
  while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (track[mid].t <= t) lo = mid; else hi = mid; }
  const a = track[lo], b = track[hi];
  if (!a.box || !b.box) return (t - a.t) < (b.t - t) ? a.box : b.box;
  const f = (t - a.t) / (b.t - a.t);
  return { x: a.box.x + (b.box.x - a.box.x) * f, y: a.box.y + (b.box.y - a.box.y) * f, w: a.box.w + (b.box.w - a.box.w) * f, h: a.box.h + (b.box.h - a.box.h) * f };
}

/** Kotak bentuk fokus daripada kotak KEPALA (ternormal) + ruang sekeliling. */
function focusRect(box, W, H, padPct, shape) {
  const pad = (padPct || 0) / 100;
  let bw = box.w * W, bh = box.h * H;
  const cx = (box.x + box.w / 2) * W;
  const cy = (box.y + box.h / 2) * H;
  if (shape === 'ellipse') { bw *= 1.1; bh *= 1.08; }
  bw *= (1 + pad); bh *= (1 + pad);
  return { x: cx - bw / 2, y: cy - bh / 2, w: bw, h: bh, cx, cy };
}

/** Fail arahan sendcmd ffmpeg (kedudukan & saiz bentuk mengikut masa). */
function buildFaceCommands(track, duration, W, H, opts) {
  const fps = opts.cmdFps || 15;
  const lines = [];
  let visible = 0;
  const sizes = [];
  for (const s of track) if (s.box) { const r = focusRect(s.box, W, H, opts.pad, opts.shape); sizes.push([r.w, r.h]); }
  sizes.sort((a, b) => a[0] - b[0]);
  const med = sizes.length ? sizes[Math.floor(sizes.length / 2)] : [W * 0.2, H * 0.2];
  const lbl = opts.labelSize;
  for (let i = 0; ; i++) {
    const t = i / fps;
    if (t > duration + 0.5) break;
    const b = trackBoxAt(track, t);
    let parts;
    if (b) {
      const r = focusRect(b, W, H, opts.pad, opts.shape);
      const w = Math.max(8, Math.round(r.w)), hh = Math.max(8, Math.round(r.h));
      const x = Math.round(r.cx - w / 2), y = Math.round(r.cy - hh / 2);
      parts = [`overlay@face x ${x}`, `overlay@face y ${y}`, `scale@face w ${w}`, `scale@face h ${hh}`];
      if (lbl) {
        const lx = Math.round(r.cx - lbl.w / 2);
        let ly = Math.round(y - lbl.h - Math.max(4, lbl.h * 0.15));
        if (ly < 0) ly = Math.round(y + hh + Math.max(4, lbl.h * 0.15));
        parts.push(`overlay@lbl x ${lx}`, `overlay@lbl y ${ly}`);
      }
      visible++;
    } else {
      parts = [`overlay@face x -100000`, `overlay@face y -100000`];
      if (lbl) parts.push(`overlay@lbl x -100000`, `overlay@lbl y -100000`);
    }
    lines.push(`${t.toFixed(3)} ` + parts.map((p) => `[enter] ${p}`).join(', ') + ';');
  }
  return { text: lines.join('\n') + '\n', baseW: Math.round(med[0]), baseH: Math.round(med[1]), visibleCount: visible };
}

/* ======================================================================== */
/* Lukisan                                                                   */
/* ======================================================================== */
function drawFocusShape(ctx, shape, x, y, w, hh, color, thick) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = thick;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  ctx.shadowColor = 'rgba(0,0,0,0.45)';
  ctx.shadowBlur = thick * 1.2;
  const ix = x + thick / 2, iy = y + thick / 2, iw = Math.max(1, w - thick), ih = Math.max(1, hh - thick);
  ctx.beginPath();
  if (shape === 'ellipse') {
    ctx.ellipse(ix + iw / 2, iy + ih / 2, iw / 2, ih / 2, 0, 0, Math.PI * 2);
    ctx.stroke();
  } else if (shape === 'rect') {
    ctx.rect(ix, iy, iw, ih);
    ctx.stroke();
  } else if (shape === 'roundrect') {
    ctx.roundRect(ix, iy, iw, ih, Math.min(iw, ih) * 0.22);
    ctx.stroke();
  } else {
    const L = Math.min(iw, ih) * 0.28;
    const P = [[ix, iy + L, ix, iy, ix + L, iy], [ix + iw - L, iy, ix + iw, iy, ix + iw, iy + L], [ix + iw, iy + ih - L, ix + iw, iy + ih, ix + iw - L, iy + ih], [ix + L, iy + ih, ix, iy + ih, ix, iy + ih - L]];
    for (const p of P) { ctx.moveTo(p[0], p[1]); ctx.lineTo(p[2], p[3]); ctx.lineTo(p[4], p[5]); }
    ctx.stroke();
  }
  ctx.restore();
}

function makeLabelCanvas(text, fontPx, color) {
  const c = document.createElement('canvas');
  const ctx = c.getContext('2d');
  ctx.font = `bold ${fontPx}px Arial, "Segoe UI", sans-serif`;
  const tw = Math.ceil(ctx.measureText(text).width);
  const padX = Math.round(fontPx * 0.6), padY = Math.round(fontPx * 0.35);
  c.width = tw + padX * 2; c.height = Math.round(fontPx * 1.2) + padY * 2;
  const g = c.getContext('2d');
  g.fillStyle = color;
  g.beginPath(); g.roundRect(0, 0, c.width, c.height, c.height / 2); g.fill();
  g.font = `bold ${fontPx}px Arial, "Segoe UI", sans-serif`;
  g.fillStyle = luminance(color) > 0.55 ? '#111111' : '#ffffff';
  g.textBaseline = 'middle';
  g.textAlign = 'center';
  g.fillText(text, c.width / 2, c.height / 2 + fontPx * 0.04);
  return c;
}
function luminance(hex) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || '');
  if (!m) return 0.5;
  return (0.299 * parseInt(m[1], 16) + 0.587 * parseInt(m[2], 16) + 0.114 * parseInt(m[3], 16)) / 255;
}

if (typeof module !== 'undefined') {
  module.exports = { smoothTrack, trackBoxAt, focusRect, buildFaceCommands, iou, descDist, headFromFace, nms, samplePatch, sampleHist, ncc, bhatta, makeModel, appearanceScore, searchHead };
}
