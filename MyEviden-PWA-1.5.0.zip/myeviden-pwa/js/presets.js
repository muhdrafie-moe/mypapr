'use strict';
/* Pratetap mampatan video & gambar */
const VIDEO_PRESETS = {
  original: { label: 'Kualiti Asal', short: 0, crf: 20, preset: 'medium', audio: '160k', fps: 0, desc: 'Resolusi asal, kualiti tinggi.' },
  normal: { label: 'Biasa', short: 1080, crf: 23, preset: 'medium', audio: '128k', fps: 0, desc: 'Biasa: resolusi sehingga 1080p, kualiti tinggi — sesuai untuk arkib. Saiz berkurang sederhana.' },
  recommended: { label: 'Disyorkan', short: 720, crf: 27, preset: 'medium', audio: '96k', fps: 0, desc: 'Disyorkan: 720p (HD), keseimbangan terbaik antara kualiti dan saiz — sesuai untuk muat naik evidens.' },
  max: { label: 'Maksimum', short: 480, crf: 31, preset: 'medium', audio: '64k', fps: 24, desc: 'Maksimum: 480p, 24fps — saiz paling kecil untuk dihantar melalui WhatsApp / e-mel. Kualiti berkurang.' }
};
const IMAGE_PRESETS = {
  normal: { label: 'Biasa', maxDim: 2560, quality: 0.85, desc: 'Biasa: sehingga 2560px, kualiti 85% — hampir tiada perbezaan visual.' },
  recommended: { label: 'Disyorkan', maxDim: 1920, quality: 0.75, desc: 'Disyorkan: sehingga 1920px, kualiti 75% — jimat saiz dengan kualiti baik.' },
  max: { label: 'Maksimum', maxDim: 1280, quality: 0.6, desc: 'Maksimum: sehingga 1280px, kualiti 60% — saiz paling kecil.' }
};

/** Penapis skala: hadkan sisi pendek kepada S piksel (tidak membesarkan), dimensi genap. */
function scaleFilter(short) {
  if (!short) return "scale=trunc(iw/2)*2:trunc(ih/2)*2";
  const S = short;
  return `scale='if(gte(iw,ih),-2,trunc(min(${S},iw)/2)*2)':'if(gte(iw,ih),trunc(min(${S},ih)/2)*2,-2)'`;
}
/** Penapis video selepas tindanan (skala + fps + format). */
function presetVideoFilters(key) {
  const p = VIDEO_PRESETS[key] || VIDEO_PRESETS.recommended;
  const f = [scaleFilter(p.short)];
  if (p.fps) f.push(`fps=${p.fps}`);
  f.push('setsar=1', 'format=yuv420p');
  return f.join(',');
}
/** Argumen pengekod output. */
function presetEncodeArgs(key, hasAudio) {
  const p = VIDEO_PRESETS[key] || VIDEO_PRESETS.recommended;
  const a = ['-c:v', 'libx264', '-preset', p.preset, '-crf', String(p.crf), '-profile:v', 'high', '-pix_fmt', 'yuv420p'];
  if (hasAudio) a.push('-c:a', 'aac', '-b:a', p.audio);
  else a.push('-an');
  a.push('-movflags', '+faststart');
  return a;
}
function videoCompressArgs(input, output, key, info) {
  const hasAudio = !info || info.hasAudio !== false;
  return ['-i', input, '-map', '0:v:0', '-map', '0:a:0?', '-vf', presetVideoFilters(key)].concat(presetEncodeArgs(key, hasAudio), ['-map_metadata', '-1', output]);
}

/**
 * Potong & gabung (ffmpeg). clips: [{path, start, end, hasAudio, width, height}]
 * Saiz bingkai ikut klip pertama; klip lain dimuatkan dengan jalur hitam. Klip tanpa audio diberi senyap.
 */
function trimMergeArgs(clips, output, key) {
  const even = (x) => Math.max(2, Math.round(x / 2) * 2);
  const W = even(clips[0].width), H = even(clips[0].height);
  const args = [];
  const f = [];
  let pairs = '';
  let total = 0;
  clips.forEach((c) => {
    const dur = Math.max(0.05, c.end - c.start);
    args.push('-ss', c.start.toFixed(3), '-t', dur.toFixed(3), '-i', c.path);
  });
  clips.forEach((c, i) => {
    const dur = Math.max(0.05, c.end - c.start);
    total += dur;
    f.push(`[${i}:v]scale=${W}:${H}:force_original_aspect_ratio=decrease,pad=${W}:${H}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,fps=30,format=yuv420p,trim=duration=${dur.toFixed(3)},setpts=PTS-STARTPTS[v${i}]`);
    if (c.hasAudio) f.push(`[${i}:a]aresample=44100:async=1,aformat=sample_fmts=fltp:channel_layouts=stereo,apad,atrim=duration=${dur.toFixed(3)},asetpts=PTS-STARTPTS[a${i}]`);
    else f.push(`anullsrc=r=44100:cl=stereo,atrim=duration=${dur.toFixed(3)},aformat=sample_fmts=fltp:channel_layouts=stereo,asetpts=PTS-STARTPTS[a${i}]`);
    pairs += `[v${i}][a${i}]`;
  });
  f.push(`${pairs}concat=n=${clips.length}:v=1:a=1[vc][ac]`);
  f.push(`[vc]${presetVideoFilters(key)}[vout]`);
  return { args: args.concat(['-filter_complex', f.join(';'), '-map', '[vout]', '-map', '[ac]'], presetEncodeArgs(key, true), ['-map_metadata', '-1', output]), duration: total };
}

if (typeof module !== 'undefined') module.exports = { VIDEO_PRESETS, IMAGE_PRESETS, scaleFilter, presetVideoFilters, presetEncodeArgs, videoCompressArgs, trimMergeArgs };
