'use strict';
/* Pengawal aplikasi: navigasi, tema, refresh, tetapan, pintasan papan kekunci */
const VIEW_META = {
  home: ['Utama', 'Perekodan evidens murid MBPK dengan mudah'],
  vcompress: ['Mampat Video', 'Kecilkan saiz video evidens — Biasa, Disyorkan atau Maksimum'],
  icompress: ['Mampat Gambar', 'Kecilkan saiz gambar evidens secara berkelompok'],
  collage: ['Kolaj Gambar', 'Gabungkan beberapa gambar dalam satu susun atur'],
  trim: ['Potong & Gabung Video', 'Potong bahagian video dan gabungkan beberapa video menjadi satu'],
  ieditor: ['Edit Gambar', 'Tambah teks dan bentuk pada gambar'],
  veditor: ['Edit Video & Fokus Muka', 'Tambah teks, bentuk dan fokus automatik pada muka murid'],
  gallery: ['Galeri Saya', 'Semua hasil anda — main semula, edit dan jana URL untuk dikongsi'],
  settings: ['Tetapan', 'Tema, folder output dan maklumat sistem']
};

const App = {
  view: 'home',

  async init() {
    applyIcons();
    await Settings.load();
    this.applyTheme(Settings.get('theme') || 'system');
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if ((Settings.get('theme') || 'system') === 'system') this.applyTheme('system'); });

    $$('.nav-item').forEach((b) => b.addEventListener('click', () => this.go(b.dataset.view)));
    $$('[data-goto]').forEach((b) => b.addEventListener('click', () => this.go(b.dataset.goto)));
    $$('[data-theme-set]').forEach((b) => b.addEventListener('click', () => this.setTheme(b.dataset.themeSet)));
    $('#btnRefresh').addEventListener('click', () => this.refresh());
    window.api.onRefreshRequest(() => this.refresh());
    $('#btnOpenOut').addEventListener('click', () => window.api.openPath(Settings.get('outDir')));
    $('#pmCancel').addEventListener('click', () => { if (Progress.onCancel) { const f = Progress.onCancel; Progress.onCancel = null; $('#pmText').textContent = 'Membatalkan…'; f(); } });

    const mods = [VideoCompress, ImageCompress, Collage, ImageEditor, VideoEditor, Share, Gallery, TrimMerge];
    for (const m of mods) {
      try { m.init(); } catch (e) { console.error(e); toast('Modul gagal dimulakan: ' + e.message, 'err'); }
    }
    await this.initSettings();

    // halang fail dilepaskan di luar zon daripada membuka tetingkap baharu
    window.addEventListener('dragover', (e) => e.preventDefault());
    window.addEventListener('drop', (e) => e.preventDefault());

    document.addEventListener('keydown', (e) => this.onKey(e));

    let last = 'home';
    try { last = sessionStorage.getItem('mypapr-view') || 'home'; } catch (_) { /* abaikan */ }
    this.go(VIEW_META[last] ? last : 'home');
    window.__mypaprReady = true;
  },

  go(view) {
    if (!VIEW_META[view]) return;
    this.view = view;
    $$('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
    $$('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + view));
    $('#pageTitle').textContent = VIEW_META[view][0];
    $('#pageSub').textContent = VIEW_META[view][1];
    try { sessionStorage.setItem('mypapr-view', view); } catch (_) { /* abaikan */ }
    requestAnimationFrame(() => {
      if (view === 'ieditor') ImageEditor.ed.fit();
      if (view === 'veditor') VideoEditor.ed.fit();
      if (view === 'collage') Collage.fit();
      if (view === 'gallery') Gallery.load();
    });
    if (view !== 'veditor' && VideoEditor.video && !VideoEditor.video.paused) VideoEditor.video.pause();
    if (view !== 'trim' && TrimMerge.video && !TrimMerge.video.paused) TrimMerge.video.pause();
  },

  applyTheme(mode) {
    const dark = mode === 'dark' || (mode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    $$('[data-theme-set]').forEach((b) => b.classList.toggle('on', b.dataset.themeSet === (dark ? 'dark' : 'light')));
    $$('#setTheme button').forEach((b) => b.classList.toggle('on', b.dataset.theme === mode));
  },
  async setTheme(mode) {
    await Settings.set({ theme: mode });
    this.applyTheme(mode);
  },

  async refresh() {
    if (Progress.visible) { toast('Tunggu sehingga proses semasa selesai atau batalkan dahulu.', 'warn'); return; }
    const dirty = (ImageEditor.ed && ImageEditor.ed.userObjects().length) || (VideoEditor.ed && VideoEditor.ed.userObjects().length) ||
      VideoCompress.items.length || ImageCompress.items.length || Collage.tray.length || VideoEditor.track;
    if (dirty) {
      const r = await window.api.message({ message: 'Muat semula aplikasi?', detail: 'Kerja yang belum dimuat turun akan dikosongkan. Fail yang telah disimpan tidak terjejas.', buttons: ['Refresh', 'Batal'] });
      if (r !== 0) return;
    }
    const btn = $('#btnRefresh');
    btn.classList.add('pressed');
    await window.api.reload();
  },

  async initSettings() {
    const info = await window.api.appInfo();
    $('#verLabel').textContent = 'Versi ' + info.version;
    const renderOut = () => { $('#setOutDir').textContent = Settings.get('outDir'); };
    const ag = $('#setAutoGallery');
    if (ag) {
      ag.checked = Settings.get('autoGallery') !== false;
      ag.addEventListener('change', async () => { await Settings.set({ autoGallery: ag.checked }); toast(ag.checked ? 'Simpan automatik ke Galeri telefon: HIDUP' : 'Simpan automatik ke Galeri telefon: MATI', 'ok'); });
    }
    renderOut();
    $('#setTheme').addEventListener('click', (e) => { const b = e.target.closest('button[data-theme]'); if (b) this.setTheme(b.dataset.theme); });
    $('#setChooseOut').addEventListener('click', async () => {
      const p = await window.api.chooseFolder({ title: 'Pilih folder output' });
      if (p) { await Settings.set({ outDir: p }); renderOut(); toast('Folder output ditukar.', 'ok'); }
    });
    $('#setResetOut').addEventListener('click', async () => { await Settings.set({ outDir: info.defaultOutDir }); renderOut(); });
    $('#setOpenOut').addEventListener('click', () => window.api.openPath(Settings.get('outDir')));
    const ffv = hasFfmpeg() ? await window.api.ffmpeg.version() : 'Pemproses video peranti (MediaRecorder / WebView)';
    const rows = [['Versi aplikasi', info.version], ['Enjin video', ffv.replace(/Copyright.*/, '')], ['Electron', info.electron], ['Platform', info.platform],
      ['Pengecaman muka', 'face-api (TensorFlow.js) — luar talian'], ['Data tetapan', info.userData]];
    $('#setInfo').innerHTML = '';
    for (const [k, v] of rows) $('#setInfo').appendChild(h('tr', null, h('td', null, h('b', null, k)), h('td', null, v)));
    this.applyTheme(Settings.get('theme') || 'system');
  },

  onKey(e) {
    if (Progress.visible || !$('#shareModal').hidden) return;
    if (!$('#previewModal').hidden) { if (e.key === 'Escape') Gallery.closePreview(); return; }
    const tag = (document.activeElement && document.activeElement.tagName) || '';
    if (this.view === 'ieditor') { ImageEditor.ed.handleKey(e); return; }
    if (this.view === 'veditor') {
      if (VideoEditor.ed.handleKey(e)) return;
      const a = VideoEditor.ed.active();
      if (e.code === 'Space' && !['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON'].includes(tag) && !(a && a.isEditing)) { e.preventDefault(); VideoEditor.togglePlay(); }
    }
  },

  async openInImageEditor(path, nameHint) {
    this.go('ieditor');
    await new Promise((r) => requestAnimationFrame(r));
    await ImageEditor.open(path, nameHint);
  }
};

window.addEventListener('error', (e) => { console.error(e.error || e.message); });
window.addEventListener('unhandledrejection', (e) => { console.error(e.reason); });
document.addEventListener('DOMContentLoaded', () => App.init().catch((e) => { console.error(e); toast('Ralat permulaan: ' + e.message, 'err'); }));
