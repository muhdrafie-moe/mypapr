'use strict';
/*
 * MyEviden (dahulu MYPAPR) Android — penyesuai platform.
 * Melaksanakan antara muka `window.api` yang sama seperti versi Windows (preload.js),
 * menggunakan pemalam Capacitor. Tiada ffmpeg: pemprosesan video melalui WebVideo (MediaRecorder).
 *
 * Model laluan (rentetan):
 *   mem:/<id>/<nama>   fail dipilih pengguna (objek File dalam memori, sesi semasa)
 *   /MYPAPR/<nama>     hasil tersimpan dalam storan aplikasi (Directory.Data)
 *   /tmp/<...>         fail sementara (Directory.Cache)
 */
(function () {
  window.synapse = window.synapse || window.outsystemsSynapse;
  const Cap = window.Capacitor;
  const FS = window.capacitorFilesystemPluginCapacitor;
  const { Directory } = FS;
  const nativeCheck = Cap && Cap.isNativePlatform && Cap.isNativePlatform();

  /*
   * Mod pelayar / PWA (iPhone, iPad, komputer): fail disimpan sebagai Blob dalam IndexedDB
   * (lebih pantas & jimat memori berbanding teks base64). API serasi subset Filesystem.
   */
  const WebFS = (() => {
    let dbp = null;
    const open = () => dbp || (dbp = new Promise((res, rej) => {
      const r = indexedDB.open('mypapr-fail', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('f');
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    }));
    const run = async (mode, fn) => {
      const db = await open();
      return new Promise((res, rej) => {
        const t = db.transaction('f', mode);
        const req = fn(t.objectStore('f'));
        t.oncomplete = () => res(req && req.result);
        t.onerror = () => rej(t.error);
        t.onabort = () => rej(t.error || new Error('Storan penuh atau ditolak'));
      });
    };
    const key = (o) => o.directory + ':' + String(o.path).replace(/^\/+/, '');
    const api = {
      put: (o, blob) => run('readwrite', (st) => st.put({ blob, size: blob.size, mtime: Date.now() }, key(o))),
      get: (o) => run('readonly', (st) => st.get(key(o))),
      keys: () => run('readonly', (st) => st.getAllKeys()),
      async mkdir() { /* tiada folder sebenar */ },
      async getUri(o) { return { uri: key(o) }; },
      async stat(o) {
        const r = await api.get(o);
        if (r) return { type: 'file', size: r.size, mtime: r.mtime };
        const ks = await api.keys();
        if (ks.some((k) => k.startsWith(key(o) + '/'))) return { type: 'directory', size: 0, mtime: Date.now() };
        throw new Error('Tiada');
      },
      deleteFile: (o) => run('readwrite', (st) => st.delete(key(o))),
      async rmdir(o) {
        const pre = key(o) + '/';
        const ks = (await api.keys()).filter((k) => k.startsWith(pre));
        await run('readwrite', (st) => { ks.forEach((k) => st.delete(k)); return null; });
      },
      async readdir(o) {
        const pre = key(o) + '/';
        const names = (await api.keys()).filter((k) => k.startsWith(pre)).map((k) => k.slice(pre.length)).filter((n) => n && !n.includes('/'));
        return { files: names.map((name) => ({ name })) };
      }
    };
    return api;
  })();
  const Filesystem = nativeCheck ? FS.Filesystem : WebFS;
  const blobs = new Map();      // mod web: laluan → Blob (untuk kongsi segera tanpa menunggu)
  const ShareP = window.capacitorShare && window.capacitorShare.Share;
  const BrowserP = window.capacitorBrowser && window.capacitorBrowser.Browser;
  const ClipP = window.capacitorClipboard && window.capacitorClipboard.Clipboard;
  // pemalam asli MYPAPR (MypaprPlugin.java): simpan ke Galeri, kongsi, muat naik
  const NativeP = (Cap && Cap.isNativePlatform && Cap.isNativePlatform() && window.capacitorExports) ? window.capacitorExports.registerPlugin('Mypapr') : null;
  const native = nativeCheck;
  document.documentElement.classList.add('platform-mobile', native ? 'platform-android' : 'platform-web');
  if (!native && window.matchMedia('(display-mode: standalone)').matches) document.documentElement.classList.add('pwa-standalone');

  const VERSION = '1.5.0';
  const OUT = '/MYPAPR';
  const mem = new Map();        // mem:/id/name → File
  const blobUrls = new Map();   // laluan → blob: URL (memori & mod web)
  const base = {};              // Directory → URI asas (asli)

  const MIME = { jpg: 'image/jpeg', jpeg: 'image/jpeg', jfif: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif', bmp: 'image/bmp', avif: 'image/avif',
    mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', mkv: 'video/x-matroska', '3gp': 'video/3gpp', avi: 'video/x-msvideo' };
  const ext = (p) => { const m = /\.([^./\\]+)$/.exec(p || ''); return m ? m[1].toLowerCase() : ''; };
  const kindOf = (p) => { const m = MIME[ext(p)] || ''; return m.startsWith('image/') ? 'image' : m.startsWith('video/') ? 'video' : null; };
  const loc = (p) => {
    if (p.startsWith('/tmp/')) return { directory: Directory.Cache, path: p.slice(1) };
    return { directory: Directory.Data, path: p.replace(/^\/+/, '') };
  };
  const joinP = (...parts) => ('/' + parts.join('/')).replace(/\/+/g, '/').replace(/\/$/, '') || '/';

  async function init() {
    if (native) {
      for (const d of [Directory.Data, Directory.Cache]) {
        try { base[d] = (await Filesystem.getUri({ directory: d, path: '' })).uri.replace(/\/$/, ''); } catch (_) { /* abaikan */ }
      }
    }
    try { await Filesystem.mkdir({ directory: Directory.Data, path: 'MYPAPR', recursive: true }); } catch (_) { /* sudah wujud */ }
  }
  const ready = init();

  function fileUri(p) { const l = loc(p); return (base[l.directory] || '') + '/' + l.path; }
  /** Laluan mutlak sistem fail (untuk pemalam asli). */
  function absPath(p) { let u = fileUri(p).replace(/^file:\/\//, ''); try { u = decodeURI(u); } catch (_) { /* abaikan */ } return u; }
  const errMsg = (e) => String((e && (e.message || e.errorMessage)) || e || 'Ralat tidak diketahui');

  function mediaUrl(p) {
    if (!p) return '';
    if (blobUrls.has(p)) return blobUrls.get(p);
    if (p.startsWith('mem:')) {
      const f = mem.get(p);
      if (!f) return '';
      const u = URL.createObjectURL(f);
      blobUrls.set(p, u);
      return u;
    }
    if (native) return Cap.convertFileSrc(fileUri(p));
    return '';
  }

  // ---------- baca / tulis ----------
  function b64(bytes) {
    let s = '';
    const CH = 0x8000;
    for (let i = 0; i < bytes.length; i += CH) s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    return btoa(s);
  }
  async function writeBytes(p, bytes) {
    await ready;
    const l = loc(p);
    if (!native) {
      // PWA: simpan terus sebagai Blob
      const blob = new Blob([bytes], { type: MIME[ext(p)] || 'application/octet-stream' });
      await WebFS.put(l, blob);
      blobs.set(p, blob);
      if (blobUrls.has(p)) URL.revokeObjectURL(blobUrls.get(p));
      blobUrls.set(p, URL.createObjectURL(blob));
      if (p.startsWith(OUT + '/') && kindOf(p) && autoGallery()) offerSave(p);
      return { ok: true, path: p, size: bytes.length };
    }
    const CH = 3 * 1024 * 1024;
    const dir = l.path.split('/').slice(0, -1).join('/');
    if (dir) { try { await Filesystem.mkdir({ directory: l.directory, path: dir, recursive: true }); } catch (_) { /* wujud */ } }
    for (let i = 0; i < Math.max(1, bytes.length); i += CH) {
      const data = b64(bytes.subarray(i, i + CH));
      if (i === 0) await Filesystem.writeFile(Object.assign({ data }, l));
      else await Filesystem.appendFile(Object.assign({ data }, l));
    }
    // simpan automatik ke Galeri telefon bagi hasil akhir (folder /MYPAPR)
    if (p.startsWith(OUT + '/') && kindOf(p) && autoGallery()) {
      saveToPhone(p).then((r) => {
        if (window.toast) {
          if (r.ok) toast(`Juga disimpan ke Galeri telefon (${r.folder}).`, 'ok');
          else toast('Gagal simpan automatik ke Galeri: ' + r.error, 'warn');
        }
      });
    }
    if (!native) {
      if (blobUrls.has(p)) URL.revokeObjectURL(blobUrls.get(p));
      blobUrls.set(p, URL.createObjectURL(new Blob([bytes], { type: MIME[ext(p)] || 'application/octet-stream' })));
    }
    return { ok: true, path: p, size: bytes.length };
  }
  async function readBlob(p) {
    if (p.startsWith('mem:')) return mem.get(p);
    if (native) return (await fetch(mediaUrl(p))).blob();
    if (blobs.has(p)) return blobs.get(p);
    const r = await WebFS.get(loc(p));
    if (!r) throw new Error('Fail tidak dijumpai');
    blobs.set(p, r.blob);
    return r.blob;
  }
  async function stat(p) {
    if (p.startsWith('mem:')) { const f = mem.get(p); return f ? { ok: true, size: f.size, mtime: f.lastModified } : { ok: false }; }
    try { const s = await Filesystem.stat(loc(p)); return { ok: s.type !== 'directory', size: s.size, mtime: s.mtime || Date.now() }; } catch (_) { return { ok: false }; }
  }
  // mod web (ujian): pastikan URL blob tersedia untuk fail tersimpan
  async function ensureUrl(p) { if (!native && !blobUrls.has(p) && !p.startsWith('mem:')) { const b = await readBlob(p); blobUrls.set(p, URL.createObjectURL(b)); } }

  // ---------- pemilih fail ----------
  function openFiles(opts) {
    opts = opts || {};
    return new Promise((resolve) => {
      const inp = document.createElement('input');
      inp.type = 'file';
      inp.accept = opts.kind === 'video' ? 'video/*' : opts.kind === 'media' ? 'image/*,video/*' : 'image/*';
      inp.multiple = opts.multi !== false;
      inp.style.display = 'none';
      let done = false;
      const fin = (list) => { if (done) return; done = true; inp.remove(); resolve(list); };
      inp.addEventListener('change', () => {
        const out = [];
        for (const f of Array.from(inp.files || [])) {
          const id = 'mem:/' + Math.random().toString(36).slice(2, 10) + '/' + f.name.replace(/[\\/]/g, '_');
          mem.set(id, f);
          out.push(id);
        }
        fin(out);
      });
      inp.addEventListener('cancel', () => fin([]));
      document.body.appendChild(inp);
      inp.click();
    });
  }

  // ---------- tetapan & pustaka (localStorage) ----------
  const LS = {
    get(k, d) { try { const v = localStorage.getItem('mypapr:' + k); return v ? JSON.parse(v) : d; } catch (_) { return d; } },
    set(k, v) { try { localStorage.setItem('mypapr:' + k, JSON.stringify(v)); } catch (_) { /* abaikan */ } }
  };
  const defaults = { theme: 'system', outDir: OUT, videoPreset: 'recommended', imagePreset: 'recommended', autoGallery: true };
  const autoGallery = () => LS.get('settings', {}).autoGallery !== false;

  async function uniquePath(p) {
    if (!(await stat(p)).ok) return p;
    const e = ext(p), b = e ? p.slice(0, -(e.length + 1)) : p;
    for (let i = 2; i < 10000; i++) { const c = `${b}_${i}${e ? '.' + e : ''}`; if (!(await stat(c)).ok) return c; }
    return `${b}-${Date.now()}.${e}`;
  }

  function downloadBlob(b, name) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(b);
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 60000);
  }
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  /**
   * PWA: tawarkan SATU butang simpan untuk semua hasil yang belum disimpan
   * (iOS memerlukan tekanan pengguna untuk helaian kongsi; semua fail dikongsi sekali gus).
   */
  const pending = [];
  let offerEl = null, offerTimer = null;
  function offerSave(p) {
    if (!pending.includes(p)) pending.push(p);
    const box = document.getElementById('toasts');
    if (!box) return;
    if (!offerEl || !offerEl.isConnected) {
      offerEl = document.createElement('div');
      offerEl.className = 'toast ok save-offer';
      offerEl.innerHTML = '<b></b><div class="offer-name"></div><div class="offer-row"></div>';
      const btn = document.createElement('button');
      btn.className = 'btn btn-success btn-sm';
      btn.textContent = isIOS ? 'Simpan ke Foto / Kongsi' : 'Simpan / Kongsi';
      btn.addEventListener('click', async () => {
        const list = pending.splice(0);
        offerEl.remove();
        const r = await shareMany(list);
        if (!r.ok && window.toast) toast(r.error, 'err', 'Gagal');
      });
      const close = document.createElement('button');
      close.className = 'btn btn-ghost btn-sm';
      close.textContent = 'Nanti';
      close.title = 'Fail kekal dalam Galeri Saya';
      close.addEventListener('click', () => { pending.splice(0); offerEl.remove(); });
      offerEl.querySelector('.offer-row').append(btn, close);
      box.appendChild(offerEl);
    }
    offerEl.querySelector('b').textContent = pending.length > 1 ? `${pending.length} hasil sedia` : 'Hasil sedia';
    offerEl.querySelector('.offer-name').textContent = pending.length > 1 ? 'Simpan semua ke Foto sekali gus' : pending[0].split('/').pop();
    clearTimeout(offerTimer);
    offerTimer = setTimeout(() => { if (offerEl) offerEl.remove(); pending.splice(0); }, 25000);
  }
  /** PWA: kongsi beberapa fail sekali gus (iPhone: "Simpan N Video/Imej"). */
  async function shareMany(list) {
    if (list.length === 1) return shareFile(list[0], 'Simpan ke Foto');
    try {
      const files = [];
      for (const p of list) { const b = blobs.get(p) || await readBlob(p); files.push(new File([b], p.split('/').pop(), { type: b.type || MIME[ext(p)] })); }
      if (navigator.canShare && navigator.canShare({ files })) { await navigator.share({ files }); return { ok: true }; }
      for (const f of files) downloadBlob(f, f.name);
      return { ok: true, downloaded: true };
    } catch (e) {
      if (/cancel|abort/i.test(errMsg(e))) return { ok: true, cancelled: true };
      return { ok: false, error: errMsg(e) };
    }
  }

  /** Kongsi fail melalui helaian kongsi Android. Pulangkan {ok, error}. */
  async function shareFile(p, title) {
    try {
      if (p.startsWith('mem:')) throw new Error('Simpan fail dahulu sebelum berkongsi.');
      if (NativeP) { await NativeP.shareFile({ path: absPath(p), mime: MIME[ext(p)] || '', title: title || 'Kongsi melalui' }); return { ok: true }; }
      if (!native) {
        const b = blobs.get(p) || await readBlob(p);
        const f = new File([b], p.split('/').pop(), { type: b.type || MIME[ext(p)] });
        if (navigator.canShare && navigator.canShare({ files: [f] })) { await navigator.share({ files: [f] }); return { ok: true }; }
        downloadBlob(b, f.name);
        return { ok: true, downloaded: true };
      }
      if (ShareP) { await ShareP.share({ title: title || 'MyEviden', files: [fileUri(p)] }); return { ok: true }; }
      return { ok: false, error: 'Perkongsian tidak disokong pada peranti ini.' };
    } catch (e) {
      if (/cancel|abort/i.test(errMsg(e))) return { ok: true, cancelled: true };
      return { ok: false, error: errMsg(e) };
    }
  }

  /** Simpan salinan ke Galeri telefon (Movies/MyEviden atau Pictures/MyEviden). */
  async function saveToPhone(p) {
    try {
      if (p.startsWith('mem:')) throw new Error('Fail belum disimpan.');
      if (NativeP) {
        const r = await NativeP.saveToGallery({ path: absPath(p), name: p.split('/').pop(), mime: MIME[ext(p)] || '' });
        return { ok: true, folder: r.folder };
      }
      // PWA: iPhone/iPad → helaian kongsi (pilih "Simpan Video"/"Simpan Imej"); komputer → muat turun
      const r = await shareFile(p, 'Simpan ke Foto');
      if (!r.ok) return r;
      if (r.cancelled) return { ok: false, error: 'Dibatalkan.' };
      return { ok: true, folder: r.downloaded ? 'Muat Turun' : 'Foto (melalui Kongsi)' };
    } catch (e) { return { ok: false, error: errMsg(e) }; }
  }

  // ---------- muat naik (Jana URL) ----------
  const SERVICES = {
    catbox: { url: 'https://catbox.moe/user/api.php', max: 200 * 1024 * 1024, label: 'Catbox (kekal)' },
    litterbox: { url: 'https://litterbox.catbox.moe/resources/internals/api.php', max: 1024 * 1024 * 1024, label: 'Litterbox (sementara)' }
  };
  const shareListeners = new Set();
  const uploads = new Map();
  const emit = (d) => { for (const cb of shareListeners) { try { cb(d); } catch (_) { /* abaikan */ } } };

  async function upload(jobId, p, opts) {
    const svc = SERVICES[opts.service] || SERVICES.litterbox;
    const blob = await readBlob(p);
    if (!blob) return { ok: false, error: 'Fail tidak dijumpai' };
    if (blob.size > svc.max) return { ok: false, error: `Fail terlalu besar (${(blob.size / 1048576).toFixed(0)} MB). Had ${svc.max / 1048576} MB — mampatkan dahulu.` };
    const endpoint = window.MYPAPR_UPLOAD_URL || svc.url;
    const name = p.split('/').pop().replace(/[^\w.\- ()]/g, '_');
    const fields = { reqtype: 'fileupload' };
    if (opts.service === 'litterbox') fields.time = ['1h', '12h', '24h', '72h'].includes(opts.time) ? opts.time : '72h';
    // Android: muat naik asli secara streaming (tiada sekatan CORS, tiada masalah memori)
    if (NativeP && !p.startsWith('mem:')) {
      let sub = null;
      try {
        sub = await NativeP.addListener('uploadProgress', (d) => { if (d.jobId === jobId) emit({ jobId, sent: d.sent, total: d.total, percent: d.total ? d.sent / d.total * 100 : 0 }); });
        uploads.set(jobId, () => NativeP.cancelUpload({ jobId }));
        const r = await NativeP.upload({ jobId, path: absPath(p), url: endpoint, fields, fileField: 'fileToUpload', fileName: name, mime: blob.type || MIME[ext(p)] || '' });
        if (r.cancelled) return { ok: false, cancelled: true };
        const t = String(r.body || '').trim();
        if (r.status >= 200 && r.status < 300 && /^https?:\/\/\S+$/.test(t)) return { ok: true, url: t };
        return { ok: false, error: `Pelayan menolak (${r.status}): ${t.slice(0, 160) || 'tiada respons'}` };
      } catch (e) {
        return { ok: false, error: errMsg(e) };
      } finally {
        uploads.delete(jobId);
        if (sub && sub.remove) sub.remove();
      }
    }
    // 1) XHR biasa (ada kemajuan)
    const viaXhr = await new Promise((resolve) => {
      const fd = new FormData();
      for (const [k, v] of Object.entries(fields)) fd.append(k, v);
      fd.append('fileToUpload', blob, name);
      const x = new XMLHttpRequest();
      uploads.set(jobId, () => { x.abort(); resolve({ ok: false, cancelled: true }); });
      x.open('POST', endpoint);
      x.upload.onprogress = (e) => { if (e.lengthComputable) emit({ jobId, sent: e.loaded, total: e.total, percent: e.loaded / e.total * 100 }); };
      x.onload = () => {
        const t = (x.responseText || '').trim();
        if (x.status >= 200 && x.status < 300 && /^https?:\/\/\S+$/.test(t)) resolve({ ok: true, url: t });
        else resolve({ ok: false, error: `Pelayan menolak (${x.status}): ${t.slice(0, 160)}` });
      };
      x.onerror = () => resolve({ ok: false, network: true });
      x.send(fd);
    });
    uploads.delete(jobId);
    if (viaXhr.network) return { ok: false, error: 'Tiada sambungan internet atau pelayan tidak dapat dicapai.' };
    return viaXhr;
  }

  window.api = {
    platform: 'android',
    mediaUrl,
    pathForFile: () => '',
    openFiles,
    saveFile: async (opts) => { await ready; return uniquePath(joinP(OUT, (opts && opts.name) || ('fail_' + Date.now()))); },
    chooseFolder: async () => null,
    message: async (o) => (window.confirm([o.message, o.detail].filter(Boolean).join('\n\n')) ? 0 : 1),
    fileInfo: async (p) => { await ready; const s = await stat(p); return s.ok ? { ok: true, size: s.size, name: p.split('/').pop(), ext: ext(p), mtime: s.mtime } : { ok: false, error: 'Tiada' }; },
    writeFile: (p, data) => writeBytes(p, data instanceof Uint8Array ? data : new Uint8Array(data)),
    writeText: (p, text) => writeBytes(p, new TextEncoder().encode(text)),
    copyFile: async (src) => { const r = await shareFile(src, 'Simpan / kongsi fail'); if (!r.ok) throw new Error(r.error); return r; },
    remove: async (p) => { try { const s = await Filesystem.stat(loc(p)); if (s.type === 'directory') await Filesystem.rmdir(Object.assign({ recursive: true }, loc(p))); else await Filesystem.deleteFile(loc(p)); return true; } catch (_) { return false; } },
    countFiles: async (dir, prefix) => { try { const r = await Filesystem.readdir(loc(dir)); return r.files.filter((f) => (f.name || f).startsWith(prefix || '')).length; } catch (_) { return 0; } },
    uniquePath: async (p) => { await ready; return uniquePath(p); },
    join: async (...parts) => joinP(...parts),
    ensureDir: async (p) => { try { await Filesystem.mkdir(Object.assign({ recursive: true }, loc(p))); } catch (_) { /* wujud */ } return p; },
    tempDir: async (prefix) => { const p = '/tmp/' + (prefix || 'job') + '-' + Math.random().toString(36).slice(2, 8); try { await Filesystem.mkdir(Object.assign({ recursive: true }, loc(p))); } catch (_) { /* abaikan */ } return p; },
    showItem: async (p) => { const r = await shareFile(p); if (!r.ok && window.toast) toast(r.error, 'err', 'Gagal berkongsi'); return true; },
    openPath: async () => { if (window.App) App.go('gallery'); return ''; },
    getSettings: async () => Object.assign({}, defaults, LS.get('settings', {}), { outDir: OUT }),
    setSettings: async (patch) => { const s = Object.assign({}, defaults, LS.get('settings', {}), patch || {}, { outDir: OUT }); LS.set('settings', s); return s; },
    appInfo: async () => ({ version: VERSION, platform: native ? 'android' : 'web', ffmpeg: '-', userData: 'Storan aplikasi (dalaman)', electron: '-', defaultOutDir: OUT, isPackaged: true }),
    reload: async () => { location.reload(); return true; },
    onRefreshRequest: () => () => {},
    library: {
      async list() {
        await ready;
        const lib = LS.get('library', { items: [], links: [] });
        const seen = new Map();
        const add = async (p, source) => {
          const kind = kindOf(p);
          if (!kind || seen.has(p)) return;
          const s = await stat(p);
          if (!s.ok) return;
          await ensureUrl(p).catch(() => {});
          seen.set(p, { path: p, name: p.split('/').pop(), size: s.size, mtime: s.mtime, kind, source });
        };
        try { const r = await Filesystem.readdir(loc(OUT)); for (const f of r.files) await add(joinP(OUT, f.name || f), 'output'); } catch (_) { /* kosong */ }
        for (const it of lib.items) await add(it.path, 'saved');
        const items = Array.from(seen.values()).map((it) => Object.assign(it, { links: lib.links.filter((l) => l.path === it.path) }));
        items.sort((a, b) => b.mtime - a.mtime);
        return { items, links: lib.links };
      },
      async add(p) { if (p.startsWith('mem:')) return true; const lib = LS.get('library', { items: [], links: [] }); if (!lib.items.some((i) => i.path === p)) lib.items.unshift({ path: p, added: Date.now() }); lib.items = lib.items.slice(0, 2000); LS.set('library', lib); return true; },
      async trash(p) { try { await Filesystem.deleteFile(loc(p)); } catch (e) { return { ok: false, error: e.message }; } const lib = LS.get('library', { items: [], links: [] }); lib.items = lib.items.filter((i) => i.path !== p); LS.set('library', lib); return { ok: true }; },
      async addLink(l) { const lib = LS.get('library', { items: [], links: [] }); lib.links.unshift(Object.assign({ created: Date.now() }, l)); lib.links = lib.links.slice(0, 1000); LS.set('library', lib); return lib.links; },
      async removeLink(u) { const lib = LS.get('library', { items: [], links: [] }); lib.links = lib.links.filter((l) => l.url !== u); LS.set('library', lib); return lib.links; }
    },
    share: {
      upload,
      cancel: async (jobId) => { const f = uploads.get(jobId); if (f) f(); return !!f; },
      services: async () => SERVICES,
      onProgress: (cb) => { shareListeners.add(cb); return () => shareListeners.delete(cb); }
    },
    copyText: async (t) => { try { if (ClipP) await ClipP.write({ string: String(t) }); else await navigator.clipboard.writeText(String(t)); } catch (_) { await navigator.clipboard.writeText(String(t)); } return true; },
    openExternal: async (u) => { if (!/^https?:\/\//.test(u)) return false; if (BrowserP && native) await BrowserP.open({ url: u }); else window.open(u, '_blank'); return true; },
    /** Android sahaja: kongsi fail melalui helaian kongsi (WhatsApp, Drive, dll.) */
    shareFile,
    /** Android sahaja: simpan salinan ke Galeri telefon */
    saveToPhone,
    ffmpeg: null
  };
})();
