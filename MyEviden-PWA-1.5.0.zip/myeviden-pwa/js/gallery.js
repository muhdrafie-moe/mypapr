'use strict';
/* Modul: Galeri Saya — pustaka semua hasil (video & gambar) dalam aplikasi */
const Gallery = {
  filter: 'all',
  q: '',
  sort: 'new',
  data: { items: [], links: [] },
  thumbs: new Map(),
  observer: null,

  init() {
    $('#glTabs').addEventListener('click', (e) => {
      const b = e.target.closest('button[data-f]'); if (!b) return;
      this.filter = b.dataset.f;
      $$('#glTabs button').forEach((x) => x.classList.toggle('on', x === b));
      this.render();
    });
    $('#glSearch').addEventListener('input', debounce((e) => { this.q = e.target.value.trim().toLowerCase(); this.render(); }, 150));
    $('#glSort').addEventListener('change', (e) => { this.sort = e.target.value; this.render(); });
    $('#glRefresh').addEventListener('click', () => this.load());
    $('#glOpen').addEventListener('click', () => window.api.openPath(Settings.get('outDir')));
    $('#glImport').addEventListener('click', async () => {
      const paths = await window.api.openFiles({ kind: 'media', title: 'Tambah fail ke Galeri' });
      for (const p of paths) await window.api.library.add(p);
      if (paths.length) { toast(paths.length + ' fail ditambah ke Galeri.', 'ok'); this.load(); }
    });
    setupDrop($('#view-gallery'), 'media', async (paths) => { for (const p of paths) await window.api.library.add(p); this.load(); });
    $('#pvClose').addEventListener('click', () => this.closePreview());
    $('#previewModal').addEventListener('click', (e) => { if (e.target.id === 'previewModal') this.closePreview(); });
    this.observer = new IntersectionObserver((ents) => {
      for (const en of ents) if (en.isIntersecting) { this.observer.unobserve(en.target); this.fillThumb(en.target); }
    }, { rootMargin: '200px' });
  },

  async load() {
    this.data = await window.api.library.list();
    this.render();
  },

  visible() {
    let items = this.data.items.filter((it) => (this.filter === 'all' || it.kind === this.filter) && (!this.q || it.name.toLowerCase().includes(this.q)));
    const by = { new: (a, b) => b.mtime - a.mtime, old: (a, b) => a.mtime - b.mtime, name: (a, b) => a.name.localeCompare(b.name), size: (a, b) => b.size - a.size }[this.sort];
    return items.sort(by);
  },

  render() {
    const grid = $('#glGrid');
    grid.innerHTML = '';
    const nv = this.data.items.filter((i) => i.kind === 'video').length, ni = this.data.items.length - nv;
    $('#glInfo').textContent = `${this.data.items.length} fail (${nv} video, ${ni} gambar) • ${this.data.links.length} pautan URL • Folder: ${Settings.get('outDir')}`;
    if (this.filter === 'links') { this.renderLinks(grid); return; }
    const items = this.visible();
    if (!items.length) {
      grid.appendChild(h('div', { class: 'empty-note' }, this.data.items.length ? 'Tiada fail sepadan dengan carian.' : 'Galeri masih kosong. Hasil mampatan, kolaj dan suntingan akan muncul di sini secara automatik.'));
      return;
    }
    for (const it of items) grid.appendChild(this.card(it));
    applyIcons(grid);
  },

  card(it) {
    const thumb = h('div', { class: 'gl-thumb', title: 'Lihat / main' });
    thumb.dataset.path = it.path; thumb.dataset.kind = it.kind; thumb.dataset.key = it.path + '|' + it.mtime;
    if (it.kind === 'image') thumb.appendChild(h('img', { src: window.api.mediaUrl(it.path), loading: 'lazy' }));
    else {
      const cached = this.thumbs.get(thumb.dataset.key);
      if (cached) thumb.appendChild(h('img', { src: cached }));
      else this.observer.observe(thumb);
      thumb.appendChild(h('div', { class: 'play' }, h('span', { 'data-icon': 'play' })));
    }
    thumb.appendChild(h('span', { class: 'gl-kind' }, it.kind === 'video' ? 'VIDEO' : 'GAMBAR'));
    const live = (it.links || []).filter((l) => !l.expires || l.expires > Date.now());
    if (live.length) thumb.appendChild(h('span', { class: 'gl-link', title: live[0].url }, '🔗 URL'));
    thumb.addEventListener('click', () => this.preview(it));
    const d = new Date(it.mtime);
    const actions = h('div', { class: 'gl-actions' },
      iconBtn(it.kind === 'video' ? 'play' : 'eye', it.kind === 'video' ? 'Main' : 'Lihat', 'btn-primary btn-sm', () => this.preview(it)),
      live.length ? iconBtn('copy', 'Salin URL', 'btn-success btn-sm', async () => { await window.api.copyText(live[0].url); toast('Pautan disalin: ' + live[0].url, 'ok'); })
        : iconBtn('link', 'URL', 'btn-ghost btn-sm', () => Share.open(it.path), 'Jana URL'),
      iconBtn('edit', '', 'btn-ghost btn-sm', () => this.edit(it), 'Edit'),
      ...this.platformButtons(it),
      iconBtn('trash', '', 'btn-ghost btn-sm', () => this.remove(it), 'Padam (ke Recycle Bin)'));
    return h('div', { class: 'gl-card card' }, thumb,
      h('div', { class: 'item-name', title: it.path }, it.name),
      h('div', { class: 'item-meta' }, h('span', null, formatBytes(it.size)), h('span', null, d.toLocaleDateString('ms-MY') + ' ' + d.toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit' }))),
      actions);
  },

  async fillThumb(el) {
    const url = await videoThumb(el.dataset.path, 1);
    if (!url) return;
    this.thumbs.set(el.dataset.key, url);
    el.insertBefore(h('img', { src: url }), el.firstChild);
  },

  renderLinks(grid) {
    const links = this.data.links.filter((l) => !this.q || (l.name || '').toLowerCase().includes(this.q));
    if (!links.length) { grid.appendChild(h('div', { class: 'empty-note' }, 'Belum ada pautan. Tekan butang "URL" pada mana-mana fail untuk menjana pautan.')); return; }
    const tb = h('table', { class: 'links-table' });
    for (const l of links) {
      const expired = l.expires && l.expires < Date.now();
      const st = l.expires ? (expired ? 'Telah luput' : 'Luput ' + new Date(l.expires).toLocaleString('ms-MY')) : 'Kekal';
      const a = h('a', { title: 'Buka dalam pelayar' }, l.url);
      a.addEventListener('click', () => window.api.openExternal(l.url));
      tb.appendChild(h('tr', null,
        h('td', null, h('b', null, l.name || ''), h('br'), h('span', { class: 'muted small' }, new Date(l.created).toLocaleString('ms-MY'))),
        h('td', null, a),
        h('td', null, h('span', { class: 'badge ' + (expired ? 'err' : 'ok') }, st)),
        h('td', null,
          iconBtn('copy', 'Salin', 'btn-primary btn-sm', async () => { await window.api.copyText(l.url); toast('Pautan disalin.', 'ok'); }), ' ',
          iconBtn('qr', '', 'btn-ghost btn-sm', () => this.showQr(l), 'Kod QR'), ' ',
          iconBtn('x', '', 'btn-ghost btn-sm', async () => { await window.api.library.removeLink(l.url); this.load(); }, 'Buang daripada senarai'))));
    }
    grid.appendChild(h('div', { style: { gridColumn: '1 / -1' } }, tb));
    applyIcons(grid);
  },

  showQr(l) {
    const c = h('canvas', { width: 360, height: 360, style: { background: '#fff', borderRadius: '12px', width: '300px', height: '300px' } });
    Share.drawQr(l.url, c);
    this.openPreview(l.name || 'Kod QR', c, [iconBtn('copy', 'Salin URL', 'btn-primary btn-sm', async () => { await window.api.copyText(l.url); toast('Pautan disalin.', 'ok'); })]);
  },

  preview(it) {
    let el;
    if (it.kind === 'video') { el = h('video', { src: window.api.mediaUrl(it.path), controls: true, autoplay: true }); }
    else el = h('img', { src: window.api.mediaUrl(it.path) });
    this.openPreview(it.name, el, [
      iconBtn('link', 'Jana URL', 'btn-success btn-sm', () => { this.closePreview(); Share.open(it.path); }),
      iconBtn('edit', 'Edit', 'btn-ghost btn-sm', () => { this.closePreview(); this.edit(it); }),
      ...this.platformButtons(it, true)]);
  },
  openPreview(title, el, actions) {
    $('#pvTitle').textContent = title;
    $('#pvBody').innerHTML = '';
    $('#pvBody').appendChild(el);
    $('#pvActions').innerHTML = '';
    actions.forEach((a) => $('#pvActions').appendChild(a));
    $('#previewModal').hidden = false;
    applyIcons($('#previewModal'));
  },
  closePreview() {
    const v = $('#pvBody video');
    if (v) { v.pause(); v.removeAttribute('src'); v.load(); }
    $('#previewModal').hidden = true;
  },

  /** Windows: tunjuk dalam folder. Android: simpan ke Galeri telefon + kongsi (WhatsApp, Drive…). */
  platformButtons(it, labels) {
    if (window.api.saveToPhone) {
      return [
        iconBtn('download', labels ? 'Simpan ke Telefon' : '', 'btn-ghost btn-sm', () => phoneSave(it.path), 'Simpan salinan ke Galeri telefon'),
        iconBtn('upload', labels ? 'Kongsi' : '', 'btn-ghost btn-sm', () => phoneShare(it.path), 'Kongsi fail (WhatsApp, Drive, dll.)')
      ];
    }
    return [iconBtn('folder', labels ? 'Tunjuk dalam folder' : '', 'btn-ghost btn-sm', () => window.api.showItem(it.path), 'Tunjuk dalam folder')];
  },

  async edit(it) {
    if (it.kind === 'image') App.openInImageEditor(it.path);
    else { App.go('veditor'); await VideoEditor.open(it.path); }
  },

  async remove(it) {
    const r = await window.api.message({ message: 'Padam fail ini?', detail: it.name + '\nFail akan dipindahkan ke Recycle Bin.', buttons: ['Padam', 'Batal'], type: 'warning' });
    if (r !== 0) return;
    const res = await window.api.library.trash(it.path);
    if (res.ok) toast('Fail dipadam.', 'ok'); else toast(res.error, 'err');
    this.load();
  }
};
