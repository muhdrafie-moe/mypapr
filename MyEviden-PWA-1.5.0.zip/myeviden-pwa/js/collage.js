'use strict';
/* Modul: Kolaj Gambar */
const T = 1 / 3;
const COLLAGE_LAYOUTS = [
  { name: 'Satu', cells: [[0, 0, 1, 1]] },
  { name: '2 lajur', cells: [[0, 0, .5, 1], [.5, 0, .5, 1]] },
  { name: '2 baris', cells: [[0, 0, 1, .5], [0, .5, 1, .5]] },
  { name: '3 lajur', cells: [[0, 0, T, 1], [T, 0, T, 1], [2 * T, 0, T, 1]] },
  { name: '3 baris', cells: [[0, 0, 1, T], [0, T, 1, T], [0, 2 * T, 1, T]] },
  { name: 'Besar kiri + 2', cells: [[0, 0, .5, 1], [.5, 0, .5, .5], [.5, .5, .5, .5]] },
  { name: 'Besar atas + 2', cells: [[0, 0, 1, .5], [0, .5, .5, .5], [.5, .5, .5, .5]] },
  { name: 'Grid 2×2', cells: [[0, 0, .5, .5], [.5, 0, .5, .5], [0, .5, .5, .5], [.5, .5, .5, .5]] },
  { name: 'Bata 4', cells: [[0, 0, .6, .5], [.6, 0, .4, .5], [0, .5, .4, .5], [.4, .5, .6, .5]] },
  { name: 'Besar atas + 3', cells: [[0, 0, 1, .6], [0, .6, T, .4], [T, .6, T, .4], [2 * T, .6, T, .4]] },
  { name: 'Besar kiri + 3', cells: [[0, 0, .6, 1], [.6, 0, .4, T], [.6, T, .4, T], [.6, 2 * T, .4, T]] },
  { name: '4 lajur', cells: [[0, 0, .25, 1], [.25, 0, .25, 1], [.5, 0, .25, 1], [.75, 0, .25, 1]] },
  { name: '2 + 3', cells: [[0, 0, .5, .5], [.5, 0, .5, .5], [0, .5, T, .5], [T, .5, T, .5], [2 * T, .5, T, .5]] },
  { name: 'Kincir', cells: [[0, 0, .6, .4], [.6, 0, .4, .6], [.4, .6, .6, .4], [0, .4, .4, .6], [.4, .4, .2, .2]] },
  { name: 'Mozaik 6', cells: [[0, 0, 2 * T, 2 * T], [2 * T, 0, T, T], [2 * T, T, T, T], [0, 2 * T, T, T], [T, 2 * T, T, T], [2 * T, 2 * T, T, T]] },
  { name: 'Grid 3×2', cells: [[0, 0, T, .5], [T, 0, T, .5], [2 * T, 0, T, .5], [0, .5, T, .5], [T, .5, T, .5], [2 * T, .5, T, .5]] },
  { name: 'Grid 2×3', cells: [[0, 0, .5, T], [.5, 0, .5, T], [0, T, .5, T], [.5, T, .5, T], [0, 2 * T, .5, T], [.5, 2 * T, .5, T]] },
  { name: 'Grid 3×3', cells: [0, 1, 2].flatMap((r) => [0, 1, 2].map((c) => [c * T, r * T, T, T])) }
];
const RATIOS = { '1:1': 1, '4:5': 4 / 5, '3:4': 3 / 4, '9:16': 9 / 16, '16:9': 16 / 9, '4:3': 4 / 3, 'A4': 1 / 1.4142 };

const Collage = {
  layout: 7,
  ratio: '1:1',
  gap: 12,
  radius: 16,
  bg: '#ffffff',
  res: 1600,
  tray: [],
  cells: [],
  sel: 0,
  drag: null,

  init() {
    this.canvas = $('#clCanvas');
    this.buildLayouts();
    this.setLayout(7);
    $('#clRatio').addEventListener('click', (e) => {
      const b = e.target.closest('button[data-r]'); if (!b) return;
      this.ratio = b.dataset.r;
      $$('#clRatio button').forEach((x) => x.classList.toggle('on', x === b));
      this.fit();
    });
    const bindRange = (id, key) => {
      const inp = $('#' + id); const out = $('#' + id + 'V');
      inp.addEventListener('input', () => { this[key] = +inp.value; out.textContent = inp.value; this.draw(); });
    };
    bindRange('clGap', 'gap'); bindRange('clRad', 'radius');
    $('#clBg').addEventListener('input', (e) => { this.bg = e.target.value; this.draw(); });
    $('#clRes').addEventListener('change', (e) => { this.res = +e.target.value; });
    $('#clAdd').addEventListener('click', async () => this.addPaths(await window.api.openFiles({ kind: 'image', title: 'Pilih gambar untuk kolaj' })));
    $('#clAuto').addEventListener('click', () => this.autoFill());
    $('#clShuffle').addEventListener('click', () => this.shuffle());
    $('#clClearCell').addEventListener('click', () => { const c = this.cells[this.sel]; if (c) { c.img = null; this.draw(); this.renderTray(); } });
    $('#clExport').addEventListener('click', () => this.exportImage());
    $('#clShare').addEventListener('click', async () => {
      if (!this.cells.some((c) => c.img)) { toast('Kolaj masih kosong. Tambah gambar dahulu.', 'warn'); return; }
      const r = await this.exportImage(await outputPath('kolaj_' + timestamp() + '.jpg'));
      if (r) Share.open(r);
    });
    $('#clToEditor').addEventListener('click', () => this.toEditor());
    setupDrop($('#clTray'), 'image', (p) => this.addPaths(p));
    this.bindCanvas();
    new ResizeObserver(() => this.fit()).observe($('#clStage'));
    this.renderTray();
  },

  buildLayouts() {
    const box = $('#clLayouts');
    box.innerHTML = '';
    COLLAGE_LAYOUTS.forEach((L, i) => {
      const rects = L.cells.map(([x, y, w, hh]) => `<rect x="${x * 100 + 3}" y="${y * 100 + 3}" width="${w * 100 - 6}" height="${hh * 100 - 6}" rx="5"/>`).join('');
      const b = h('button', { class: 'layout-btn', title: L.name + ' (' + L.cells.length + ' gambar)', html: `<svg viewBox="0 0 100 100">${rects}</svg>`, 'data-i': i });
      b.addEventListener('click', () => this.setLayout(i));
      box.appendChild(b);
    });
  },

  setLayout(i) {
    const prev = this.cells.map((c) => c.img).filter(Boolean);
    this.layout = i;
    this.cells = COLLAGE_LAYOUTS[i].cells.map((r, k) => ({ rect: r, img: prev[k] || null, zoom: 1, ox: 0, oy: 0 }));
    this.sel = 0;
    $$('#clLayouts .layout-btn').forEach((b) => b.classList.toggle('on', +b.dataset.i === i));
    this.fit();
    this.renderTray();
  },

  async addPaths(paths) {
    if (!paths || !paths.length) return;
    let added = 0;
    for (const p of paths) {
      try {
        const img = await loadImagePath(p);
        this.tray.push({ path: p, img, id: uid('t') });
        added++;
      } catch (e) { toast('Gagal membuka: ' + baseName(p), 'err'); }
    }
    if (added) {
      // isi petak kosong secara automatik
      const free = this.cells.filter((c) => !c.img);
      const unused = this.tray.filter((t) => !this.cells.some((c) => c.img === t));
      free.forEach((c, k) => { if (unused[k]) { c.img = unused[k]; c.zoom = 1; c.ox = 0; c.oy = 0; } });
    }
    this.renderTray();
    this.draw();
  },

  autoFill() {
    if (!this.tray.length) { toast('Tambah gambar dahulu.', 'warn'); return; }
    this.cells.forEach((c, k) => { c.img = this.tray[k % this.tray.length]; c.zoom = 1; c.ox = 0; c.oy = 0; });
    this.renderTray(); this.draw();
  },
  shuffle() {
    const imgs = this.cells.map((c) => c.img);
    for (let i = imgs.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [imgs[i], imgs[j]] = [imgs[j], imgs[i]]; }
    this.cells.forEach((c, k) => { c.img = imgs[k]; c.ox = 0; c.oy = 0; c.zoom = 1; });
    this.draw();
  },

  renderTray() {
    const tray = $('#clTray');
    tray.innerHTML = '';
    if (!this.tray.length) { tray.appendChild(h('div', { class: 'tray-empty muted small', html: 'Tiada gambar. Tekan <b>Tambah Gambar</b> atau seret fail ke sini.' })); return; }
    this.tray.forEach((t, i) => {
      const used = this.cells.some((c) => c.img === t);
      const im = h('img', { src: window.api.mediaUrl(t.path), draggable: 'true', title: baseName(t.path) + ' — seret ke petak' });
      im.addEventListener('dragstart', (e) => { e.dataTransfer.setData('text/mypapr-tray', String(i)); e.dataTransfer.effectAllowed = 'copy'; });
      im.addEventListener('click', () => { const c = this.cells[this.sel]; if (c) { c.img = t; c.zoom = 1; c.ox = 0; c.oy = 0; this.draw(); this.renderTray(); } });
      const del = h('button', { title: 'Buang' }, '×');
      del.addEventListener('click', () => {
        this.cells.forEach((c) => { if (c.img === t) c.img = null; });
        this.tray.splice(i, 1);
        this.renderTray(); this.draw();
      });
      tray.appendChild(h('div', { class: 'tray-img' + (used ? ' used' : '') }, im, del));
    });
  },

  size(longSide) {
    const r = RATIOS[this.ratio] || 1;
    return r >= 1 ? [longSide, Math.round(longSide / r)] : [Math.round(longSide * r), longSide];
  },

  fit() {
    const st = $('#clStage').getBoundingClientRect();
    if (st.width < 20) return;
    const r = RATIOS[this.ratio] || 1;
    let w = st.width - 30, hh = w / r;
    if (hh > st.height - 30) { hh = st.height - 30; w = hh * r; }
    w = Math.max(50, Math.floor(w)); hh = Math.max(50, Math.floor(hh));
    const dpr = window.devicePixelRatio || 1;
    this.canvas.width = Math.round(w * dpr); this.canvas.height = Math.round(hh * dpr);
    this.canvas.style.width = w + 'px'; this.canvas.style.height = hh + 'px';
    this.cssW = w; this.cssH = hh;
    this.draw();
  },

  cellRect(cell, W, H, scale) {
    const g = this.gap * scale;
    const [x, y, w, hh] = cell.rect;
    const e = 1e-6;
    const l = x * W + (x < e ? g : g / 2);
    const t = y * H + (y < e ? g : g / 2);
    const r = (x + w) * W - (x + w > 1 - e ? g : g / 2);
    const b = (y + hh) * H - (y + hh > 1 - e ? g : g / 2);
    return { x: l, y: t, w: Math.max(1, r - l), h: Math.max(1, b - t) };
  },

  /** Lukis kolaj ke konteks. scale = nisbah piksel terhadap rujukan 1000px. */
  render(ctx, W, H, preview) {
    const scale = Math.max(W, H) / 1000;
    ctx.save();
    ctx.fillStyle = this.bg;
    ctx.fillRect(0, 0, W, H);
    this.cells.forEach((c, i) => {
      const R = this.cellRect(c, W, H, scale);
      const rad = Math.min(this.radius * scale, R.w / 2, R.h / 2);
      ctx.save();
      ctx.beginPath();
      ctx.roundRect(R.x, R.y, R.w, R.h, rad);
      ctx.clip();
      if (c.img) {
        const im = c.img.img;
        const iw = im.naturalWidth, ih = im.naturalHeight;
        const s = Math.max(R.w / iw, R.h / ih) * c.zoom;
        const dw = iw * s, dh = ih * s;
        const maxX = (dw - R.w) / 2 / R.w, maxY = (dh - R.h) / 2 / R.h;
        c.ox = clamp(c.ox, -maxX, maxX); c.oy = clamp(c.oy, -maxY, maxY);
        const dx = R.x + R.w / 2 - dw / 2 + c.ox * R.w;
        const dy = R.y + R.h / 2 - dh / 2 + c.oy * R.h;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(im, dx, dy, dw, dh);
      } else if (preview) {
        ctx.fillStyle = 'rgba(120,135,165,0.18)';
        ctx.fillRect(R.x, R.y, R.w, R.h);
        ctx.fillStyle = 'rgba(100,115,145,0.85)';
        ctx.font = `600 ${Math.max(11, 13 * scale)}px "Segoe UI", Arial`;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.font = `300 ${Math.max(20, 34 * scale)}px "Segoe UI", Arial`;
        ctx.fillText('+', R.x + R.w / 2, R.y + R.h / 2 - 12 * scale);
        ctx.font = `600 ${Math.max(10, 12 * scale)}px "Segoe UI", Arial`;
        ctx.fillText('Klik dua kali / seret gambar', R.x + R.w / 2, R.y + R.h / 2 + 16 * scale);
      }
      ctx.restore();
      if (preview && i === this.sel) {
        ctx.save();
        ctx.strokeStyle = '#1f5bff'; ctx.lineWidth = 3 * (window.devicePixelRatio || 1);
        ctx.setLineDash([10, 6]);
        ctx.beginPath(); ctx.roundRect(R.x + 1.5, R.y + 1.5, R.w - 3, R.h - 3, rad); ctx.stroke();
        ctx.restore();
      }
    });
    ctx.restore();
  },

  draw() {
    if (!this.canvas.width) return;
    this.render(this.canvas.getContext('2d'), this.canvas.width, this.canvas.height, true);
  },

  cellAt(ev) {
    const rc = this.canvas.getBoundingClientRect();
    const x = (ev.clientX - rc.left) / rc.width * this.canvas.width;
    const y = (ev.clientY - rc.top) / rc.height * this.canvas.height;
    const scale = Math.max(this.canvas.width, this.canvas.height) / 1000;
    for (let i = 0; i < this.cells.length; i++) {
      const R = this.cellRect(this.cells[i], this.canvas.width, this.canvas.height, scale);
      if (x >= R.x && x <= R.x + R.w && y >= R.y && y <= R.y + R.h) return { i, R };
    }
    return null;
  },

  bindCanvas() {
    const cv = this.canvas;
    cv.style.touchAction = 'none';
    const pts = new Map();
    let pinch = null;
    cv.addEventListener('pointerdown', (e) => {
      pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (pts.size === 2 && this.drag) {
        // cubit untuk zum (skrin sentuh)
        const [a, b] = Array.from(pts.values());
        const c = this.cells[this.drag.i];
        pinch = { i: this.drag.i, d: Math.hypot(a[0] - b[0], a[1] - b[1]), zoom: c.zoom };
        this.drag = null;
        return;
      }
      const hit = this.cellAt(e);
      if (!hit) return;
      try { cv.setPointerCapture(e.pointerId); } catch (_) { /* abaikan */ }
      this.sel = hit.i;
      this.drag = { i: hit.i, x: e.clientX, y: e.clientY, ox: this.cells[hit.i].ox, oy: this.cells[hit.i].oy, R: hit.R };
      this.draw();
    });
    const endPtr = (e) => { pts.delete(e.pointerId); if (pts.size < 2) pinch = null; if (!pts.size) this.drag = null; };
    cv.addEventListener('pointerup', endPtr);
    cv.addEventListener('pointercancel', endPtr);
    cv.addEventListener('pointermove', (e) => {
      if (pts.has(e.pointerId)) pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (pinch && pts.size === 2) {
        const [a, b] = Array.from(pts.values());
        const c = this.cells[pinch.i];
        if (c.img) { c.zoom = clamp(pinch.zoom * Math.hypot(a[0] - b[0], a[1] - b[1]) / Math.max(1, pinch.d), 1, 5); this.draw(); }
        return;
      }
      if (!this.drag) return;
      const c = this.cells[this.drag.i];
      if (!c.img) return;
      const k = this.canvas.width / this.canvas.getBoundingClientRect().width;
      c.ox = this.drag.ox + (e.clientX - this.drag.x) * k / this.drag.R.w;
      c.oy = this.drag.oy + (e.clientY - this.drag.y) * k / this.drag.R.h;
      this.draw();
    });
    cv.addEventListener('wheel', (e) => {
      const hit = this.cellAt(e);
      if (!hit || !this.cells[hit.i].img) return;
      e.preventDefault();
      const c = this.cells[hit.i];
      c.zoom = clamp(c.zoom * (e.deltaY < 0 ? 1.08 : 1 / 1.08), 1, 5);
      this.sel = hit.i;
      this.draw();
    }, { passive: false });
    cv.addEventListener('dblclick', async (e) => {
      const hit = this.cellAt(e);
      if (!hit) return;
      const paths = await window.api.openFiles({ kind: 'image', multi: false, title: 'Pilih gambar untuk petak' });
      if (!paths.length) return;
      try {
        const img = await loadImagePath(paths[0]);
        const t = { path: paths[0], img, id: uid('t') };
        this.tray.push(t);
        Object.assign(this.cells[hit.i], { img: t, zoom: 1, ox: 0, oy: 0 });
        this.renderTray(); this.draw();
      } catch (_) { toast('Gagal membuka gambar', 'err'); }
    });
    cv.addEventListener('dragover', (e) => { e.preventDefault(); });
    cv.addEventListener('drop', async (e) => {
      e.preventDefault();
      const hit = this.cellAt(e);
      const trayIdx = e.dataTransfer.getData('text/mypapr-tray');
      if (trayIdx !== '' && hit) {
        Object.assign(this.cells[hit.i], { img: this.tray[+trayIdx], zoom: 1, ox: 0, oy: 0 });
        this.sel = hit.i;
        this.renderTray(); this.draw();
        return;
      }
      const files = Array.from(e.dataTransfer.files || []).map((f) => window.api.pathForFile(f)).filter(isImagePath);
      if (!files.length) return;
      const startLen = this.tray.length;
      const freeBefore = this.cells.filter((c) => !c.img).length;
      await this.addPaths(files);
      if (hit && freeBefore === 0 && this.tray[startLen]) {
        Object.assign(this.cells[hit.i], { img: this.tray[startLen], zoom: 1, ox: 0, oy: 0 });
        this.renderTray(); this.draw();
      }
    });
  },

  renderFull() {
    const [W, H] = this.size(this.res);
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    this.render(c.getContext('2d'), W, H, false);
    return c;
  },

  async exportImage(destPath) {
    if (!this.cells.some((c) => c.img)) { toast('Kolaj masih kosong. Tambah gambar dahulu.', 'warn'); return null; }
    const c = this.renderFull();
    let dest = destPath;
    if (!dest) {
      dest = await window.api.saveFile({ name: 'kolaj_' + timestamp() + '.jpg', title: 'Simpan kolaj', filters: [{ name: 'JPEG', extensions: ['jpg'] }, { name: 'PNG', extensions: ['png'] }] });
      if (!dest) return null;
    }
    const isPng = extOf(dest) === 'png';
    const bytes = await canvasToBytes(c, isPng ? 'image/png' : 'image/jpeg', 0.92);
    await window.api.writeFile(dest, bytes);
    window.api.library.add(dest);
    toast('Kolaj disimpan: ' + dest, 'ok', 'Berjaya');
    return dest;
  },

  async toEditor() {
    if (!this.cells.some((c) => c.img)) { toast('Kolaj masih kosong.', 'warn'); return; }
    const c = this.renderFull();
    const dir = await window.api.tempDir('kolaj');
    const p = await window.api.join(dir, 'kolaj_' + timestamp() + '.png');
    await window.api.writeFile(p, await canvasToBytes(c, 'image/png'));
    App.openInImageEditor(p, 'kolaj_' + timestamp());
  }
};
