'use strict';
/* Modul: Potong & Gabung Video (Windows: ffmpeg • Android: main balik + MediaRecorder) */
const TrimMerge = {
  clips: [],
  sel: -1,
  running: false,

  init() {
    this.video = $('#tmVideo');
    $('#tmAdd').addEventListener('click', async () => this.add(await window.api.openFiles({ kind: 'video', title: 'Pilih video untuk dipotong / digabung' })));
    $('#tmEmptyAdd').addEventListener('click', async () => this.add(await window.api.openFiles({ kind: 'video', title: 'Pilih video untuk dipotong / digabung' })));
    setupDrop($('#view-trim'), 'video', (p) => this.add(p));
    $('#tmClear').addEventListener('click', () => { if (this.running) return; this.clips = []; this.select(-1); this.renderList(); });
    $('#tmExport').addEventListener('click', () => this.exportVideo());
    $('#tmShare').addEventListener('click', async () => { const p = await this.exportVideo(); if (p) Share.open(p); });
    $('#tmSetStart').addEventListener('click', () => this.setPoint('start', this.video.currentTime));
    $('#tmSetEnd').addEventListener('click', () => this.setPoint('end', this.video.currentTime));
    $('#tmPlaySeg').addEventListener('click', () => this.playSegment());
    $('#tmReset').addEventListener('click', () => { const c = this.cur(); if (!c) return; c.start = 0; c.end = c.duration; this.syncUI(); this.renderList(); });
    $('#tmStart').addEventListener('change', (e) => this.setPoint('start', parseFloat(e.target.value) || 0));
    $('#tmEnd').addEventListener('change', (e) => this.setPoint('end', parseFloat(e.target.value) || 0));
    this.video.addEventListener('timeupdate', () => {
      const c = this.cur();
      if (c && this.segPlay && this.video.currentTime >= c.end - 0.03) { this.video.pause(); this.segPlay = false; }
      this.drawPlayhead();
    });
    this.bindHandles();
    this.renderList();
    this.syncUI();
  },

  cur() { return this.clips[this.sel] || null; },

  async add(paths) {
    if (!paths || !paths.length) return;
    for (const p of paths) {
      const info = await probeMedia(p);
      if (!info.ok || !info.hasVideo) { toast('Bukan video yang sah: ' + baseName(p), 'err'); continue; }
      const c = { id: uid('c'), path: p, name: baseName(p), duration: info.duration, start: 0, end: info.duration, width: info.width, height: info.height, hasAudio: info.hasAudio !== false, thumb: null };
      this.clips.push(c);
      videoThumb(p, 0.5).then((u) => { c.thumb = u; this.renderList(); });
    }
    if (this.sel < 0 && this.clips.length) this.select(0);
    this.renderList();
  },

  select(i) {
    this.sel = i;
    const c = this.cur();
    $('#tmEmpty').hidden = !!c;
    $('#tmPlayer').hidden = !c;
    if (c) {
      this.video.src = window.api.mediaUrl(c.path);
      this.video.currentTime = c.start;
    } else { this.video.removeAttribute('src'); this.video.load(); }
    this.renderList();
    this.syncUI();
  },

  setPoint(which, t) {
    const c = this.cur();
    if (!c) return;
    t = clamp(t, 0, c.duration);
    if (which === 'start') c.start = Math.min(t, c.end - 0.1);
    else c.end = Math.max(t, c.start + 0.1);
    c.start = Math.max(0, c.start); c.end = Math.min(c.duration, c.end);
    this.syncUI();
    this.renderList();
  },

  playSegment() {
    const c = this.cur();
    if (!c) return;
    this.video.currentTime = c.start;
    this.segPlay = true;
    this.video.play();
  },

  syncUI() {
    const c = this.cur();
    const total = this.clips.reduce((a, x) => a + (x.end - x.start), 0);
    $('#tmTotal').textContent = this.clips.length ? `${this.clips.length} klip • jumlah ${formatTime(total)}` : '';
    $('#tmExport').querySelector('span:last-child').textContent = this.clips.length > 1 ? 'Gabung & Simpan' : 'Potong & Simpan';
    if (!c) return;
    // jangan tulis ganti kotak yang sedang ditaip pengguna
    if (document.activeElement !== $('#tmStart')) $('#tmStart').value = c.start.toFixed(1);
    if (document.activeElement !== $('#tmEnd')) $('#tmEnd').value = c.end.toFixed(1);
    $('#tmLen').textContent = `Bahagian dipilih: ${formatTime(c.start)} → ${formatTime(c.end)} (${(c.end - c.start).toFixed(1)} s daripada ${c.duration.toFixed(1)} s)`;
    const L = c.start / c.duration * 100, R = c.end / c.duration * 100;
    $('#tmSel').style.left = L + '%';
    $('#tmSel').style.width = (R - L) + '%';
    $('#tmHS').style.left = L + '%';
    $('#tmHE').style.left = R + '%';
    this.drawPlayhead();
  },
  drawPlayhead() {
    const c = this.cur();
    if (!c) return;
    $('#tmHead').style.left = clamp(this.video.currentTime / c.duration * 100, 0, 100) + '%';
  },

  /** Pemegang mula/tamat yang boleh diseret (tetikus & sentuhan). */
  bindHandles() {
    const bar = $('#tmBar');
    let drag = null;
    const tAt = (e) => { const r = bar.getBoundingClientRect(); const c = this.cur(); return clamp((e.clientX - r.left) / r.width, 0, 1) * (c ? c.duration : 0); };
    const start = (which) => (e) => {
      if (!this.cur()) return;
      e.preventDefault(); e.stopPropagation();
      drag = which;
      try { e.target.setPointerCapture(e.pointerId); } catch (_) { /* abaikan */ }
      this.video.pause();
    };
    $('#tmHS').addEventListener('pointerdown', start('start'));
    $('#tmHE').addEventListener('pointerdown', start('end'));
    const move = (e) => {
      if (!drag) return;
      const t = tAt(e);
      this.setPoint(drag, t);
      const c = this.cur();
      this.video.currentTime = drag === 'start' ? c.start : c.end;
    };
    $('#tmHS').addEventListener('pointermove', move);
    $('#tmHE').addEventListener('pointermove', move);
    const end = () => { drag = null; };
    $('#tmHS').addEventListener('pointerup', end);
    $('#tmHE').addEventListener('pointerup', end);
    bar.addEventListener('pointerdown', (e) => { if (drag || !this.cur()) return; this.video.currentTime = tAt(e); });
  },

  renderList() {
    const list = $('#tmList');
    list.innerHTML = '';
    if (!this.clips.length) { list.appendChild(h('div', { class: 'muted small center', style: { padding: '20px' } }, 'Tiada klip. Tambah satu video untuk dipotong, atau dua (atau lebih) untuk digabung.')); this.syncUI(); return; }
    this.clips.forEach((c, i) => {
      const row = h('div', { class: 'clip-row' + (i === this.sel ? ' sel' : '') },
        h('span', { class: 'clip-no' }, String(i + 1)),
        c.thumb ? h('img', { src: c.thumb }) : h('div', { class: 'clip-ph' }),
        h('div', { class: 'clip-info' }, h('b', { title: c.path }, c.name), h('span', { class: 'muted small' }, `${formatTime(c.start)} → ${formatTime(c.end)} • ${(c.end - c.start).toFixed(1)} s${c.hasAudio ? '' : ' • tiada audio'}`)),
        h('div', { class: 'clip-btns' },
          iconBtn('up', '', 'btn-ghost btn-sm', (e) => { e.stopPropagation(); this.move(i, -1); }, 'Naik'),
          iconBtn('down', '', 'btn-ghost btn-sm', (e) => { e.stopPropagation(); this.move(i, 1); }, 'Turun'),
          iconBtn('x', '', 'btn-ghost btn-sm', (e) => { e.stopPropagation(); this.removeClip(i); }, 'Buang')));
      row.addEventListener('click', () => { if (i !== this.sel) this.select(i); });
      list.appendChild(row);
    });
    applyIcons(list);
    this.syncUI();
  },
  move(i, d) {
    const j = i + d;
    if (j < 0 || j >= this.clips.length || this.running) return;
    [this.clips[i], this.clips[j]] = [this.clips[j], this.clips[i]];
    if (this.sel === i) this.sel = j; else if (this.sel === j) this.sel = i;
    this.renderList();
  },
  removeClip(i) {
    if (this.running) return;
    this.clips.splice(i, 1);
    this.select(Math.min(this.sel, this.clips.length - 1));
  },

  async exportVideo() {
    if (this.running) return null;
    if (!this.clips.length) { toast('Tambah video terlebih dahulu.', 'warn'); return null; }
    this.video.pause();
    const preset = $('#tmQuality').value;
    const name = this.clips.length > 1 ? `gabung_${timestamp()}.mp4` : `${stripExt(this.clips[0].name)}_potong.mp4`;
    const dest = await outputPath(name);
    this.running = true;
    let cancelled = false, cancelFn = null;
    Progress.show(this.clips.length > 1 ? 'Menggabungkan video…' : 'Memotong video…', '', () => { cancelled = true; if (cancelFn) cancelFn(); });
    try {
      let outPath = dest, size = 0;
      if (hasFfmpeg()) {
        const job = trimMergeArgs(this.clips, dest, preset);
        const r = await runFfmpegJob(job.args, { duration: job.duration, registerCancel: (fn) => { cancelFn = fn; }, onProgress: (p) => Progress.set(p) });
        if (r.cancelled || cancelled) { await window.api.remove(dest); toast('Dibatalkan.', 'warn'); return null; }
        if (r.code !== 0) throw new Error(ffmpegErrorText(r));
        size = (await window.api.fileInfo(dest)).size;
      } else {
        Progress.set(0, 'Memproses (masa ≈ jumlah tempoh klip)…');
        const r = await WebVideo.renderSequence({
          clips: this.clips.map((c) => ({ url: window.api.mediaUrl(c.path), start: c.start, end: c.end })),
          preset, isCancelled: () => cancelled, onProgress: (p) => Progress.set(p)
        });
        if (!r) { toast('Dibatalkan.', 'warn'); return null; }
        outPath = dest.replace(/\.mp4$/i, '.' + r.ext);
        await saveBlob(outPath, r.blob);
        size = r.blob.size;
      }
      window.api.library.add(outPath);
      toast(`Video disimpan (${formatBytes(size)}): ${outPath}`, 'ok', this.clips.length > 1 ? 'Gabung berjaya' : 'Potong berjaya');
      this.lastOut = outPath;
      return outPath;
    } catch (e) {
      toast(e.message, 'err', 'Gagal');
      return null;
    } finally {
      this.running = false;
      Progress.hide();
    }
  }
};
