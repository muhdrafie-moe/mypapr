'use strict';
/* Modul: Editor Video — teks, bentuk & fokus muka automatik */
const VideoEditor = {
  ed: null,
  src: null,
  previewPath: null,
  info: null,
  duration: 0,
  vw: 0, vh: 0,
  target: null,
  track: null,
  raf: 0,
  faceCanvas: null,

  init() {
    this.video = $('#veVideo');
    this.ed = new OverlayEditor({
      mode: 'video',
      canvasEl: $('#veCanvas'), hostEl: $('#veHost'), stageEl: $('#veStage'),
      toolsEl: $('#veTools'), propsEl: $('#veProps'),
      getTime: () => this.video.currentTime || 0,
      onTimeChange: () => this.updateVisibility(true),
      onChange: () => this.updateVisibility(true),
      onFit: (cw, ch) => this.fitFaceLayer(cw, ch)
    });
    this.faceCanvas = h('canvas', { class: 'face-layer', style: { position: 'absolute', left: 0, top: 0, width: '100%', height: '100%', pointerEvents: 'none' } });
    this.video.after(this.faceCanvas);

    $('#veOpen').addEventListener('click', async () => {
      const p = await window.api.openFiles({ kind: 'video', multi: false, title: 'Buka video' });
      if (p.length) this.open(p[0]);
    });
    setupDrop($('#veStage'), 'video', (p) => this.open(p[0]));
    $('#veUndo').addEventListener('click', () => this.ed.undo());
    $('#veRedo').addEventListener('click', () => this.ed.redo());
    $('#vePlay').addEventListener('click', () => this.togglePlay());
    $('#veMute').addEventListener('click', () => {
      this.video.muted = !this.video.muted;
      const ic = $('#veMute .ico'); ic.dataset.icon = this.video.muted ? 'mute' : 'volume'; applyIcons($('#veMute'));
    });
    $('#veSeek').addEventListener('input', (e) => {
      if (!this.duration) return;
      this.video.currentTime = (+e.target.value / 1000) * this.duration;
      this.tick(true);
    });
    this.video.addEventListener('play', () => this.setPlayIcon(true));
    this.video.addEventListener('pause', () => this.setPlayIcon(false));
    this.video.addEventListener('ended', () => this.setPlayIcon(false));
    this.video.addEventListener('seeked', () => this.tick(true));
    this.video.addEventListener('timeupdate', () => { if (this.video.paused) this.tick(true); });

    $('#veDetect').addEventListener('click', () => this.detectFaces('initial'));
    $('#veCorrect').addEventListener('click', () => this.detectFaces('correct'));
    $('#veManual').addEventListener('click', () => (this.mRec ? this.stopManual() : this.startManual()));
    $('#veMMode').addEventListener('click', (e) => {
      const bt = e.target.closest('button[data-m]'); if (!bt || this.mRec) return;
      $$('#veMMode button').forEach((x) => x.classList.toggle('on', x === bt));
      $('#veMTapOpts').hidden = bt.dataset.m !== 'tap';
      $('#veMDragOpts').hidden = bt.dataset.m !== 'drag';
    });
    $('#veMSize').addEventListener('input', (e) => this.setSize(+e.target.value / 100));
    if (window.matchMedia('(pointer: coarse)').matches) $('#veMOffset').checked = true;
    this.manual = [];
    $('#veTrack').addEventListener('click', () => this.runTracking());
    $('#veTrackClear').addEventListener('click', () => { if (this.mRec) this.stopManual(); if (this.tracker) { this.tracker.close(); this.tracker = null; } this.track = null; this.autoTrack = null; this.manual = []; this.target = null; this.renderTarget(); this.renderStrip(); this.drawFace(); $('#veTrackStatus').textContent = ''; });
    $('#veExport').addEventListener('click', () => this.exportVideo());
    $('#veShare').addEventListener('click', async () => {
      if (!this.src) { toast('Buka video terlebih dahulu.', 'warn'); return; }
      const dest = await outputPath(stripExt(baseName(this.src)) + '_edit.mp4');
      const r = await this.exportVideo(dest);
      if (r) Share.open(r);
    });
    $('#veFacePicks').addEventListener('click', (e) => { if (e.target.id === 'veFacePicks' && !this.mRec) this.hidePicks(); });
    const redraw = () => { $('#veFThickV').textContent = $('#veFThick').value; $('#veFPadV').textContent = $('#veFPad').value + '%'; this.drawFace(); };
    ['veFShape', 'veFColor', 'veFThick', 'veFPad', 'veFLabelOn', 'veFLabel'].forEach((id) => { $('#' + id).addEventListener('input', redraw); $('#' + id).addEventListener('change', redraw); });
    this.renderTarget();
  },

  /* ----------------------------- buka video ----------------------------- */
  async open(path) {
    if (this.src && (this.ed.userObjects().length || this.track)) {
      const r = await window.api.message({ message: 'Buka video baharu?', detail: 'Teks, bentuk dan fokus muka semasa akan dibuang.', buttons: ['Buka', 'Batal'] });
      if (r !== 0) return false;
    }
    Progress.show('Membuka video…', baseName(path));
    try {
      const info = await probeMedia(path);
      if (!info.ok || !info.hasVideo) throw new Error('Fail ini bukan video yang sah.');
      this.info = info;
      this.src = path;
      this.previewPath = path;
      let ok = await this.loadPreview(path);
      if (!ok) {
        Progress.set(0, 'Format video perlu ditukar untuk pratonton…');
        const proxy = await this.makeProxy(path, info);
        if (!proxy) throw new Error('Video tidak dapat dibuka.');
        this.previewPath = proxy;
        ok = await this.loadPreview(proxy);
        if (!ok) throw new Error('Video tidak dapat dimainkan.');
      }
      this.vw = this.video.videoWidth; this.vh = this.video.videoHeight;
      this.duration = this.video.duration && isFinite(this.video.duration) ? this.video.duration : info.duration;
      this.ed.duration = this.duration;
      const s = Math.min(1, 1280 / Math.max(this.vw, this.vh));
      $('#veEmpty').hidden = true;
      this.ed.setSize(Math.round(this.vw * s), Math.round(this.vh * s));
      if (!this._selHooked) {
        this._selHooked = true;
        ['selection:created', 'selection:updated', 'selection:cleared'].forEach((ev) => this.ed.canvas.on(ev, () => this.updateVisibility()));
      }
      this.ed.clearAll();
      this.ed.counter = {};
      this.target = null; this.track = null; this.autoTrack = null; this.manual = [];
      if (this.mRec) this.stopManual();
      if (this.tracker) { this.tracker.close(); this.tracker = null; }
      this.renderTarget(); this.renderStrip();
      $('#veTrackStatus').textContent = '';
      $('#veInfo').textContent = `${info.width}×${info.height} • ${formatTime(this.duration, false)}`;
      this.tick(true);
      Progress.hide();
      return true;
    } catch (e) {
      Progress.hide();
      toast(e.message, 'err', 'Gagal membuka video');
      return false;
    }
  },

  loadPreview(path) {
    return new Promise((resolve) => {
      const v = this.video;
      let done = false;
      const fin = (ok) => { if (done) return; done = true; v.onloadeddata = null; v.onerror = null; clearTimeout(tm); resolve(ok); };
      const tm = setTimeout(() => fin(v.readyState >= 2 && v.videoWidth > 0), 15000);
      v.onloadeddata = () => fin(v.videoWidth > 0);
      v.onerror = () => fin(false);
      v.crossOrigin = 'anonymous';
      v.src = window.api.mediaUrl(path);
      v.load();
    });
  },

  async makeProxy(path, info) {
    if (!hasFfmpeg()) return null;
    const dir = await window.api.tempDir('proxy');
    const out = await window.api.join(dir, 'pratonton.mp4');
    const args = ['-i', path, '-map', '0:v:0', '-map', '0:a:0?', '-vf', scaleFilter(720) + ',format=yuv420p', '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '26', '-c:a', 'aac', '-b:a', '128k', out];
    const r = await runFfmpegJob(args, { duration: info.duration, onProgress: (p) => Progress.set(p) });
    return r.code === 0 ? out : null;
  },

  /* ----------------------------- main balik ----------------------------- */
  togglePlay() {
    if (!this.src) return;
    if (this.video.paused) { this.hidePicks(); this.video.play(); this.loop(); } else this.video.pause();
  },
  setPlayIcon(playing) {
    const ic = $('#vePlay .ico'); ic.dataset.icon = playing ? 'pause' : 'play'; applyIcons($('#vePlay'));
  },
  loop() {
    cancelAnimationFrame(this.raf);
    const step = () => { this.tick(); if (!this.video.paused && !this.video.ended) this.raf = requestAnimationFrame(step); };
    this.raf = requestAnimationFrame(step);
  },
  tick(force) {
    const t = this.video.currentTime || 0;
    $('#veTime').textContent = formatTime(t) + ' / ' + formatTime(this.duration);
    if (this.duration) $('#veSeek').value = Math.round(t / this.duration * 1000);
    this.updateVisibility(force);
    this.drawFace();
  },
  updateVisibility() {
    const c = this.ed.canvas;
    if (!c) return;
    const t = this.video.currentTime || 0;
    const act = c.getActiveObject();
    const sel = act ? (act.type === 'activeSelection' ? act.getObjects() : [act]) : [];
    let changed = false;
    for (const o of this.ed.userObjects()) {
      const end = o.mpEnd == null ? Infinity : o.mpEnd;
      const vis = (t >= (o.mpStart || 0) - 0.001 && t <= end + 0.001) || sel.includes(o);
      if (o.visible !== vis) { o.visible = vis; changed = true; }
    }
    if (changed) c.requestRenderAll();
  },

  /* ----------------------------- lapisan muka ----------------------------- */
  fitFaceLayer(cw, ch) {
    const dpr = window.devicePixelRatio || 1;
    this.faceCanvas.width = Math.round(cw * dpr);
    this.faceCanvas.height = Math.round(ch * dpr);
    this.drawFace();
  },
  faceOpts() {
    return {
      shape: $('#veFShape').value, color: $('#veFColor').value, thick: +$('#veFThick').value, pad: +$('#veFPad').value,
      label: $('#veFLabelOn').checked ? $('#veFLabel').value.trim() : ''
    };
  },
  drawFace() {
    const fc = this.faceCanvas;
    const ctx = fc.getContext('2d');
    ctx.clearRect(0, 0, fc.width, fc.height);
    if (!this.src) return;
    const b = this.mRec && this.mCursor ? this.cursorBox() : (this.track ? trackBoxAt(this.track, this.video.currentTime || 0) : null);
    if (!b) return;
    const o = this.faceOpts();
    const W = fc.width, H = fc.height;
    const r = focusRect(b, W, H, o.pad, o.shape);
    const thick = Math.max(1.5, o.thick * Math.max(W, H) / 1000);
    drawFocusShape(ctx, o.shape, r.x, r.y, r.w, r.h, o.color, thick);
    if (o.label) {
      const lc = makeLabelCanvas(o.label, Math.max(10, Math.round(H * 0.035)), o.color);
      let ly = r.y - lc.height - Math.max(4, lc.height * 0.15);
      if (ly < 0) ly = r.y + r.h + Math.max(4, lc.height * 0.15);
      ctx.drawImage(lc, r.cx - lc.width / 2, ly);
    }
  },

  /* ----------------------------- kesan muka ----------------------------- */
  async ensureModels() {
    if (FaceAI.ready) return true;
    Progress.show('Memuatkan model AI pengecaman muka…', 'Hanya sekali bagi setiap sesi (luar talian).');
    Progress.set(30);
    try { await FaceAI.load(); Progress.set(100); Progress.hide(); return true; } catch (e) {
      Progress.hide(); toast('Model AI gagal dimuatkan: ' + e.message, 'err'); return false;
    }
  },

  /** Selaraskan masa video pratonton dengan grid analisis (supaya titik rujukan tepat). */
  async snapToGrid() {
    const rate = this.tracker ? this.tracker.rate : +$('#veFRate').value;
    const t = Math.min(Math.round((this.video.currentTime || 0) * rate) / rate, Math.max(0, this.duration - 0.04));
    if (Math.abs(t - this.video.currentTime) > 0.001) {
      await new Promise((r) => { const f = () => { this.video.removeEventListener('seeked', f); r(); }; this.video.addEventListener('seeked', f); this.video.currentTime = t; setTimeout(f, 3000); });
    }
    return t;
  },

  /** mode: 'initial' (pilih subjek) atau 'correct' (betulkan subjek pada masa ini) */
  async detectFaces(mode) {
    mode = mode || 'initial';
    if (!this.src) { toast('Buka video terlebih dahulu.', 'warn'); return; }
    if (mode === 'correct' && !this.tracker) { toast('Jejak subjek dahulu sebelum membetulkan.', 'warn'); return; }
    this.video.pause();
    if (!(await this.ensureModels())) return;
    const btns = [$('#veDetect'), $('#veCorrect')]; btns.forEach((b) => { b.disabled = true; });
    try {
      const t = await this.snapToGrid();
      const cv = frameToCanvas(this.video, document.createElement('canvas'), 1280);
      const heads = await detectHeads(cv);
      this.lastDetect = { canvas: cv, faces: heads, time: t, mode };
      this.showPicks(heads, mode);
      const what = mode === 'correct' ? 'yang BETUL' : 'yang ingin difokus';
      if (heads.length) toast(`${heads.length} kepala/muka dikesan. Klik kepala murid ${what}, atau seret kotak pada kepala murid jika tiada kotak.`, 'ok');
      else toast('Tiada muka dikesan secara automatik. Seret (lukis) kotak pada kepala murid untuk memilihnya.', 'warn');
    } catch (e) {
      toast('Ralat pengesanan: ' + e.message, 'err');
    } finally { btns.forEach((b) => { b.disabled = false; }); }
  },
  showPicks(faces, mode) {
    const box = $('#veFacePicks');
    box.innerHTML = '';
    box.appendChild(h('div', { class: 'pick-hint' }, mode === 'correct' ? 'Betulkan: klik kepala murid yang betul • atau seret kotak • Esc untuk batal' : 'Klik kepala murid • atau seret kotak pada kepala • Esc untuk batal'));
    faces.forEach((f, i) => {
      const d = h('div', { class: 'face-pick', style: { left: f.x * 100 + '%', top: f.y * 100 + '%', width: f.w * 100 + '%', height: f.h * 100 + '%' } }, h('span', null, String(i + 1)));
      d.addEventListener('pointerdown', (e) => e.stopPropagation());
      d.addEventListener('click', (e) => { e.stopPropagation(); this.pickFace(i); });
      box.appendChild(d);
    });
    box.classList.add('show');
    this.revealStage();
    this.bindDraw();
  },
  bindDraw() {
    const box = $('#veFacePicks');
    if (box._drawBound) return;
    box._drawBound = true;
    let st = null, rectEl = null;
    const pos = (e) => { const r = box.getBoundingClientRect(); return [clamp((e.clientX - r.left) / r.width, 0, 1), clamp((e.clientY - r.top) / r.height, 0, 1)]; };
    box.addEventListener('pointerdown', (e) => {
      if (!box.classList.contains('show') || box.classList.contains('record') || e.target.closest('.face-pick')) return;
      try { box.setPointerCapture(e.pointerId); } catch (_) { /* abaikan */ }
      st = pos(e);
      rectEl = h('div', { class: 'face-pick drawing' });
      box.appendChild(rectEl);
      e.preventDefault();
    });
    box.addEventListener('pointermove', (e) => {
      if (!st || !rectEl) return;
      const p = pos(e);
      Object.assign(rectEl.style, { left: Math.min(st[0], p[0]) * 100 + '%', top: Math.min(st[1], p[1]) * 100 + '%', width: Math.abs(p[0] - st[0]) * 100 + '%', height: Math.abs(p[1] - st[1]) * 100 + '%' });
    });
    box.addEventListener('pointerup', (e) => {
      if (!st || box.classList.contains('record')) { st = null; return; }
      const p = pos(e);
      const b = { x: Math.min(st[0], p[0]), y: Math.min(st[1], p[1]), w: Math.abs(p[0] - st[0]), h: Math.abs(p[1] - st[1]) };
      st = null;
      if (rectEl) { rectEl.remove(); rectEl = null; }
      const r = box.getBoundingClientRect();
      if (b.w * r.width < 12 || b.h * r.height < 12) { if (!e.target.closest('.face-pick')) this.hidePicks(); return; }
      this.pickBox(b, null);
    });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && box.classList.contains('show') && !box.classList.contains('record')) this.hidePicks(); });
  },
  /** Telefon: pastikan video kelihatan (panel alat berada di bawah video). */
  revealStage() {
    const st = $('#veStage');
    const r = st.getBoundingClientRect();
    if (r.top < 0 || r.bottom > window.innerHeight) st.scrollIntoView({ block: 'start', behavior: 'instant' });
  },
  hidePicks() { $('#veFacePicks').classList.remove('show'); $$('#veFacePicks > *').forEach((n) => n.remove()); },
  pickFace(i) {
    const f = this.lastDetect.faces[i];
    this.pickBox({ x: f.x, y: f.y, w: f.w, h: f.h }, f.desc);
  },
  async pickBox(box, desc) {
    const d = this.lastDetect;
    this.hidePicks();
    const anchor = { desc, box, time: d.time, thumb: cropFaceThumb(d.canvas, box) };
    if (d.mode === 'correct' && this.tracker) {
      await this.withTracking('Membetulkan subjek…', async (cb) => {
        await this.tracker.addAnchor({ t: anchor.time, box: anchor.box, desc: anchor.desc }, cb);
      });
      toast('Subjek dibetulkan dari ' + formatTime(anchor.time) + '. Semak semula dan betulkan lagi jika perlu.', 'ok', 'Dibetulkan');
      return;
    }
    this.target = anchor;
    this.autoTrack = null;
    this.track = this.mergedTrack();
    if (this.tracker) { this.tracker.close(); this.tracker = null; }
    this.renderTarget(); this.renderStrip(); this.drawFace();
    toast('Subjek dipilih. Tekan "Jejak Kepala & Muka" untuk menjejak sepanjang video.', 'ok');
  },
  renderTarget() {
    const el = $('#veTarget');
    el.innerHTML = '';
    if (!this.target) { el.appendChild(h('span', { class: 'muted small' }, 'Belum ada subjek dipilih')); return; }
    const n = this.tracker ? this.tracker.anchors.length : 1;
    el.append(h('img', { src: this.target.thumb }), h('div', { class: 'small' }, h('b', null, 'Subjek dipilih'), h('br'),
      h('span', { class: 'muted' }, 'pada ' + formatTime(this.target.time) + (n > 1 ? ` • ${n - 1} pembetulan` : ''))));
  },

  async withTracking(title, fn) {
    if (!(await this.ensureModels())) return false;
    this.video.pause();
    let cancelled = false;
    Progress.show(title, 'Menganalisis kepala & muka (luar talian)…', () => { cancelled = true; });
    const t0 = performance.now();
    const cb = {
      isCancelled: () => cancelled,
      onStage: (txt, p) => Progress.set(p, txt),
      onProgress: (p, s) => {
        const el = (performance.now() - t0) / 1000;
        const eta = p > 2 ? el / p * (100 - p) : 0;
        Progress.set(p, `Bingkai ${s.processed}/${s.total}${eta ? ' • Baki ~' + Math.ceil(eta) + 's' : ''}`);
      }
    };
    let ok = false;
    try {
      await fn(cb);
      ok = true;
    } catch (e) {
      if (e.message === 'DIBATALKAN') toast('Penjejakan dibatalkan. Bahagian yang telah dianalisis dikekalkan.', 'warn');
      else toast('Ralat penjejakan: ' + e.message, 'err');
    } finally {
      if (this.tracker) {
        this.autoTrack = this.tracker.toTrack();
        this.track = this.mergedTrack();
        const vis = this.track.filter((s) => s.box).length;
        const pct = Math.round(vis / this.track.length * 100);
        $('#veTrackStatus').textContent = `✓ Subjek dijejak dalam ${pct}% video. Jika tersasar: jeda → Betulkan Subjek.`;
        if (ok) toast(`Penjejakan selesai — subjek ditemui dalam ${pct}% video.`, pct > 0 ? 'ok' : 'warn', 'Jejak Kepala & Muka');
      }
      Progress.hide();
      this.renderTarget(); this.renderStrip(); this.tick(true);
    }
    return ok;
  },

  async runTracking() {
    if (!this.src) { toast('Buka video terlebih dahulu.', 'warn'); return; }
    if (!this.target) { toast('Pilih subjek dahulu: tekan "Kesan Kepala & Muka" dan klik kepala murid.', 'warn'); return; }
    if (!(await this.ensureModels())) return;
    if (this.tracker) this.tracker.close();
    this.tracker = new SubjectTracker({ path: this.previewPath, duration: this.duration, rate: +$('#veFRate').value });
    await this.withTracking('Menjejak kepala & muka subjek…', async (cb) => {
      await this.tracker.open(cb);
      await this.tracker.addAnchor({ t: this.target.time, box: this.target.box, desc: this.target.desc }, cb);
    });
  },
  renderStrip() {
    const el = $('#veTrackStrip');
    el.innerHTML = '';
    if (!this.track || !this.track.length || !this.duration) return;
    const col = (s) => !s.box ? 'transparent' : s.state === 'manual' ? 'var(--primary)' : s.state === 'hold' ? 'var(--accent)' : 'var(--success)';
    let segStart = 0, cur = col(this.track[0]);
    const push = (from, to, c) => el.appendChild(h('i', { style: { width: ((to - from) / this.duration * 100) + '%', background: c } }));
    for (let i = 1; i < this.track.length; i++) {
      const c = col(this.track[i]);
      if (c !== cur) { push(segStart, this.track[i].t, cur); segStart = this.track[i].t; cur = c; }
    }
    push(segStart, this.duration, cur);
    if (this.tracker) for (const a of this.tracker.anchors) el.appendChild(h('b', { class: 'anchor-mark', title: 'Titik rujukan ' + formatTime(a.t), style: { left: (a.t / this.duration * 100) + '%' } }));
  },


  /* ----------------------------- rekod manual (tanpa AI) ----------------------------- */
  /*
   * Dua kaedah:
   *  • KETIK LANGKAH (disyorkan untuk telefon): video dijeda, ketik kepala murid → titik direkod,
   *    video maju sendiri (0.25/0.5/1 s). Pergerakan antara titik dilicinkan (interpolasi).
   *  • SERET: tahan & gerakkan tetikus/jari semasa video dimainkan perlahan. Pada skrin sentuh
   *    bentuk dipapar DI ATAS hujung jari supaya jari tidak menutup muka.
   */
  /** Gabung jejak automatik + segmen manual (manual mengatasi automatik). */
  mergedTrack() {
    const ranges = (this.manual || []).concat(this.mCur && this.mCur.samples.length ? [this.mCur] : []).filter((r) => r.samples.length);
    let base = this.autoTrack ? this.autoTrack.slice() : [];
    for (const r of ranges) base = base.filter((x) => x.t < r.t0 - 0.03 || x.t > r.t1 + 0.03);
    let all = base;
    for (const r of ranges) {
      all = all.concat(r.samples.map((x) => ({ t: x.t, box: x.box, state: 'manual' })));
      if (!this.autoTrack) all.push({ t: Math.max(0, r.t0 - 0.02), box: null, state: 'none' }, { t: r.t1 + 0.02, box: null, state: 'none' });
    }
    all.sort((x, y) => x.t - y.t);
    return all.some((x) => x.box) ? all : null;
  },
  manualMode() { return ($('#veMMode button.on') || {}).dataset ? $('#veMMode button.on').dataset.m : 'tap'; },
  cursorBox() {
    const W = this.vw || 16, H = this.vh || 9;
    const w = this.mSize, hh = this.mSize * 1.25 * W / H;
    return { x: this.mCursor[0] - w / 2, y: this.mCursor[1] - hh / 2, w, h: hh };
  },
  setSize(v) {
    this.mSize = clamp(v, 0.02, 0.6);
    const sl = $('#veMSize'); if (sl) sl.value = Math.round(this.mSize * 100);
    this.drawFace();
  },
  startManual() {
    if (!this.src) { toast('Buka video terlebih dahulu.', 'warn'); return; }
    this.hidePicks();
    this.video.pause();
    this.ed.canvas.discardActiveObject();
    this.mRec = true;
    this.mCursor = null;
    this.mCur = null;
    if (!this.mSize) {
      const b = this.track ? trackBoxAt(this.track, this.video.currentTime || 0) : null;
      this.setSize(b ? b.w : (+$('#veMSize').value || 9) / 100);
    }
    const mode = this.manualMode();
    const box = $('#veFacePicks');
    box.innerHTML = '';
    const stop = (e) => e.stopPropagation();
    if (mode === 'tap') {
      const bar = h('div', { class: 'tap-bar' },
        h('span', { class: 'tap-time', id: 'veTapTime' }, formatTime(this.video.currentTime)),
        iconBtn('undo', 'Undur', 'btn-ghost btn-sm', () => this.tapUndo(), 'Buang titik terakhir'),
        iconBtn('eye', 'Tiada', 'btn-ghost btn-sm', () => this.tapNone(), 'Murid tiada dalam babak ini — langkau'),
        iconBtn('check', 'Selesai', 'btn-success btn-sm', () => this.stopManual(), 'Tamatkan rekod'));
      ['pointerdown', 'pointerup', 'click'].forEach((ev) => bar.addEventListener(ev, stop));
      box.append(h('div', { class: 'pick-hint' }, 'KETIK kepala murid → video maju sendiri. Cubit/roda = saiz.'), bar);
    } else {
      box.append(h('div', { class: 'pick-hint' }, 'TAHAN & gerakkan pada kepala murid → video bermain. Lepas = jeda. Cubit/roda = saiz.'),
        h('div', { class: 'rec-badge' }, '● MERAKAM'));
      const bar = h('div', { class: 'tap-bar' }, iconBtn('check', 'Selesai', 'btn-success btn-sm', () => this.stopManual()));
      ['pointerdown', 'pointerup', 'click'].forEach((ev) => bar.addEventListener(ev, stop));
      box.appendChild(bar);
    }
    box.classList.add('show', 'record');
    this.revealStage();
    const b = $('#veManual'); b.classList.add('on'); b.querySelector('span:last-child').textContent = 'Selesai Rekod';
    applyIcons(box);
    if (!this._mBound) this.bindManual();
    this.drawFace();
  },
  stopManual() {
    if (this.mCur) this.finalizeSegment(this.manualMode() === 'drag');
    this.mRec = false;
    this.mCursor = null;
    cancelAnimationFrame(this.mRaf);
    this.video.pause();
    const box = $('#veFacePicks');
    box.classList.remove('show', 'record', 'rec');
    box.innerHTML = '';
    this.video.playbackRate = 1;
    const b = $('#veManual'); b.classList.remove('on'); b.querySelector('span:last-child').textContent = 'Mula Rekod Manual';
    this.track = this.mergedTrack();
    this.renderStrip();
    this.drawFace();
    const n = (this.manual || []).reduce((a, r) => a + Math.max(0, r.t1 - r.t0), 0);
    if (n > 0) $('#veTrackStatus').textContent = `✓ Rekod manual: ${n.toFixed(1)}s (${this.manual.length} segmen).`;
  },
  bindManual() {
    this._mBound = true;
    const box = $('#veFacePicks');
    const pts = new Map();
    let pinch = null;
    const pos = (e) => { const r = box.getBoundingClientRect(); return [clamp((e.clientX - r.left) / r.width, 0, 1), clamp((e.clientY - r.top) / r.height, 0, 1)]; };
    const withOffset = (p, e) => {
      // skrin sentuh: letak bentuk di atas hujung jari supaya muka tidak terlindung
      if (e.pointerType === 'touch' && $('#veMOffset').checked) {
        const hh = this.mSize * 1.25 * (this.vw || 16) / (this.vh || 9);
        return [p[0], clamp(p[1] - hh * 0.75 - 0.03, 0, 1)];
      }
      return p;
    };
    box.addEventListener('pointerdown', (e) => {
      if (!this.mRec) return;
      e.preventDefault();
      pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (pts.size === 2) {
        const [a, c] = Array.from(pts.values());
        pinch = { d: Math.hypot(a[0] - c[0], a[1] - c[1]), size: this.mSize };
        if (this.mCur && this.manualMode() === 'drag') this.endDrag();
        return;
      }
      if (pts.size > 1) return;
      try { box.setPointerCapture(e.pointerId); } catch (_) { /* abaikan */ }
      this.mCursor = withOffset(pos(e), e);
      if (this.manualMode() === 'tap') { this._tapStart = { x: e.clientX, y: e.clientY }; this.drawFace(); }
      else this.beginDrag();
    });
    box.addEventListener('pointermove', (e) => {
      if (!this.mRec) return;
      if (pts.has(e.pointerId)) pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (pinch && pts.size === 2) {
        const [a, c] = Array.from(pts.values());
        this.setSize(pinch.size * Math.hypot(a[0] - c[0], a[1] - c[1]) / Math.max(1, pinch.d));
        return;
      }
      if (e.pointerType === 'mouse' || pts.has(e.pointerId)) {
        this.mCursor = withOffset(pos(e), e);
        if (this.video.paused) this.drawFace();
      }
    });
    const up = (e) => {
      if (!this.mRec) { pts.delete(e.pointerId); return; }
      const wasPinch = !!pinch;
      pts.delete(e.pointerId);
      if (pts.size < 2) pinch = null;
      if (wasPinch) return;
      if (this.manualMode() === 'tap') {
        if (e.type === 'pointerup' && this._tapStart) { this.mCursor = withOffset(pos(e), e); this.tapRecord(); }
        this._tapStart = null;
      } else if (this.mCur) this.endDrag();
    };
    box.addEventListener('pointerup', up);
    box.addEventListener('pointercancel', up);
    box.addEventListener('wheel', (e) => { if (!this.mRec) return; e.preventDefault(); this.setSize(this.mSize * (e.deltaY < 0 ? 1.08 : 1 / 1.08)); }, { passive: false });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && this.mRec) this.stopManual(); });
  },

  /* --- Ketik Langkah --- */
  stepSize() { return +$('#veMStep').value || 0.5; },
  tapRecord() {
    if (!this.mCursor) return;
    const t = this.video.currentTime;
    if (!this.mCur) this.mCur = { t0: t, t1: t, samples: [] };
    const S = this.mCur.samples;
    // ketik semula pada masa yang sama → ganti titik
    if (S.length && Math.abs(S[S.length - 1].t - t) < 0.01) S.pop();
    S.push({ t, box: this.cursorBox() });
    this.mCur.t0 = S[0].t; this.mCur.t1 = S[S.length - 1].t;
    this.track = this.mergedTrack();
    this.renderStrip();
    const next = t + this.stepSize();
    if (next >= this.duration - 0.02) {
      this.finalizeSegment(false);
      toast('Sampai ke hujung video. Tekan Selesai.', 'ok');
      this.drawFace();
      return;
    }
    this.seekTo(next);
  },
  tapUndo() {
    if (this.mCur && this.mCur.samples.length) {
      const last = this.mCur.samples.pop();
      if (!this.mCur.samples.length) this.mCur = null;
      else { this.mCur.t1 = this.mCur.samples[this.mCur.samples.length - 1].t; }
      this.track = this.mergedTrack(); this.renderStrip();
      this.mCursor = [last.box.x + last.box.w / 2, last.box.y + last.box.h / 2];
      this.seekTo(last.t);
    } else this.seekTo(Math.max(0, this.video.currentTime - this.stepSize()));
  },
  tapNone() {
    // murid tiada dalam babak: tamatkan segmen semasa (bentuk tidak dipapar di sini) dan maju
    if (this.mCur) this.finalizeSegment(false);
    const next = Math.min(this.duration - 0.04, this.video.currentTime + this.stepSize());
    this.seekTo(next);
  },
  seekTo(t) {
    this.video.pause();
    this.video.currentTime = t;
    const el = $('#veTapTime'); if (el) el.textContent = formatTime(t);
  },

  /* --- Seret --- */
  beginDrag() {
    if (this.video.ended || this.video.currentTime >= this.duration - 0.05) { toast('Video sudah tamat. Undur video untuk merekod semula.', 'warn'); return; }
    this.mCur = { t0: this.video.currentTime, t1: this.video.currentTime, samples: [] };
    $('#veFacePicks').classList.add('rec');
    this.video.playbackRate = +$('#veMSpeed').value || 0.5;
    const sample = () => {
      if (!this.mCur || !this.mCursor) return;
      const t = this.video.currentTime;
      const last = this.mCur.samples[this.mCur.samples.length - 1];
      if (!last || t > last.t + 0.005) this.mCur.samples.push({ t, box: this.cursorBox() });
      this.mCur.t1 = t;
    };
    const loop = () => {
      if (!this.mCur) return;
      sample();
      this.tick();
      if (this.video.ended) { this.endDrag(); return; }
      this.mRaf = requestAnimationFrame(loop);
    };
    sample();
    this.video.play().catch(() => {});
    this.mRaf = requestAnimationFrame(loop);
  },
  endDrag() {
    cancelAnimationFrame(this.mRaf);
    this.video.pause();
    $('#veFacePicks').classList.remove('rec');
    this.finalizeSegment(true);
  },
  // nama lama (serasi)
  beginSegment() { this.beginDrag(); },
  endSegment() { this.endDrag(); },

  /** Simpan segmen semasa ke senarai manual (ganti rekod lama dalam julat yang sama). */
  finalizeSegment(smooth) {
    const seg = this.mCur;
    this.mCur = null;
    if (!seg || !seg.samples.length) { this.drawFace(); return; }
    let S = seg.samples;
    if (S.length === 1) S = [S[0], { t: Math.min(this.duration, S[0].t + this.stepSize() * 0.9), box: S[0].box }];
    if (smooth && S.length > 2) {
      // licinkan getaran tangan (purata bergerak 5 titik)
      S = S.map((p, i) => {
        let cx = 0, cy = 0, w = 0, hh = 0, n = 0;
        for (let k = Math.max(0, i - 2); k <= Math.min(S.length - 1, i + 2); k++) { const b = S[k].box; cx += b.x + b.w / 2; cy += b.y + b.h / 2; w += b.w; hh += b.h; n++; }
        cx /= n; cy /= n; w /= n; hh /= n;
        return { t: p.t, box: { x: cx - w / 2, y: cy - hh / 2, w, h: hh } };
      });
    }
    seg.samples = S;
    seg.t0 = S[0].t; seg.t1 = S[S.length - 1].t;
    const out = [];
    for (const r of this.manual) {
      if (r.t1 < seg.t0 || r.t0 > seg.t1) { out.push(r); continue; }
      const before = r.samples.filter((x) => x.t < seg.t0 - 0.02), after = r.samples.filter((x) => x.t > seg.t1 + 0.02);
      if (before.length > 1) out.push({ t0: before[0].t, t1: before[before.length - 1].t, samples: before });
      if (after.length > 1) out.push({ t0: after[0].t, t1: after[after.length - 1].t, samples: after });
    }
    out.push(seg);
    out.sort((x, y) => x.t0 - y.t0);
    this.manual = out;
    this.track = this.mergedTrack();
    this.renderStrip();
    this.drawFace();
  },

  /* ----------------------------- eksport ----------------------------- */
  async buildExportJob(dest, quality) {
    const info = this.info;
    const W = info.width || this.vw, H = info.height || this.vh;
    const dir = await window.api.tempDir('eksport');
    const inputs = ['-i', this.src];
    const graph = [];
    let cur = '0:v';
    let idx = 1;
    let n = 0;
    const lbl = () => 'v' + (n++);

    // --- fokus muka ---
    let face = null;
    if (this.track && this.track.some((s) => s.box)) {
      const o = this.faceOpts();
      let labelSize = null;
      let labelCanvas = null;
      if (o.label) {
        labelCanvas = makeLabelCanvas(o.label, Math.max(14, Math.round(H * 0.035)), o.color);
        labelSize = { w: labelCanvas.width, h: labelCanvas.height };
      }
      const cmds = buildFaceCommands(this.track, this.duration, W, H, { pad: o.pad, shape: o.shape, labelSize, cmdFps: 15 });
      const thick = Math.max(2, o.thick * Math.max(W, H) / 1000);
      const sc = document.createElement('canvas');
      sc.width = Math.max(16, cmds.baseW); sc.height = Math.max(16, cmds.baseH);
      drawFocusShape(sc.getContext('2d'), o.shape, 0, 0, sc.width, sc.height, o.color, thick);
      await window.api.writeFile(await window.api.join(dir, 'face.png'), await canvasToBytes(sc, 'image/png'));
      await window.api.writeText(await window.api.join(dir, 'cmds.txt'), cmds.text);
      if (labelCanvas) await window.api.writeFile(await window.api.join(dir, 'label.png'), await canvasToBytes(labelCanvas, 'image/png'));
      face = { cmds, labelCanvas, sw: sc.width, sh: sc.height };
      const o2 = lbl();
      graph.push(`[${cur}]sendcmd=f=cmds.txt[${o2}]`);
      cur = o2;
    }

    // --- tindanan statik (teks/bentuk) dikumpul ikut julat masa ---
    const groups = new Map();
    for (const o of this.ed.userObjects()) {
      const s = +(o.mpStart || 0).toFixed(2);
      const e = o.mpEnd == null ? null : +o.mpEnd.toFixed(2);
      const key = s + '|' + e;
      if (!groups.has(key)) groups.set(key, { s, e, objs: [] });
      groups.get(key).objs.push(o);
    }
    // pulihkan kelegapan sebenar sebelum render
    const mult = W / this.ed.workW;
    let gi = 0;
    for (const g of groups.values()) {
      // kekalkan susunan lapisan asal
      const url = this.ed.renderObjectsPng(g.objs, mult);
      const name = `ov${gi++}.png`;
      await window.api.writeFile(await window.api.join(dir, name), dataUrlToBytes(url));
      inputs.push('-i', name);
      const o2 = lbl();
      const en = (g.s > 0 || g.e != null) ? `:enable='between(t,${g.s},${g.e == null ? 999999 : g.e})'` : '';
      graph.push(`[${cur}][${idx}:v]overlay=0:0${en}[${o2}]`);
      cur = o2; idx++;
    }
    this.updateVisibility(true);

    if (face) {
      inputs.push('-loop', '1', '-framerate', '25', '-i', 'face.png');
      const fs = lbl(), o2 = lbl();
      graph.push(`[${idx}:v]format=rgba,scale@face=w=${face.sw}:h=${face.sh}:eval=frame[${fs}]`);
      graph.push(`[${cur}][${fs}]overlay@face=x=-100000:y=-100000:eval=frame:shortest=1[${o2}]`);
      cur = o2; idx++;
      if (face.labelCanvas) {
        inputs.push('-i', 'label.png');
        const o3 = lbl();
        graph.push(`[${cur}][${idx}:v]overlay@lbl=x=-100000:y=-100000:eval=frame[${o3}]`);
        cur = o3; idx++;
      }
    }
    graph.push(`[${cur}]${presetVideoFilters(quality)}[vout]`);
    await window.api.writeText(await window.api.join(dir, 'graph.txt'), graph.join(';\n'));
    const args = inputs.concat(['-filter_complex_script', 'graph.txt', '-map', '[vout]', '-map', '0:a:0?'],
      presetEncodeArgs(quality, info.hasAudio), ['-t', this.duration.toFixed(3), dest]);
    return { args, dir, graph };
  },

  /** Eksport tanpa ffmpeg (Android): main semula + lukis tindanan + MediaRecorder. */
  async webExport(dest, quality, isCancelled) {
    const [W, H] = WebVideo.outSize(this.vw, this.vh, quality);
    const groups = new Map();
    for (const o of this.ed.userObjects()) {
      const s = +(o.mpStart || 0).toFixed(2), e = o.mpEnd == null ? null : +o.mpEnd.toFixed(2);
      const key = s + '|' + e;
      if (!groups.has(key)) groups.set(key, { s, e, objs: [] });
      groups.get(key).objs.push(o);
    }
    const layers = [];
    for (const g of groups.values()) layers.push({ s: g.s, e: g.e == null ? Infinity : g.e, img: await loadImageUrl(this.ed.renderObjectsPng(g.objs, W / this.ed.workW)) });
    this.updateVisibility(true);
    const track = this.track && this.track.some((x) => x.box) ? this.track : null;
    const fo = this.faceOpts();
    const thick = Math.max(2, fo.thick * Math.max(W, H) / 1000);
    const lbl = fo.label ? makeLabelCanvas(fo.label, Math.max(14, Math.round(H * 0.035)), fo.color) : null;
    const overlay = (ctx, t) => {
      for (const L of layers) if (t >= L.s - 0.001 && t <= L.e + 0.001) ctx.drawImage(L.img, 0, 0, W, H);
      if (!track) return;
      const b = trackBoxAt(track, t);
      if (!b) return;
      const r = focusRect(b, W, H, fo.pad, fo.shape);
      drawFocusShape(ctx, fo.shape, r.x, r.y, r.w, r.h, fo.color, thick);
      if (lbl) {
        let ly = r.y - lbl.height - Math.max(4, lbl.height * 0.15);
        if (ly < 0) ly = r.y + r.h + Math.max(4, lbl.height * 0.15);
        ctx.drawImage(lbl, r.cx - lbl.width / 2, ly);
      }
    };
    Progress.set(0, 'Memproses video (masa ≈ tempoh video)…');
    const r = await WebVideo.render({ url: window.api.mediaUrl(this.previewPath || this.src), preset: quality, overlay, isCancelled, onProgress: (p) => Progress.set(p) });
    if (!r) return null;
    const path = dest.replace(/\.[^.\\/]+$/, '') + '.' + r.ext;
    await saveBlob(path, r.blob);
    return { path, size: r.blob.size };
  },

  async exportVideo(destPath) {
    if (!this.src) { toast('Buka video terlebih dahulu.', 'warn'); return null; }
    this.video.pause();
    this.ed.canvas.discardActiveObject();
    const quality = $('#veQuality').value;
    let dest = destPath;
    if (!dest) {
      dest = await window.api.saveFile({ name: stripExt(baseName(this.src)) + '_edit.mp4', title: 'Simpan video', filters: [{ name: 'Video MP4', extensions: ['mp4'] }] });
      if (!dest) return null;
    }
    if (!/\.mp4$/i.test(dest)) dest += '.mp4';
    let cancelFn = null;
    let cancelled = false;
    Progress.show('Mengeksport video…', 'Menyediakan lapisan…', () => { cancelled = true; if (cancelFn) cancelFn(); });
    try {
      if (!hasFfmpeg()) {
        const out = await this.webExport(dest, quality, () => cancelled);
        if (!out) { toast('Eksport dibatalkan.', 'warn'); return null; }
        window.api.library.add(out.path);
        toast(`Video disimpan (${formatBytes(out.size)}): ${out.path}`, 'ok', 'Berjaya');
        return out.path;
      }
      const job = await this.buildExportJob(dest, quality);
      Progress.set(0, 'Mengekod video (ffmpeg)…');
      const r = await runFfmpegJob(job.args, {
        cwd: job.dir, duration: this.duration,
        registerCancel: (fn) => { cancelFn = fn; },
        onProgress: (p) => Progress.set(p)
      });
      window.api.remove(job.dir);
      if (r.cancelled || cancelled) { await window.api.remove(dest); toast('Eksport dibatalkan.', 'warn'); return null; }
      if (r.code !== 0) { console.error(r.stderr); throw new Error(ffmpegErrorText(r)); }
      const fi = await window.api.fileInfo(dest);
      window.api.library.add(dest);
      toast(`Video disimpan (${formatBytes(fi.size)}): ${dest}`, 'ok', 'Berjaya');
      return dest;
    } catch (e) {
      toast(e.message, 'err', 'Eksport gagal');
      return null;
    } finally {
      Progress.hide();
      this.ed.renderProps();
    }
  }
};
